# CHRONOS BLADE: PIXEL LEGACY

Juego de plataformas 2D en Pixel Art para móvil, optimizado **exclusivamente para pantalla HORIZONTAL (Landscape)**, con 3 personajes desbloqueables + héroe inicial, 4 armas, 4 potenciadores, tienda, diálogos RPG y 3 modos de juego.

**Todo el código está escrito a mano, completo y sin placeholders: 19 scripts C#, 8.283 líneas.**
El código fue verificado con el compilador real de C# (Roslyn, `LangVersion 9.0`) contra una réplica de la API de Unity: **0 errores, 0 warnings**.


> 📦 **Este repositorio es un proyecto Unity completo listo para GitHub**, con compilación automática del APK de Android
> mediante GitHub Actions. Consulta **[README.md](README.md)** para: subir el proyecto, crear el secreto `UNITY_LICENSE`,
> compilar el APK desde la pestaña *Actions* y descargarlo como artefacto o Release.

---

## 1) Los 5 pasos para que funcione al presionar Play

**PASO 1 — Orientación Landscape.**
`Edit → Project Settings → Player → Resolution and Presentation`:
- `Default Orientation` = **Landscape Left**
- En `Allowed Orientations for Auto Rotation` deja marcadas solo **Landscape Left** y **Landscape Right** (desmarca `Portrait` y `Portrait Upside Down`).
- Desactiva `Use 32-bit Display Buffer`? (opcional). En Android/iOS puedes activar `Render outside safe area`.

**PASO 2 — Importar y reproducir.**
Copia la carpeta `Assets/ChronosBlade` dentro de `Assets/` de tu proyecto. Abre cualquier escena (puede estar vacía) y presiona **Play**.
`RuntimeBootstrap.cs` construye en tiempo de ejecución: cámara, fondo con parallax, menú, niveles, HUD, controles táctiles y el gestor de modos. No necesitas prefabs, escenas ni assets de arte/audio (el Pixel Art y el sonido se generan por código).
Ajusta la **Game view a 1280x720 (Landscape)** en el editor.

**PASO 3 — Componentes del Jugador (si lo montas a mano).**
El juego ya crea el jugador por código con lo siguiente; si prefieres hacerlo manual:
- `SpriteRenderer` (sorting order 20)
- `Rigidbody2D`: `Body Type = Dynamic`, `Gravity Scale = 3.1`, `Constraints = Freeze Rotation Z`, `Interpolation = Interpolate`, `Collision Detection = Continuous`
- `BoxCollider2D`: `Size = (0.62, 1.5)`, `Offset = (0, 0.75)` (los pies quedan en el pivote)
- Script `PixelPlayerController` (incluye `[RequireComponent(typeof(Rigidbody2D))]` y `[RequireComponent(typeof(BoxCollider2D))]`).
- Opcional: un hijo con `Animator` (recibe automáticamente los parámetros `Speed` float, `Grounded` bool, `VelocityY` float, `Attacking` bool, `Dead` bool y el trigger `Attack`).

**PASO 4 — Canvas / HUD (Landscape).**
El HUD y los controles táctiles se crean por código con: `Canvas` en `Screen Space - Overlay` + **`CanvasScaler` = Scale With Screen Size, Reference Resolution 1280x720, Match 0.5** + `GraphicRaycaster` + un `EventSystem` (se crea automáticamente si no existe).
Si agregas tus propios Canvas, usa exactamente esos valores para que las posiciones del joystick (izquierda) y de los botones (derecha) coincidan.

**PASO 5 — Entrada y física.**
- `Edit → Project Settings → Player → Active Input Handling` = **Both** (o `Input Manager (Old)`). El juego usa la API clásica `Input` para el teclado de pruebas; los controles táctiles funcionan por `EventSystem`.
- `Edit → Project Settings → Physics 2D → Gravity` = `(0, -9.81)` (valor por defecto; el código lo escala por `gravityScale`).
- El HUD/joystick se posicionan anclados a esquinas, así que funciona en cualquier resolución Landscape (16:9, 18:9, 20:9).

---

## 2) Controles

| Acción | Teclado (pruebas) | Táctil (Landscape) |
|---|---|---|
| Mover | `A`/`D` o ←/→ | Joystick (esquina inferior izquierda) |
| Saltar / Doble salto | `Espacio` / `W` / ↑ | Botón **SALTO** (pulsa dos veces para doble salto) |
| Atacar (apuntando con el joystick) | `J` / `K` / `Z` / `X` | Botón **ATACAR** |
| Usar potenciador 1-4 | `1` `2` `3` `4` | 4 ranuras de consumibles del HUD |
| Avanzar diálogo | `Espacio` / clic / `Enter` | Tocar el cuadro de diálogo |
| Pausa | `Esc` / `P` | Botón `II` (arriba-derecha) |

---

## 3) Modos de juego

- **Historia** (`GameMode.Story`): 5 niveles con diálogos RPG (efecto máquina de escribir, salto de texto, movimiento congelado durante la conversación), checkpoints, cofres, pinchos, plataformas móviles y Portal Temporal final. La progresión se guarda: el menú continúa en el nivel alcanzado.
- **Supervivencia / Arcade** (`GameMode.Survival`): oleadas infinitas con contador de bajas, oleada, enemigos vivos máximos, dificultad creciente (tier de enemigos, velocidad y cadencias) y récord personal guardado.
- **Speedrun** (`GameMode.Speedrun`): cronómetro de precisión **MM:SS:MS**, tiempo "PAR", placas de impulso, penalización de +3 s por caída y récord guardado con `PlayerPrefs`.

---

## 4) Sistemas principales

| Sistema | Archivo | Qué hace |
|---|---|---|
| Jugador | `Player/PixelPlayerController.cs` | Estadísticas por personaje (VID/VEL/DAÑO), correr con aceleración, salto con altura variable, coyote time + buffer, doble salto, ataque, daño con invulnerabilidad y parpadeo, muerte, respawn, monedas/gemas, sombra dinámica, animación procedural + parámetros de Animator. |
| Armas y potenciadores | `Player/WeaponAndPowerUpSystem.cs` | 4 armas (Espada, Gran Espada de Fuego, Dagas Rápidas, Lanza Bumerán que vuela y regresa perforando), caja de golpe orientable, daño = arma × nivel × personaje × potenciador. Potenciadores: Tónico (invencible 8 s), Imán (atrae monedas/gemas 12 s), Escudo (absorbe el próximo golpe), Daño x2 (10 s). |
| Tienda y desbloqueos | `UI/PixelShopManager.cs` | 3 pestañas (Personajes / Armas / Potenciadores), Compra y Selección de héroes, Compra/Equipar/Mejorar armas (5 niveles con coste exponencial), consumibles, verificación de saldo mixto (Monedas + Gemas), descuento automático, avisos de error y guardado en `PlayerPrefs`. |
| Diálogos | `UI/DialogueManager.cs` | Cuadro amplio superior para Landscape, typewriter configurable, avance/salto, auto-avance temporizado, congelamiento del jugador, ganchos por conversación. |
| Modos y enemigos | `UI/GameModeAndEnemyManager.cs` + `Enemies/PixelEnemyAI.cs` | Gestor central de los 3 modos (intros, oleadas, cronómetro, records, pausa, pantallas de resultado) + IA con patrulla entre puntos, detección por proximidad, persecución, ataque con enfriamiento, knockback por resistencia, drop de monedas/gemas/corazones y 3 especies (Trashling terrestre, Murciélago volador, Guardián Warden pesado). |
| Guardado | `Core/SaveSystem.cs` | Monedas, gemas, héroes y armas desbloqueadas, niveles de arma, inventario de consumibles, records y progreso de historia. |
| Pixel Art y audio | `Core/SpriteFactory.cs`, `Core/AudioFx.cs` | Todos los sprites 16x16 (héroes con 4 paletas, 3 enemigos, objetos, HUD, iconos, portal, pinchos) y todo el audio (ondas cuadradas/triangulares sintetizadas) generados por código: el juego se ve y suena bien sin importar un solo asset. |
| Escenario | `Core/SceneBuilder.cs`, `World/CameraFollow.cs`, `World/BackgroundScroller.cs`, `World/LevelInteractables.cs`, `World/Vfx.cs` | Construcción del menú y de los niveles, cámara con suavizado/shake/límites, fondo con 3 capas de parallax + nubes, monedas, gemas, corazones, cofres, pinchos, plataformas móviles, checkpoints, portal, placas de impulso, límites de nivel y efectos visuales (corte, chispas, polvo). |

---

## 5) Usa tu propio Pixel Art (opcional)

1. Crea el prefab `Assets/Resources/ChronosBlade/PlayerAnimationOverride.prefab` con el componente `PixelArtOverride` y asigna tus `AnimationClip` (Idle, Run, Jump, Attack, Hurt, Die). El juego las usará automáticamente (`SampleAnimation`) en cuanto existan; si no existe el prefab, usa el pixel art procedural.
2. Para conectar un Animator visual: añade un `Animator Controller` al hijo con `Animator` del jugador y crea estados con los parámetros `Speed` (float), `Grounded` (bool), `VelocityY` (float), `Attacking` (bool), `Dead` (bool) y el trigger `Attack`.
3. Balance y contenido: todo vive en `Core/Catalog.cs` (personajes, armas, precios, duración de potenciadores, curvas de supervivencia, guiones de los 5 niveles).

## 6) Notas

- **Autoarranque**: `RuntimeBootstrap.cs` usa `[RuntimeInitializeOnLoadMethod]`. Si prefieres montar escenas a mano, borra ese archivo (los menús también están en `Chronos Blade/Construir juego en la escena actual` del menú de Unity, y `Chronos Blade/Borrar progreso guardado` reinicia el guardado).
- Los personajes se desbloquean con Monedas; las Gemas se conservan como moneda premium (los potenciadores y las mejoras aceptan el sistema mixto de `TrySpend(monedas, gemas)`).
- Recompensas: cofres, enemigos y bonus de nivel otorgan Monedas; las caídas cuestan tiempo en Speedrun y devuelven al checkpoint en Historia/Supervivencia.
