# CHRONOS BLADE: PIXEL LEGACY 🗡️⏳

Juego de plataformas de acción 2D en **Pixel Art** para móvil, optimizado **exclusivamente para pantalla HORIZONTAL (Landscape)**.

**3 modos de juego** (Historia con diálogos RPG, Supervivencia/Arcade y Speedrun con cronómetro MM:SS:MS), **4 héroes desbloqueables**, **4 armas**, **4 potenciadores**, tienda completa y guardado persistente.

> **Listo para usar:** todo el código está escrito a mano, completo y sin placeholders (**19 scripts C# + 2 de Editor**), verificado con el compilador real de C# → **0 errores, 0 advertencias**.
> El Pixel Art (sprites 16×16), los fondos con parallax, el HUD, los controles táctiles y todo el audio **se generan por código**: no hace falta importar ningún asset.

---

## 📱 1) Subirlo a GitHub desde el teléfono (sin descomprimir nada)

1. Crea un repositorio **Public** (público, así GitHub Actions es gratis e ilimitado).
2. Con el repositorio abierto: **Add file ▸ Upload files** → selecciona **`ChronosBlade-PixelLegacy-Fuente.zip`** tal cual (no lo descomprimas) → **Commit changes**.
3. **Add file ▸ Create new file** → en el nombre escribe exactamente:

   ```
   .github/workflows/chronos-blade.yml
   ```

   (los `/` crean las carpetas solas) → pega el contenido del archivo `chronos-blade.yml` → **Commit changes**.
4. Listo: ya puedes compilar el APK desde **Actions ▸ Chronos Blade ▸ Run workflow**.

> Ese único archivo `.yml` hace **todo**: activar la licencia, compilar el APK y (opcional) extraer el proyecto al repositorio.

---

## 🔑 2) Obtener la licencia de Unity (solo la primera vez)

GitHub necesita una licencia de Unity para compilar. Se hace **una sola vez**:

1. Ve a **Actions ▸ Chronos Blade ▸ Run workflow** y elige la acción **`activar-licencia`**.
2. Cuando termine (~3 min), abre el run y descarga el artefacto **`Unity-Activation-File`** (contiene un `.alf`).
3. Entra desde el navegador a **https://license.unity3d.com/manual**, inicia sesión con tu cuenta de Unity y sube ese `.alf`.
4. Elige **Unity Personal** (o tu licencia) y descarga el archivo **`.ulf`**.
5. Ábrelo con cualquier app de notas/bloc de notas del teléfono, copia **TODO** el texto y guárdalo en
   **Settings ▸ Secrets and variables ▸ Actions ▸ New repository secret** con el nombre exacto:

   | Nombre del secreto | Valor |
   |---|---|
   | `UNITY_LICENSE` | Todo el contenido del archivo `.ulf` |
   | `UNITY_EMAIL` (recomendado) | El correo de tu cuenta de Unity |
   | `UNITY_PASSWORD` (recomendado) | La contraseña de tu cuenta de Unity |

> ¿Tienes licencia Pro/Plus? En vez del `.ulf`, crea los secretos `UNITY_EMAIL`, `UNITY_PASSWORD` y `UNITY_SERIAL`.

---

## 📦 3) Compilar el APK

1. **Actions ▸ Chronos Blade ▸ Run workflow ▸ `compilar-apk`**.
2. Espera ~10-25 minutos (la primera vez: descarga Unity + compila IL2CPP/ARM).
3. Abre el run terminado y descarga el artefacto **`ChronosBlade-APK`** → dentro está **`ChronosBlade-PixelLegacy.apk`**.
4. Pásalo al teléfono, actívalo e instálalo (permite "instalar apps de origen desconocido").

**Opcional:** elige la acción **`extraer-proyecto`** para que la carpeta `Assets/` con todo el código aparezca *de verdad* en el repositorio (útil para verlo/editarlo o abrirlo con Unity Hub). El ZIP original no se borra, así que puedes seguir compilando el APK igual.

**¿Por qué funciona?** El workflow descomprime tu ZIP en la nube, aplica la configuración (Landscape + Android/IL2CPP) y llama a `ChronosBlade.EditorTools.AndroidBuilder.BuildFromCI`.

---

## ⚙️ 4) Lo que el proyecto configura solo

`Assets/ChronosBlade/Editor/ProjectConfigurator.cs` aplica automáticamente (al abrir el proyecto en Unity, desde el menú **Chronos Blade ▸ 1. Configurar proyecto** y antes de cualquier build):

- **Default Orientation = Landscape Left** (+ rotación a Landscape Right; retrato desactivado).
- Nombre del producto, compañía, versión y **bundle id** `com.chronosblade.pixellegacy`.
- **IL2CPP** + **ARMv7/ARM64**, min SDK 24 (Android 7.0), target SDK automático.
- Crea la escena **`Bootstrap.unity`** y la registra en *Build Settings*.
- Al ejecutar: 60 FPS objetivo y la pantalla no se apaga (`Screen.sleepTimeout`).

`AndroidBuilder.cs` compila el APK en local (**Chronos Blade ▸ 2. Compilar APK Android (local)** → `Builds/…apk`) y en la nube.
¿Quieres el APK más liviano/rápido? En `ApplyPlayerSettings()` deja solo `AndroidArchitecture.ARM64`.

---

## 🖥️ 5) Abrir el proyecto en Unity (opcional, en PC)

1. Instala **Unity Hub** + **Unity 2022.3.62f1 LTS** con *Android Build Support*.
2. Descarga el repositorio (`Code ▸ Download ZIP` o `git clone`) y descomprime.
3. Unity Hub: **Add ▸ Add project from disk** → elige la carpeta del proyecto.
4. Abre la escena `Assets/ChronosBlade/Scenes/Bootstrap.unity` (se crea sola la primera vez) y presiona **Play**.

Compilar APK en local: menú **Chronos Blade ▸ 2. Compilar APK Android (local)** o:

```bash
Unity -quit -batchmode -projectPath . -executeMethod ChronosBlade.EditorTools.AndroidBuilder.BuildFromCI
```

---

## 🎮 6) Controles

| Acción | Teclado (editor) | Táctil (Landscape) |
|---|---|---|
| Mover | `A`/`D` o ←/→ | Joystick (abajo-izquierda) |
| Saltar / **doble salto** | `Espacio` / `W` / ↑ | Botón **SALTO** (púlsalo dos veces) |
| Atacar | `J` / `K` / `Z` / `X` | Botón **ATACAR** |
| Potenciadores 1-4 | `1` `2` `3` `4` | 4 ranuras del HUD |
| Avanzar diálogo | `Espacio` / clic | Tocar el cuadro de diálogo |
| Pausa | `Esc` / `P` | Botón `II` (arriba-derecha) |

---

## 📁 7) Estructura del proyecto

```
Assets/ChronosBlade/
├── Editor/
│   ├── ProjectConfigurator.cs   # Landscape + Android + escena Bootstrap (+ preprocesador de build)
│   └── AndroidBuilder.cs        # Compila el APK (menú local y modo CI)
├── Scenes/                      # Bootstrap.unity (se crea/registra sola)
└── Scripts/
    ├── Core/       Catalog, SpriteFactory, SaveSystem, InputHub, GameSession,
    │               AudioFx, SceneBuilder, RuntimeBootstrap
    ├── Player/     PixelPlayerController, WeaponAndPowerUpSystem
    ├── Enemies/    PixelEnemyAI
    ├── UI/         UIFactory, DialogueManager, GameModeAndEnemyManager, PixelShopManager
    └── World/      CameraFollow, BackgroundScroller, LevelInteractables, Vfx

Packages/manifest.json
ProjectSettings/ProjectVersion.txt
DOCUMENTACION_JUEGO.md   # Documentación detallada del juego y de sus sistemas
```

---

## 🧩 8) Modos de juego

- **HISTORIA** — 5 niveles con diálogos RPG (efecto máquina de escribir), checkpoints, cofres, pinchos, plataformas móviles y Portal Temporal. Guarda tu progreso.
- **SUPERVIVENCIA (Arcade)** — oleadas infinitas con contador de bajas, oleada actual y dificultad creciente; récord personal guardado.
- **SPEEDRUN** — cronómetro de precisión **MM:SS:MS**, tiempo "PAR", placas de impulso, +3 s de penalización por caída y récord persistente.

**Tienda:** 4 personajes con estadísticas únicas (VID/VEL/DAÑO), 4 armas mejorables a 5 niveles (Espada Inicial, Gran Espada de Fuego, Dagas Rápidas, Lanza Bumerán) y 4 potenciadores (Tónico de Invencibilidad, Imán de Monedas, Escudo de Fuerza, Daño x2).

---

## ❓ 9) Solución de problemas

| Problema | Solución |
|---|---|
| `UNITY_LICENSE` inválido o expirado | Vuelve a ejecutar la acción `activar-licencia`, genera un `.ulf` nuevo y actualiza el secreto. |
| El workflow no aparece en la pestaña Actions | El archivo debe estar exactamente en `.github/workflows/chronos-blade.yml` y en la rama principal (`main`). |
| "No scenes in build settings" | El proyecto lo resuelve solo: `ProjectConfigurator` crea y registra `Bootstrap.unity` antes de cada build. |
| La compilación tarda mucho | Es normal la **primera vez** (~15-25 min: Unity + IL2CPP + ARM). Las siguientes usan la caché `Library`. |
| El juego no responde al teclado en el editor | `Edit ▸ Project Settings ▸ Player ▸ Active Input Handling` = **Both** o *Input Manager (Old)*. |
| Errores de `Input` (formato antiguo) | Misma causa anterior (paquete *Input System* como único). |
| Repositorio privado y se acaban los minutos | Los repos **públicos** tienen Actions gratis e ilimitado. |

---

## 📜 10) Extra

- Documentación completa del juego (sistemas, balance, cómo usar tu propio Pixel Art): **[DOCUMENTACION_JUEGO.md](DOCUMENTACION_JUEGO.md)**.
- Todo el balance y el contenido están centralizados en `Assets/ChronosBlade/Scripts/Core/Catalog.cs`.
- Para usar tus propios sprites: crea `Assets/Resources/ChronosBlade/PlayerAnimationOverride.prefab` con el componente `PixelArtOverride`.
