#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace ChronosBlade.EditorTools
{
    /// <summary>
    /// Configura el proyecto automaticamente para movil HORIZONTAL (Landscape) y Android:
    ///  - Orientacion por defecto: Landscape Left (y rotacion a Landscape Right).
    ///  - Identificador de paquete, version, SDK minimo/objetivo y arquitecturas.
    ///  - Backend de scripting IL2CPP (necesario para ARM64 en Google Play).
    ///  - Crea y registra la escena "Bootstrap" que arranca el juego.
    ///
    /// Se ejecuta: al abrir el proyecto, desde el menu "Chronos Blade",
    /// y como paso previo a CUALQUIER build (ver ChronosBuildPreprocessor).
    /// </summary>
    public static class ProjectConfigurator
    {
        public const string PackageName = "com.chronosblade.pixellegacy";
        public const string ProductName = "Chronos Blade: Pixel Legacy";
        public const string CompanyName = "ChronosBlade Studio";
        public const string BundleVersion = "1.0.0";
        public const int BundleVersionCode = 1;
        public const string SceneFolder = "Assets/ChronosBlade/Scenes";
        public const string BootstrapScenePath = SceneFolder + "/Bootstrap.unity";

        [InitializeOnLoadMethod]
        private static void AutoConfigureOnLoad()
        {
            // Se difiere al siguiente ciclo del editor para no interferir con la carga de assets.
            EditorApplication.delayCall += delegate { EnsureConfigured(false); };
        }

        [MenuItem("Chronos Blade/1. Configurar proyecto (Landscape + Android)")]
        public static void ConfigureFromMenu()
        {
            EnsureConfigured(true);
            EditorUtility.DisplayDialog(
                "Chronos Blade: Pixel Legacy",
                "Proyecto configurado.\n\n- Orientacion: Landscape Left\n- Paquete: " + PackageName
                + "\n- IL2CPP + ARM64/ARMv7\n- Escena Bootstrap lista en Build Settings\n\nYa puedes presionar Play.",
                "Genial");
        }

        /// <summary>Aplica todos los ajustes de proyecto y garantiza la escena de arranque.</summary>
        public static void EnsureConfigured(bool verbose)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            {
                return;
            }

            ApplyPlayerSettings();
            EnsureBootstrapScene();
            AssetDatabase.SaveAssets();

            if (verbose)
            {
                Debug.Log("[Chronos Blade] Configuracion aplicada: Landscape, Android (IL2CPP/ARM), escena Bootstrap registrada.");
            }
        }

        /// <summary>Ajustes de Player Settings para movil horizontal.</summary>
        public static void ApplyPlayerSettings()
        {
            PlayerSettings.productName = ProductName;
            PlayerSettings.companyName = CompanyName;
            PlayerSettings.bundleVersion = BundleVersion;

            // --- Orientacion Landscape (requisito del juego) ---
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            PlayerSettings.allowedAutorotateToLandscapeLeft = true;
            PlayerSettings.allowedAutorotateToLandscapeRight = true;
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;

            // --- Identidad y versionado Android ---
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, PackageName);
            PlayerSettings.Android.bundleVersionCode = BundleVersionCode;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;

            // --- Rendimiento movil: IL2CPP + ARM64 (obligatorio en Google Play) ---
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64 | AndroidArchitecture.ARMv7;
        }

        /// <summary>Crea (si falta) la escena Bootstrap y la deja habilitada en Build Settings.</summary>
        public static void EnsureBootstrapScene()
        {
            if (!File.Exists(BootstrapScenePath))
            {
                string folder = Path.GetDirectoryName(BootstrapScenePath);
                if (!string.IsNullOrEmpty(folder) && !AssetDatabase.IsValidFolder(folder))
                {
                    AssetDatabase.CreateFolder("Assets/ChronosBlade", "Scenes");
                }

                Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
                EditorSceneManager.SaveScene(scene, BootstrapScenePath);
                EditorSceneManager.CloseScene(scene, true);
                AssetDatabase.Refresh();
                Debug.Log("[Chronos Blade] Escena creada: " + BootstrapScenePath);
            }

            RegisterSceneInBuildSettings();
        }

        private static void RegisterSceneInBuildSettings()
        {
            EditorBuildSettingsScene[] scenes = EditorBuildSettings.scenes;
            for (int i = 0; i < scenes.Length; i++)
            {
                if (scenes[i] != null && scenes[i].path == BootstrapScenePath)
                {
                    if (!scenes[i].enabled)
                    {
                        scenes[i].enabled = true;
                        EditorBuildSettings.scenes = scenes;
                    }
                    return;
                }
            }

            EditorBuildSettingsScene[] updated = new EditorBuildSettingsScene[scenes.Length + 1];
            System.Array.Copy(scenes, updated, scenes.Length);
            updated[scenes.Length] = new EditorBuildSettingsScene(BootstrapScenePath, true);
            EditorBuildSettings.scenes = updated;
            Debug.Log("[Chronos Blade] Escena registrada en Build Settings: " + BootstrapScenePath);
        }

        /// <summary>Rutas de las escenas habilitadas (la escena Bootstrap si no hay ninguna mas).</summary>
        public static string[] GetEnabledScenePaths()
        {
            System.Collections.Generic.List<string> paths = new System.Collections.Generic.List<string>();
            EditorBuildSettingsScene[] scenes = EditorBuildSettings.scenes;
            for (int i = 0; i < scenes.Length; i++)
            {
                if (scenes[i] != null && scenes[i].enabled && !string.IsNullOrEmpty(scenes[i].path))
                {
                    paths.Add(scenes[i].path);
                }
            }
            if (paths.Count == 0)
            {
                paths.Add(BootstrapScenePath);
            }
            return paths.ToArray();
        }
    }

    /// <summary>
    /// Se ejecuta justo antes de cualquier build (interfaz o linea de comandos) para
    /// garantizar que la orientacion y la escena de arranque esten configuradas.
    /// </summary>
    public class ChronosBuildPreprocessor : IPreprocessBuildWithReport
    {
        public int callbackOrder
        {
            get { return 0; }
        }

        public void OnPreprocessBuild(BuildReport report)
        {
            ProjectConfigurator.EnsureConfigured(false);
        }
    }
}
#endif
