#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace ChronosBlade.EditorTools
{
    /// <summary>
    /// Compilador de APK de Chronos Blade: Pixel Legacy para Android.
    ///
    /// Uso en el editor:   menu "Chronos Blade -> 2. Compilar APK Android (local)"
    /// Uso desde CI:       Unity -quit -batchmode -projectPath . -executeMethod ChronosBlade.EditorTools.AndroidBuilder.BuildFromCI
    ///
    /// En CI (GitHub Actions con game-ci/unity-builder) se respeta el argumento
    /// "-customBuildPath" que envie la accion, aceptando tanto una carpeta como
    /// una ruta de archivo .apk. Si no llega, se usa "build/Android/".
    /// </summary>
    public static class AndroidBuilder
    {
        public const string ApkFileName = "ChronosBlade-PixelLegacy.apk";
        public const string CiOutputFolder = "build/Android";
        public const string LocalOutputFolder = "Builds";

        [MenuItem("Chronos Blade/2. Compilar APK Android (local)")]
        public static void BuildFromMenu()
        {
            string apkPath = Path.GetFullPath(Path.Combine(LocalOutputFolder, ApkFileName));
            BuildApk(apkPath, true);
        }

        /// <summary>Metodo invocado por GitHub Actions (game-ci/unity-builder -> buildMethod).</summary>
        public static void BuildFromCI()
        {
            string customPath = ReadCommandLineArgument("-customBuildPath");
            string apkPath;

            if (!string.IsNullOrEmpty(customPath) && customPath.Trim().EndsWith(".apk", System.StringComparison.OrdinalIgnoreCase))
            {
                // La accion ya nos dio la ruta completa del archivo APK.
                apkPath = Path.GetFullPath(customPath.Trim());
            }
            else if (!string.IsNullOrEmpty(customPath))
            {
                // La accion nos dio una carpeta de salida.
                apkPath = Path.GetFullPath(Path.Combine(customPath.Trim(), ApkFileName));
            }
            else
            {
                apkPath = Path.GetFullPath(Path.Combine(CiOutputFolder, ApkFileName));
            }

            BuildApk(apkPath, false);
        }

        /// <summary>Compila el APK de Android en la ruta de archivo indicada.</summary>
        public static void BuildApk(string apkFilePath, bool interactive)
        {
            ProjectConfigurator.EnsureConfigured(true);

            if (!EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android))
            {
                Debug.LogWarning("[Chronos Blade] No se pudo cambiar al target Android automaticamente. " +
                    "Instala el modulo 'Android Build Support' desde Unity Hub.");
            }

            string directory = Path.GetDirectoryName(apkFilePath);
            if (!string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
            }

            BuildPlayerOptions options = new BuildPlayerOptions();
            options.scenes = ProjectConfigurator.GetEnabledScenePaths();
            options.locationPathName = apkFilePath;
            options.target = BuildTarget.Android;
            options.targetGroup = BuildTargetGroup.Android;
            options.options = BuildOptions.None;

            Debug.Log("[Chronos Blade] Compilando APK en: " + apkFilePath);
            BuildReport report = BuildPipeline.BuildPlayer(options);
            BuildSummary summary = report.summary;

            if (summary.result == BuildResult.Succeeded)
            {
                Debug.Log("[Chronos Blade] APK generado correctamente: " + summary.outputPath
                    + " (" + (summary.totalSize / 1024 / 1024) + " MB)");
                if (interactive && Application.isBatchMode == false)
                {
                    EditorUtility.DisplayDialog("APK compilado",
                        "El APK se genero en:\n" + summary.outputPath, "Perfecto");
                }
                Finish(0, interactive);
                return;
            }

            Debug.LogError("[Chronos Blade] La compilacion del APK fallo: " + summary.result
                + " (" + summary.totalErrors + " errores)");
            if (interactive && Application.isBatchMode == false)
            {
                EditorUtility.DisplayDialog("Error de compilacion",
                    "La compilacion fallo (" + summary.result + ").\nRevisa la consola de Unity.", "Cerrar");
            }
            Finish(1, interactive);
        }

        private static void Finish(int exitCode, bool interactive)
        {
            if (Application.isBatchMode || !interactive)
            {
                EditorApplication.Exit(exitCode);
            }
        }

        private static string ReadCommandLineArgument(string key)
        {
            string[] args = System.Environment.GetCommandLineArgs();
            for (int i = 0; i < args.Length - 1; i++)
            {
                if (args[i] == key)
                {
                    return args[i + 1];
                }
            }
            return null;
        }
    }
}
#endif
