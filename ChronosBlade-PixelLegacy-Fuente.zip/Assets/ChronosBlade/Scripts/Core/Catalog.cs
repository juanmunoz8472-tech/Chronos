using System.Collections.Generic;
using UnityEngine;

namespace ChronosBlade
{
    /// <summary>Modos de juego soportados por Chronos Blade: Pixel Legacy.</summary>
    public enum GameMode
    {
        Story,
        Survival,
        Speedrun
    }

    /// <summary>Familias de armas equipables.</summary>
    public enum WeaponKind
    {
        InitialSword,
        FireGreatsword,
        FastDaggers,
        BoomerangLance
    }

    /// <summary>Potenciadores activos disponibles en la tienda.</summary>
    public enum PowerUpId
    {
        None,
        Tonic,
        Magnet,
        Shield,
        DoubleDamage
    }

    /// <summary>Especies de enemigos del juego.</summary>
    public enum EnemySpecies
    {
        Trashling,
        Bat,
        Warden
    }

    [System.Serializable]
    public class CharacterDefinition
    {
        public string Id;
        public string DisplayName;
        public string Title;
        public string Description;
        public int MaxHealth;
        public float MoveSpeed;
        public float DamageMultiplier;
        public int PriceCoins;
        public int PaletteIndex;
    }

    [System.Serializable]
    public class WeaponDefinition
    {
        public string Id;
        public string DisplayName;
        public string Description;
        public WeaponKind Kind;
        public int Damage;
        public float AttackCooldown;
        public float Range;
        public float DamagePerLevel;
        public int MaxLevel;
        public int PriceCoins;
        public int UpgradeBaseCost;
        public float Knockback;
        public bool IsProjectile;
        public float ProjectileSpeed;
        public int ProjectilePierce;
        public Color32 SlashColor;
    }

    [System.Serializable]
    public class PowerUpDefinition
    {
        public PowerUpId Id;
        public string Key;
        public string DisplayName;
        public string Description;
        public int PriceCoins;
        public float Duration;
        public PixelArtType Icon;
    }

    /// <summary>
    /// Catalogo central: personajes, armas, potenciadores, curvas de dificultad
    /// y guiones del Modo Historia. Un unico punto de verdad para balance.
    /// </summary>
    public static class ChronosCatalog
    {
        public const string GameTitle = "CHRONOS BLADE: PIXEL LEGACY";
        public const int StoryLevelCount = 5;
        public const int InitialCoins = 250;
        public const int InitialGems = 3;

        public static readonly List<CharacterDefinition> Characters = new List<CharacterDefinition>()
        {
            new CharacterDefinition()
            {
                Id = "kaen", DisplayName = "KAEN", Title = "El Espadachin Carmesi",
                Description = "Equilibrado. Fiel al filo de su espada.",
                MaxHealth = 100, MoveSpeed = 7.5f, DamageMultiplier = 1.00f,
                PriceCoins = 0, PaletteIndex = 0
            },
            new CharacterDefinition()
            {
                Id = "lyra", DisplayName = "LYRA", Title = "Cronomante de Cristal",
                Description = "Rapida y fragil. Domina el tiempo, no los golpes.",
                MaxHealth = 75, MoveSpeed = 9.4f, DamageMultiplier = 0.92f,
                PriceCoins = 1500, PaletteIndex = 1
            },
            new CharacterDefinition()
            {
                Id = "bhram", DisplayName = "BHRAM", Title = "Coloso de Hierro Antiguo",
                Description = "Lento pero brutal. Un muro que camina.",
                MaxHealth = 150, MoveSpeed = 6.2f, DamageMultiplier = 1.35f,
                PriceCoins = 2600, PaletteIndex = 2
            },
            new CharacterDefinition()
            {
                Id = "nyx", DisplayName = "NYX", Title = "Sombra de las Ruinas",
                Description = "Asesina legendaria: letal, ligera, precisa.",
                MaxHealth = 90, MoveSpeed = 8.6f, DamageMultiplier = 1.50f,
                PriceCoins = 5000, PaletteIndex = 3
            }
        };

        public static readonly List<WeaponDefinition> Weapons = new List<WeaponDefinition>()
        {
            new WeaponDefinition()
            {
                Id = "sword", DisplayName = "ESPADA INICIAL", Kind = WeaponKind.InitialSword,
                Description = "Filo balanceado forjado en la era de las ruinas.",
                Damage = 20, AttackCooldown = 0.34f, Range = 1.10f, DamagePerLevel = 0.22f,
                MaxLevel = 5, PriceCoins = 0, UpgradeBaseCost = 200, Knockback = 5.5f,
                IsProjectile = false, ProjectileSpeed = 0f, ProjectilePierce = 0,
                SlashColor = new Color32(220, 240, 255, 210)
            },
            new WeaponDefinition()
            {
                Id = "greatsword", DisplayName = "GRAN ESPADA DE FUEGO", Kind = WeaponKind.FireGreatsword,
                Description = "Lenta, devastadora y envuelta en llamas eternas.",
                Damage = 46, AttackCooldown = 0.62f, Range = 1.45f, DamagePerLevel = 0.24f,
                MaxLevel = 5, PriceCoins = 1200, UpgradeBaseCost = 320, Knockback = 8.5f,
                IsProjectile = false, ProjectileSpeed = 0f, ProjectilePierce = 0,
                SlashColor = new Color32(255, 150, 45, 225)
            },
            new WeaponDefinition()
            {
                Id = "daggers", DisplayName = "DAGAS RAPIDAS", Kind = WeaponKind.FastDaggers,
                Description = "Rafagas veloces: poco daño, presion constante.",
                Damage = 12, AttackCooldown = 0.16f, Range = 0.90f, DamagePerLevel = 0.26f,
                MaxLevel = 5, PriceCoins = 900, UpgradeBaseCost = 260, Knockback = 3.2f,
                IsProjectile = false, ProjectileSpeed = 0f, ProjectilePierce = 0,
                SlashColor = new Color32(180, 255, 210, 190)
            },
            new WeaponDefinition()
            {
                Id = "boomerang", DisplayName = "LANZA BUMERAN", Kind = WeaponKind.BoomerangLance,
                Description = "Proyectil giratorio que atraviesa a todo enemigo.",
                Damage = 26, AttackCooldown = 0.48f, Range = 0.80f, DamagePerLevel = 0.24f,
                MaxLevel = 5, PriceCoins = 1800, UpgradeBaseCost = 380, Knockback = 6.0f,
                IsProjectile = true, ProjectileSpeed = 15.5f, ProjectilePierce = 4,
                SlashColor = new Color32(140, 225, 255, 200)
            }
        };

        public static readonly List<PowerUpDefinition> PowerUps = new List<PowerUpDefinition>()
        {
            new PowerUpDefinition()
            {
                Id = PowerUpId.Tonic, Key = "tonic", DisplayName = "TONICO DE INVENCIBILIDAD",
                Description = "8 s de invulnerabilidad total. Atraviesa enemigos sin temor.",
                PriceCoins = 300, Duration = 8f, Icon = PixelArtType.PowerTonic
            },
            new PowerUpDefinition()
            {
                Id = PowerUpId.Magnet, Key = "magnet", DisplayName = "IMAN DE MONEDAS",
                Description = "12 s atrayendo monedas y gemas cercanas hacia ti.",
                PriceCoins = 250, Duration = 12f, Icon = PixelArtType.PowerMagnet
            },
            new PowerUpDefinition()
            {
                Id = PowerUpId.Shield, Key = "shield", DisplayName = "ESCUDO DE FUERZA",
                Description = "Absorbe por completo el proximo golpe recibido.",
                PriceCoins = 350, Duration = 0f, Icon = PixelArtType.PowerShield
            },
            new PowerUpDefinition()
            {
                Id = PowerUpId.DoubleDamage, Key = "double", DisplayName = "DAÑO x2",
                Description = "10 s infligiendo el doble de daño con cualquier arma.",
                PriceCoins = 400, Duration = 10f, Icon = PixelArtType.PowerDoubleDamage
            }
        };

        public static CharacterDefinition GetCharacter(string id)
        {
            for (int i = 0; i < Characters.Count; i++)
            {
                if (Characters[i].Id == id)
                {
                    return Characters[i];
                }
            }
            return Characters[0];
        }

        public static WeaponDefinition GetWeapon(string id)
        {
            for (int i = 0; i < Weapons.Count; i++)
            {
                if (Weapons[i].Id == id)
                {
                    return Weapons[i];
                }
            }
            return Weapons[0];
        }

        public static PowerUpDefinition GetPowerUp(PowerUpId id)
        {
            for (int i = 0; i < PowerUps.Count; i++)
            {
                if (PowerUps[i].Id == id)
                {
                    return PowerUps[i];
                }
            }
            return null;
        }

        public static PowerUpDefinition GetPowerUpByKey(string key)
        {
            for (int i = 0; i < PowerUps.Count; i++)
            {
                if (PowerUps[i].Key == key)
                {
                    return PowerUps[i];
                }
            }
            return null;
        }

        public static int WeaponDamage(WeaponDefinition def, int level)
        {
            if (def == null)
            {
                return 1;
            }
            float dmg = def.Damage * (1f + (level - 1) * def.DamagePerLevel);
            return Mathf.Max(1, Mathf.RoundToInt(dmg));
        }

        public static int WeaponUpgradeCost(WeaponDefinition def, int currentLevel)
        {
            if (def == null)
            {
                return 999999;
            }
            float scale = Mathf.Pow(1.65f, Mathf.Max(0, currentLevel - 1));
            return Mathf.RoundToInt(def.UpgradeBaseCost * scale);
        }

        /// <summary>Segundos entre apariciones en Supervivencia (la presion aumenta con las bajas).</summary>
        public static float SurvivalSpawnInterval(int kills)
        {
            float interval = 2.4f - kills * 0.055f;
            return Mathf.Clamp(interval, 0.55f, 3f);
        }

        /// <summary>Enemigos vivos maximos simultaneamente en Supervivencia.</summary>
        public static int SurvivalMaxAlive(int kills)
        {
            return Mathf.Clamp(6 + kills / 8, 6, 16);
        }

        /// <summary>Oleada actual en Supervivencia (1 oleada cada 6 bajas).</summary>
        public static int SurvivalWave(int kills)
        {
            return 1 + kills / 6;
        }

        public static float SpeedrunParTime(int track)
        {
            switch (track)
            {
                case 1: return 45f;
                case 2: return 40f;
                case 3: return 52f;
                default: return 48f;
            }
        }

        public static string StoryLevelName(int level)
        {
            switch (level)
            {
                case 1: return "NIVEL 1: EL DESPERTAR DEL ACERO";
                case 2: return "NIVEL 2: LAS CAÑERIAS DE OXIDO";
                case 3: return "NIVEL 3: EL INVERNADERO SUSPENDIDO";
                case 4: return "NIVEL 4: LA TORRE DEL RELOJ ROTO";
                case 5: return "NIVEL 5: EL NUCLEO DE VEX";
                default: return "NIVEL " + level;
            }
        }

        public static string StoryObjective(int level)
        {
            switch (level)
            {
                case 1: return "OBJETIVO: llega al Portal Temporal del este.";
                case 2: return "OBJETIVO: cruza las cañerias y destruye el nido.";
                case 3: return "OBJETIVO: asciende por las plataformas flotantes.";
                case 4: return "OBJETIVO: sube la torre antes de que el tiempo se agote.";
                case 5: return "OBJETIVO: derrota a la guardia de Vex y alcanza el nucleo.";
                default: return "OBJETIVO: avanza hacia el portal.";
            }
        }

        public static readonly Color SpeakerKaen = new Color32(255, 120, 120, 255);
        public static readonly Color SpeakerLyra = new Color32(120, 225, 255, 255);
        public static readonly Color SpeakerCore = new Color32(205, 140, 255, 255);
        public static readonly Color SpeakerNyx = new Color32(150, 255, 170, 255);
        public static readonly Color SpeakerVex = new Color32(255, 190, 90, 255);
        public static readonly Color SpeakerSystem = new Color32(210, 215, 230, 255);

        public static List<DialogueLine> StoryIntro(int level)
        {
            switch (level)
            {
                case 1:
                    return new List<DialogueLine>()
                    {
                        new DialogueLine("LYRA", "Despierta, portador. El Nucleo de Vex devora el tiempo de este mundo.", SpeakerLyra),
                        new DialogueLine("KAEN", "Otra vez tu... y otra vez yo al borde de la ruina.", SpeakerKaen),
                        new DialogueLine("LYRA", "Tu espada recuerda. Muévete con [A][D] o el joystick, salta con [ESPACIO] y ataca con [J].", SpeakerLyra),
                        new DialogueLine("VOZ DEL NUCLEO", "Todo lo que fue... sera mio otra vez.", SpeakerCore)
                    };
                case 2:
                    return new List<DialogueLine>()
                    {
                        new DialogueLine("KAEN", "Cañerias de oxido. El aire quema incluso a este lado del tiempo.", SpeakerKaen),
                        new DialogueLine("LYRA", "Las gemas azules son fragmentos de cronos. Recogelas para la tienda.", SpeakerLyra),
                        new DialogueLine("VOZ DEL NUCLEO", "Corre, espadachin. El reloj ya empezo a contar.", SpeakerCore)
                    };
                case 3:
                    return new List<DialogueLine>()
                    {
                        new DialogueLine("LYRA", "Enjambre de murcielagos cronofagos. Usa el DOBLE SALTO: pulsa salto dos veces.", SpeakerLyra),
                        new DialogueLine("KAEN", "Si caigo, te cobro los daños.", SpeakerKaen),
                        new DialogueLine("LYRA", "Trato hecho. Ahora corre.", SpeakerLyra)
                    };
                case 4:
                    return new List<DialogueLine>()
                    {
                        new DialogueLine("VOZ DEL NUCLEO", "Mis Guardianes del Oxido ya marchan hacia ti.", SpeakerCore),
                        new DialogueLine("KAEN", "Que vengan. Cada engranaje roto es un segundo que te arrebato.", SpeakerKaen),
                        new DialogueLine("NYX", "...Te observo desde las sombras, espadachin. No me decepciones.", SpeakerNyx)
                    };
                case 5:
                    return new List<DialogueLine>()
                    {
                        new DialogueLine("VEX", "Bienvenido al ultimo segundo de tu historia.", SpeakerVex),
                        new DialogueLine("KAEN", "El tiempo no se posee, Vex. Se defiende.", SpeakerKaen),
                        new DialogueLine("LYRA", "Kaen... si el Nucleo cae, todas las lineas temporales se reinician.", SpeakerLyra),
                        new DialogueLine("KAEN", "Entonces que se reinicien. Con mi nombre dentro.", SpeakerKaen)
                    };
                default:
                    return new List<DialogueLine>()
                    {
                        new DialogueLine("LYRA", "El portal te espera. Sigue adelante.", SpeakerLyra)
                    };
            }
        }

        public static List<DialogueLine> StoryOutro(int level)
        {
            switch (level)
            {
                case 1:
                    return new List<DialogueLine>()
                    {
                        new DialogueLine("LYRA", "El primer fragmento es tuyo. El tiempo respira de nuevo.", SpeakerLyra),
                        new DialogueLine("VOZ DEL NUCLEO", "Fue solo un segundo robado...", SpeakerCore)
                    };
                case 2:
                    return new List<DialogueLine>()
                    {
                        new DialogueLine("KAEN", "Nido destruido. Que se oxiden mis enemigos, no mis botas.", SpeakerKaen)
                    };
                case 3:
                    return new List<DialogueLine>()
                    {
                        new DialogueLine("LYRA", "El invernadero colapso, pero sobrevivimos. Siguiente: la Torre.", SpeakerLyra)
                    };
                case 4:
                    return new List<DialogueLine>()
                    {
                        new DialogueLine("NYX", "Impresionante. Tal vez no seas solo una reliquia.", SpeakerNyx),
                        new DialogueLine("KAEN", "Tal vez tu tampoco.", SpeakerKaen)
                    };
                case 5:
                    return new List<DialogueLine>()
                    {
                        new DialogueLine("VEX", "No... el tiempo... ME PERTENECE...", SpeakerVex),
                        new DialogueLine("LYRA", "El Nucleo se apaga. Kaen, lo logramos: el mundo recuerda su futuro.", SpeakerLyra),
                        new DialogueLine("KAEN", "Entonces grabemoslo a filo. Chronos Blade: legado completo.", SpeakerKaen)
                    };
                default:
                    return new List<DialogueLine>()
                    {
                        new DialogueLine("LYRA", "Otro fragmento restaurado.", SpeakerLyra)
                    };
            }
        }

        /// <summary>La ultima linea del propio Vex es mas larga: tiempo extra para leer.</summary>
        public static float AutoAdvanceSeconds(int charactersInLine)
        {
            return 1.6f + charactersInLine * 0.035f;
        }
    }
}
