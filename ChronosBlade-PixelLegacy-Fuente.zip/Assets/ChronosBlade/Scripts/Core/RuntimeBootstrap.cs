using UnityEngine;

namespace ChronosBlade
{
    /// <summary>
    /// Arranque automatico: al presionar Play (con cualquier escena vacia) se
    /// construye el juego completo en tiempo de ejecucion. Tambien expone un
    /// menu de Editor para reconstruirlo manualmente si hiciera falta.
    /// Si prefieres montar tu propia escena a mano, simplemente borra este archivo.
    /// </summary>
    public static class RuntimeBootstrap
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void Launch()
        {
            // Evita duplicados si la escena ya contiene un GameModeManager propio.
            if (Object.FindObjectOfType<GameModeManager>() != null)
            {
                return;
            }
            SceneBuilder.RunBootstrap();
        }

#if UNITY_EDITOR
        [UnityEditor.MenuItem("Chronos Blade/Construir juego en la escena actual")]
        private static void BuildFromMenu()
        {
            SceneBuilder.RunBootstrap();
        }

        [UnityEditor.MenuItem("Chronos Blade/Borrar progreso guardado")]
        private static void ClearSaveFromMenu()
        {
            SaveSystem.ResetAll();
            Debug.Log("[Chronos Blade] Progreso borrado: monedas, gemas, heroes, armas y records reiniciados.");
        }
#endif
    }
}
