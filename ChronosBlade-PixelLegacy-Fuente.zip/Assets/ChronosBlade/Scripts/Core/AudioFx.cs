using System.Collections.Generic;
using UnityEngine;

namespace ChronosBlade
{
    public enum Sfx
    {
        Jump,
        DoubleJump,
        Attack,
        Shoot,
        Hit,
        Coin,
        Gem,
        PowerUp,
        Hurt,
        Die,
        UiClick,
        Purchase,
        Denied,
        Victory,
        Defeat,
        Goal,
        Wave
    }

    public enum MusicMood
    {
        Menu,
        Story,
        Boss,
        Survival,
        Speedrun
    }

    /// <summary>
    /// Audio 100% procedural (ondas cuadradas y ruido generados por codigo),
    /// por lo que el juego suena sin necesitar ningun archivo de audio importado.
    /// </summary>
    public static class AudioFx
    {
        private const int SampleRate = 44100;

        private static AudioSource _sfxSource;
        private static AudioSource _musicSource;
        private static readonly Dictionary<Sfx, AudioClip> SfxClips = new Dictionary<Sfx, AudioClip>();
        private static readonly Dictionary<MusicMood, AudioClip> MusicClips = new Dictionary<MusicMood, AudioClip>();
        private static MusicMood _currentMood = MusicMood.Menu;
        private static bool _musicEnabled = true;
        private static float _sfxVolume = 0.75f;
        private static float _musicVolume = 0.22f;

        public static bool MusicEnabled
        {
            get { return _musicEnabled; }
        }

        public static void Init(GameObject host)
        {
            if (_sfxSource != null || host == null)
            {
                return;
            }

            _sfxSource = host.AddComponent<AudioSource>();
            _sfxSource.playOnAwake = false;
            _sfxSource.loop = false;
            _sfxSource.volume = 1f;

            _musicSource = host.AddComponent<AudioSource>();
            _musicSource.playOnAwake = false;
            _musicSource.loop = true;
            _musicSource.volume = _musicVolume;
        }

        public static void Play(Sfx sfx, float volumeScale = 1f)
        {
            if (_sfxSource == null)
            {
                return;
            }
            AudioClip clip = GetSfxClip(sfx);
            if (clip != null)
            {
                _sfxSource.PlayOneShot(clip, Mathf.Clamp01(volumeScale) * _sfxVolume);
            }
        }

        public static void PlayMusic(MusicMood mood)
        {
            _currentMood = mood;
            if (_musicSource == null || !_musicEnabled)
            {
                return;
            }
            AudioClip clip = GetMusicClip(mood);
            if (clip == null)
            {
                return;
            }
            if (_musicSource.clip == clip && _musicSource.isPlaying)
            {
                return;
            }
            _musicSource.clip = clip;
            _musicSource.Play();
        }

        public static void StopMusic()
        {
            if (_musicSource != null)
            {
                _musicSource.Stop();
            }
        }

        public static void ToggleMusic()
        {
            _musicEnabled = !_musicEnabled;
            if (_musicEnabled)
            {
                PlayMusic(_currentMood);
            }
            else
            {
                StopMusic();
            }
        }

        public static void SetSfxVolume(float value)
        {
            _sfxVolume = Mathf.Clamp01(value);
        }

        public static void SetMusicVolume(float value)
        {
            _musicVolume = Mathf.Clamp01(value);
            if (_musicSource != null)
            {
                _musicSource.volume = _musicVolume;
            }
        }

        // ------------------------------------------------------------------
        // Sintesis
        // ------------------------------------------------------------------
        private static AudioClip GetSfxClip(Sfx sfx)
        {
            AudioClip clip;
            if (SfxClips.TryGetValue(sfx, out clip) && clip != null)
            {
                return clip;
            }

            switch (sfx)
            {
                case Sfx.Jump:
                    clip = MakeSweep("sfx_jump", new float[] { 420f, 620f }, 0.055f, 0.35f, true);
                    break;
                case Sfx.DoubleJump:
                    clip = MakeSweep("sfx_doublejump", new float[] { 620f, 900f }, 0.06f, 0.32f, true);
                    break;
                case Sfx.Attack:
                    clip = MakeSweep("sfx_attack", new float[] { 320f, 180f }, 0.06f, 0.30f, false);
                    break;
                case Sfx.Shoot:
                    clip = MakeSweep("sfx_shoot", new float[] { 780f, 460f }, 0.07f, 0.28f, false);
                    break;
                case Sfx.Hit:
                    clip = MakeNoise("sfx_hit", 0.05f, 0.35f, 1400f);
                    break;
                case Sfx.Coin:
                    clip = MakeMelody("sfx_coin", new float[] { 880f, 1320f }, 0.05f, 0.30f);
                    break;
                case Sfx.Gem:
                    clip = MakeMelody("sfx_gem", new float[] { 990f, 1320f, 1760f }, 0.055f, 0.30f);
                    break;
                case Sfx.PowerUp:
                    clip = MakeMelody("sfx_powerup", new float[] { 520f, 660f, 880f, 1100f }, 0.06f, 0.32f);
                    break;
                case Sfx.Hurt:
                    clip = MakeSweep("sfx_hurt", new float[] { 300f, 120f }, 0.12f, 0.35f, false);
                    break;
                case Sfx.Die:
                    clip = MakeMelody("sfx_die", new float[] { 520f, 420f, 320f, 200f, 120f }, 0.11f, 0.35f);
                    break;
                case Sfx.UiClick:
                    clip = MakeMelody("sfx_click", new float[] { 700f }, 0.035f, 0.22f);
                    break;
                case Sfx.Purchase:
                    clip = MakeMelody("sfx_purchase", new float[] { 660f, 880f, 1200f }, 0.06f, 0.30f);
                    break;
                case Sfx.Denied:
                    clip = MakeMelody("sfx_denied", new float[] { 220f, 180f }, 0.08f, 0.28f);
                    break;
                case Sfx.Victory:
                    clip = MakeMelody("sfx_victory", new float[] { 660f, 880f, 1100f, 1320f, 1760f }, 0.10f, 0.30f);
                    break;
                case Sfx.Defeat:
                    clip = MakeMelody("sfx_defeat", new float[] { 440f, 370f, 294f, 220f }, 0.14f, 0.28f);
                    break;
                case Sfx.Goal:
                    clip = MakeMelody("sfx_goal", new float[] { 880f, 1100f, 1320f }, 0.08f, 0.30f);
                    break;
                default:
                    clip = MakeMelody("sfx_wave", new float[] { 330f, 440f }, 0.08f, 0.28f);
                    break;
            }

            SfxClips[sfx] = clip;
            return clip;
        }

        private static AudioClip GetMusicClip(MusicMood mood)
        {
            AudioClip clip;
            if (MusicClips.TryGetValue(mood, out clip) && clip != null)
            {
                return clip;
            }

            float[] melody;
            float noteLength;
            switch (mood)
            {
                case MusicMood.Menu:
                    melody = new float[] { 261f, 329f, 392f, 523f, 392f, 329f, 293f, 349f, 440f, 523f, 440f, 349f, 329f, 293f, 261f, 196f };
                    noteLength = 0.26f;
                    break;
                case MusicMood.Boss:
                    melody = new float[] { 146f, 174f, 220f, 174f, 146f, 196f, 233f, 196f, 138f, 164f, 207f, 164f, 130f, 155f, 196f, 155f };
                    noteLength = 0.20f;
                    break;
                case MusicMood.Survival:
                    melody = new float[] { 220f, 262f, 330f, 392f, 330f, 262f, 196f, 247f, 294f, 370f, 294f, 247f, 220f, 277f, 330f, 415f };
                    noteLength = 0.19f;
                    break;
                case MusicMood.Speedrun:
                    melody = new float[] { 330f, 415f, 494f, 587f, 494f, 415f, 370f, 466f, 554f, 659f, 554f, 466f, 415f, 523f, 622f, 740f };
                    noteLength = 0.17f;
                    break;
                default:
                    melody = new float[] { 262f, 311f, 392f, 466f, 392f, 311f, 233f, 311f, 349f, 440f, 523f, 440f, 349f, 294f, 349f, 392f };
                    noteLength = 0.24f;
                    break;
            }

            clip = MakeMelody("music_" + mood, melody, noteLength, 0.20f);
            MusicClips[mood] = clip;
            return clip;
        }

        private static AudioClip MakeMelody(string name, float[] notes, float noteLength, float amplitude)
        {
            int samplesPerNote = Mathf.Max(16, Mathf.RoundToInt(SampleRate * noteLength));
            int total = samplesPerNote * notes.Length;
            float[] data = new float[total];
            for (int n = 0; n < notes.Length; n++)
            {
                float freq = notes[n];
                for (int i = 0; i < samplesPerNote; i++)
                {
                    float t = (float)i / SampleRate;
                    float phase = freq * t;
                    float square = (phase % 1f) < 0.5f ? 1f : -1f;
                    float triangle = 4f * Mathf.Abs((phase % 1f) - 0.5f) - 1f;
                    float envelope = Mathf.Clamp01(1f - (float)i / samplesPerNote * 0.55f);
                    data[n * samplesPerNote + i] = (square * 0.45f + triangle * 0.55f) * envelope * amplitude;
                }
            }
            return CreateClip(name, data);
        }

        private static AudioClip MakeSweep(string name, float[] freqs, float duration, float amplitude, bool rise)
        {
            int length = Mathf.Max(64, Mathf.RoundToInt(SampleRate * duration));
            float[] data = new float[length];
            float from = freqs[0];
            float to = freqs[freqs.Length - 1];
            float phase = 0f;
            for (int i = 0; i < length; i++)
            {
                float t = (float)i / length;
                float freq = Mathf.Lerp(from, to, rise ? t : t);
                phase += freq / SampleRate;
                float square = (phase % 1f) < 0.5f ? 1f : -1f;
                float envelope = Mathf.Clamp01(1f - t);
                data[i] = square * envelope * amplitude;
            }
            return CreateClip(name, data);
        }

        private static AudioClip MakeNoise(string name, float duration, float amplitude, float lowPassCut)
        {
            int length = Mathf.Max(64, Mathf.RoundToInt(SampleRate * duration));
            float[] data = new float[length];
            Random.State previous = Random.state;
            Random.InitState(name.GetHashCode());
            float filtered = 0f;
            float alpha = Mathf.Clamp01(lowPassCut / SampleRate);
            for (int i = 0; i < length; i++)
            {
                float sample = Random.Range(-1f, 1f);
                filtered += (sample - filtered) * alpha;
                float envelope = Mathf.Clamp01(1f - (float)i / length);
                data[i] = filtered * envelope * amplitude;
            }
            Random.state = previous;
            return CreateClip(name, data);
        }

        private static AudioClip CreateClip(string name, float[] data)
        {
            AudioClip clip = AudioClip.Create(name, data.Length, 1, SampleRate, false);
            clip.SetData(data, 0);
            return clip;
        }
    }
}
