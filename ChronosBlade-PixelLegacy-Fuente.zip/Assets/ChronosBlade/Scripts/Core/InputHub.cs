using UnityEngine;

namespace ChronosBlade
{
    /// <summary>
    /// Hub unico de entrada. Combina teclado (para pruebas en el editor) con los
    /// controles tactiles virtuales que construye UIFactory en pantalla Landscape.
    /// </summary>
    public class InputHub : MonoBehaviour
    {
        public static InputHub Instance { get; private set; }

        private float _stickX;
        private float _stickY;
        private bool _stickActive;
        private bool _buttonJumpHeld;
        private bool _buttonAttackHeld;

        private bool _jumpQueued;
        private bool _attackQueued;
        private bool _cancelQueued;
        private bool _advanceQueued;

        private float _keyboardX;
        private bool _keyJumpHeld;

        /// <summary>Eje horizontal combinado (-1 izquierda, +1 derecha).</summary>
        public float Horizontal
        {
            get
            {
                if (Mathf.Abs(_keyboardX) > 0.05f)
                {
                    return _keyboardX;
                }
                return _stickX;
            }
        }

        /// <summary>Eje vertical combinado (usado por el joystick para apuntar el ataque).</summary>
        public float Vertical
        {
            get { return _stickActive ? _stickY : 0f; }
        }

        /// <summary>Salto mantenido (para salto de altura variable).</summary>
        public bool JumpHeld
        {
            get { return _buttonJumpHeld || _keyJumpHeld; }
        }

        public bool AttackHeld
        {
            get { return _buttonAttackHeld || Input.GetKey(KeyCode.J) || Input.GetKey(KeyCode.K); }
        }

        public static InputHub Ensure()
        {
            if (Instance != null)
            {
                return Instance;
            }
            GameObject go = new GameObject("ChronosInput");
            Object.DontDestroyOnLoad(go);
            return go.AddComponent<InputHub>();
        }

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }

        private void Update()
        {
            // --- Teclado (pruebas en editor / escritorio) ---
            _keyboardX = 0f;
            if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
            {
                _keyboardX -= 1f;
            }
            if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
            {
                _keyboardX += 1f;
            }

            if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))
            {
                _keyJumpHeld = true;
            }
            else
            {
                _keyJumpHeld = false;
            }

            if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow))
            {
                QueueJump();
            }

            if (Input.GetKeyDown(KeyCode.J) || Input.GetKeyDown(KeyCode.K) || Input.GetKeyDown(KeyCode.Z)
                || Input.GetKeyDown(KeyCode.X) || Input.GetKey(KeyCode.LeftControl))
            {
                QueueAttack();
            }

            if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P))
            {
                _cancelQueued = true;
            }

            if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0)
                || (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began))
            {
                _advanceQueued = true;
            }
        }

        // ---------------- API para los botones tactiles ----------------
        public void SetStick(Vector2 value)
        {
            _stickX = Mathf.Clamp(value.x, -1f, 1f);
            _stickY = Mathf.Clamp(value.y, -1f, 1f);
            _stickActive = value.sqrMagnitude > 0.01f;
        }

        public void SetJumpHeld(bool held)
        {
            _buttonJumpHeld = held;
            if (held)
            {
                _jumpQueued = true;
            }
        }

        public void SetAttackHeld(bool held)
        {
            _buttonAttackHeld = held;
            if (held)
            {
                _attackQueued = true;
            }
        }

        public void QueueJump()
        {
            _jumpQueued = true;
        }

        public void QueueAttack()
        {
            _attackQueued = true;
        }

        // ---------------- Consumidores ----------------
        public bool ConsumeJump()
        {
            bool value = _jumpQueued;
            _jumpQueued = false;
            return value;
        }

        public bool ConsumeAttack()
        {
            bool value = _attackQueued;
            _attackQueued = false;
            return value;
        }

        public bool ConsumeCancel()
        {
            bool value = _cancelQueued;
            _cancelQueued = false;
            return value;
        }

        public bool ConsumeAdvance()
        {
            bool value = _advanceQueued;
            _advanceQueued = false;
            return value;
        }

        public void ClearAll()
        {
            _jumpQueued = false;
            _attackQueued = false;
            _cancelQueued = false;
            _advanceQueued = false;
            _stickX = 0f;
            _stickY = 0f;
            _stickActive = false;
            _buttonJumpHeld = false;
            _buttonAttackHeld = false;
        }
    }
}
