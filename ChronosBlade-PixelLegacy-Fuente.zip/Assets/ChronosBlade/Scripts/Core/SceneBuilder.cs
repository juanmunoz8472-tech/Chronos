using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace ChronosBlade
{
    /// <summary>
    /// Ensambla TODO el juego por codigo: menu principal, niveles de historia,
    /// arena de supervivencia, pista de speedrun, HUD, controles tactiles y
    /// pantallas de resultado. No requiere prefabs ni escenas configuradas a mano:
    /// al presionar Play el juego se construye solo (ver RuntimeBootstrap).
    /// </summary>
    public static class SceneBuilder
    {
        private static GameObject _gameRoot;
        private static GameObject _menuRoot;
        private static GameObject _systemsRoot;
        private static Canvas _gameCanvas;
        private static bool _bootstrapped;

        public static Canvas FindGameCanvas()
        {
            return _gameCanvas;
        }

        // ------------------------------------------------------------------
        // ARRANQUE
        // ------------------------------------------------------------------
        public static void RunBootstrap()
        {
            if (_bootstrapped)
            {
                return;
            }
            _bootstrapped = true;

            Application.targetFrameRate = 60;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            InputHub.Ensure();

            if (_systemsRoot == null)
            {
                _systemsRoot = new GameObject("ChronosSystems");
                Object.DontDestroyOnLoad(_systemsRoot);
            }
            AudioFx.Init(_systemsRoot);

            SaveSystem.Load();
            EnsureCamera();
            LoadMainMenu();
        }

        private static Camera EnsureCamera()
        {
            Camera camera = Camera.main;
            if (camera == null)
            {
                GameObject cameraGo = new GameObject("Main Camera");
                cameraGo.tag = "MainCamera";
                camera = cameraGo.AddComponent<Camera>();
            }
            camera.orthographic = true;
            camera.orthographicSize = 7f;
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(0.05f, 0.06f, 0.11f, 1f);
            camera.transform.rotation = Quaternion.identity;
            camera.transform.position = new Vector3(0f, 3f, -10f);

            if (Object.FindObjectOfType<AudioListener>() == null)
            {
                camera.gameObject.AddComponent<AudioListener>();
            }

            if (camera.GetComponent<CameraFollow>() == null)
            {
                camera.gameObject.AddComponent<CameraFollow>();
            }
            return camera;
        }

        private static void SetSkyGradient(Camera camera, Color top, Color bottom)
        {
            Transform existing = camera.transform.Find("SkyGradient");
            if (existing != null)
            {
                Object.Destroy(existing.gameObject);
            }

            GameObject go = new GameObject("SkyGradient");
            go.transform.SetParent(camera.transform, false);
            go.transform.localPosition = new Vector3(0f, 0f, 9f);
            go.transform.localScale = new Vector3(34f, 17f, 1f);
            SpriteRenderer renderer = go.AddComponent<SpriteRenderer>();
            renderer.sprite = SpriteFactory.Gradient(top, bottom);
            renderer.sortingOrder = -100;
        }

        // ------------------------------------------------------------------
        // MENU PRINCIPAL
        // ------------------------------------------------------------------
        public static void LoadMainMenu()
        {
            Time.timeScale = 1f;
            DestroyGame();

            Camera camera = EnsureCamera();
            camera.GetComponent<CameraFollow>().Target = null;
            camera.transform.position = new Vector3(0f, 4f, -10f);
            SetSkyGradient(camera, new Color(0.16f, 0.12f, 0.34f), new Color(0.05f, 0.05f, 0.12f));
            AudioFx.PlayMusic(MusicMood.Menu);

            if (_menuRoot != null)
            {
                Object.Destroy(_menuRoot);
                _menuRoot = null;
            }

            Canvas canvas = UIFactory.CreateCanvas("MenuCanvas", 40);
            _menuRoot = canvas.gameObject;

            DestroyBackdrop();
            BackgroundScroller.Create(camera, GroundTheme.Void, -60f, 60f, 4f);

            RectTransform screen = UIFactory.CreateRect(canvas.transform, "Menu", Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);

            UIFactory.CreateText(screen, "Title", ChronosCatalog.GameTitle, 66, TextAnchor.UpperCenter, new Color(1f, 0.88f, 0.55f),
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(1100f, 80f), new Vector2(0f, -34f));

            UIFactory.CreateText(screen, "Tagline", "El tiempo se defiende con filo. Plataformas de accion 2D en Pixel Art.",
                24, TextAnchor.UpperCenter, new Color(0.82f, 0.86f, 1f),
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(1100f, 34f), new Vector2(0f, -114f));

            int storyLevel = Mathf.Clamp(SaveSystem.StoryProgress, 1, ChronosCatalog.StoryLevelCount);
            float buttonY = -180f;
            UIFactory.CreateButton(screen, "Story", "MODO HISTORIA   -   NIVEL " + storyLevel, 30, new Color(0.85f, 0.55f, 0.2f, 1f),
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(620f, 82f), new Vector2(0f, buttonY),
                delegate
                {
                    AudioFx.Play(Sfx.UiClick);
                    StartStory(Mathf.Clamp(SaveSystem.StoryProgress, 1, ChronosCatalog.StoryLevelCount));
                });

            UIFactory.CreateButton(screen, "Survival", "MODO SUPERVIVENCIA (ARCADE)", 30, new Color(0.7f, 0.3f, 0.3f, 1f),
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(620f, 82f), new Vector2(0f, buttonY - 96f),
                delegate
                {
                    AudioFx.Play(Sfx.UiClick);
                    StartSurvival();
                });

            UIFactory.CreateButton(screen, "Speedrun", "MODO SPEEDRUN (CONTRARRELOJ)", 30, new Color(0.35f, 0.7f, 0.8f, 1f),
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(620f, 82f), new Vector2(0f, buttonY - 192f),
                delegate
                {
                    AudioFx.Play(Sfx.UiClick);
                    StartSpeedrun(1);
                });

            UIFactory.CreateButton(screen, "Shop", "TIENDA Y HEROES", 30, new Color(0.55f, 0.85f, 0.4f, 1f),
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(620f, 82f), new Vector2(0f, buttonY - 288f),
                delegate
                {
                    AudioFx.Play(Sfx.UiClick);
                    PixelShopManager.Open();
                });

            // Panel de progreso (derecha).
            Image recordPanel = UIFactory.CreatePanel(screen, "Records", UIFactory.PanelColor,
                new Vector2(1f, 0.5f), new Vector2(1f, 0.5f), new Vector2(1f, 0.5f), new Vector2(392f, 300f), new Vector2(-26f, 10f));

            CharacterDefinition selected = CharacterSelection.Selected;
            WeaponDefinition weapon = ChronosCatalog.GetWeapon(SaveSystem.SelectedWeaponId);
            int weaponLevel = Mathf.Max(1, SaveSystem.GetWeaponLevel(weapon.Id));

            UIFactory.CreateImage(recordPanel.transform, "HeroPreview", SpriteFactory.GetHero(selected.PaletteIndex, HeroAnim.Idle, 0), Color.white,
                new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(96f, 96f), new Vector2(18f, -16f));
            UIFactory.CreateText(recordPanel.transform, "HeroName", selected.DisplayName + "\n" + selected.Title, 20, TextAnchor.UpperLeft, UIFactory.Accent,
                new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(270f, 66f), new Vector2(122f, -22f));

            UIFactory.CreateText(recordPanel.transform, "Loadout",
                "ARMA: " + weapon.DisplayName + " LV." + weaponLevel
                + "\nMONEDAS: " + SaveSystem.Coins
                + "\nGEMAS: " + SaveSystem.Gems
                + "\nRECORD SURVIVAL: " + SaveSystem.BestSurvivalKills + " BAJAS"
                + "\nRECORD SPEEDRUN: " + SaveSystem.FormatSpeedrun(SaveSystem.BestSpeedrunTime),
                21, TextAnchor.UpperLeft, new Color(0.86f, 0.9f, 1f),
                new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(356f, 190f), new Vector2(20f, -122f));

            // Botones de sistema (abajo-derecha).
            UIFactory.CreateButton(screen, "Music", "MUSICA ON/OFF", 20, UIFactory.PanelLight,
                new Vector2(1f, 0f), new Vector2(1f, 0f), new Vector2(1f, 0f), new Vector2(280f, 56f), new Vector2(-26f, 24f),
                delegate
                {
                    AudioFx.ToggleMusic();
                    AudioFx.Play(Sfx.UiClick);
                });

            UIFactory.CreateButton(screen, "ResetData", "REINICIAR DATOS", 20, new Color(0.5f, 0.24f, 0.24f, 1f),
                new Vector2(0f, 0f), new Vector2(0f, 0f), new Vector2(0f, 0f), new Vector2(280f, 56f), new Vector2(26f, 24f),
                delegate
                {
                    AudioFx.Play(Sfx.UiClick);
                    ShowResetConfirm(canvas);
                });

            UIFactory.CreateText(screen, "Controls",
                "[TECLADO] A/D mover - ESPACIO saltar (x2) - J atacar - 1..4 potenciadores - ESC pausa\n[TACTIL] Joystick izquierdo - Botones SALTO/ATACAR a la derecha - Toca el cuadro de dialogo para avanzar",
                19, TextAnchor.LowerLeft, new Color(1f, 1f, 1f, 0.6f),
                new Vector2(0f, 0f), new Vector2(0f, 0f), new Vector2(0f, 0f), new Vector2(900f, 60f), new Vector2(26f, 92f));
        }

        private static void ShowResetConfirm(Canvas canvas)
        {
            Image dim = UIFactory.CreatePanel(canvas.transform, "ResetConfirm", new Color(0f, 0f, 0f, 0.8f),
                Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            dim.raycastTarget = true;

            Image card = UIFactory.CreatePanel(dim.transform, "Card", UIFactory.PanelColor,
                new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(680f, 320f), Vector2.zero);

            UIFactory.CreateText(card.transform, "Title", "¿BORRAR TODO EL PROGRESO?", 34, TextAnchor.UpperCenter, UIFactory.AccentRed,
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(600f, 44f), new Vector2(0f, -26f));

            UIFactory.CreateText(card.transform, "Body",
                "Se perderan monedas, gemas, heroes, armas y records.\nEsta accion no se puede deshacer.",
                22, TextAnchor.UpperCenter, new Color(0.9f, 0.9f, 0.95f),
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(600f, 80f), new Vector2(0f, -90f));

            UIFactory.CreateButton(card.transform, "Yes", "SI, BORRAR", 24, UIFactory.AccentRed,
                new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(260f, 64f), new Vector2(-150f, 34f),
                delegate
                {
                    SaveSystem.ResetAll();
                    AudioFx.Play(Sfx.Denied);
                    LoadMainMenu();
                });

            UIFactory.CreateButton(card.transform, "No", "CANCELAR", 24, UIFactory.PanelLight,
                new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(260f, 64f), new Vector2(150f, 34f),
                delegate
                {
                    AudioFx.Play(Sfx.UiClick);
                    Object.Destroy(dim.gameObject);
                });
        }

        // ------------------------------------------------------------------
        // PARTIDA
        // ------------------------------------------------------------------
        public static void StartStory(int level)
        {
            StartGame(GameMode.Story, Mathf.Clamp(level, 1, ChronosCatalog.StoryLevelCount));
        }

        public static void StartSurvival()
        {
            StartGame(GameMode.Survival, 1);
        }

        public static void StartSpeedrun(int track)
        {
            StartGame(GameMode.Speedrun, Mathf.Clamp(track, 1, 3));
        }

        private class LevelLayout
        {
            public GroundTheme Theme = GroundTheme.Grass;
            public Vector3 Spawn = new Vector3(0f, 1.4f, 0f);
            public float MinX = -20f;
            public float MaxX = 80f;
            public float MinY = -10f;
            public float MaxY = 12f;
            public float KillY = -12f;
            public float ArenaMinX = -14f;
            public float ArenaMaxX = 14f;
            public float ArenaFloorY = 0f;
            public bool IsArena;
        }

        private static void DestroyBackdrop()
        {
            BackgroundScroller backdrop = BackgroundScroller.Current;
            if (backdrop != null)
            {
                Object.Destroy(backdrop.gameObject);
            }
        }

        private static void DestroyGame()
        {
            if (_gameCanvas != null)
            {
                Object.Destroy(_gameCanvas.gameObject);
                _gameCanvas = null;
            }
            if (_gameRoot != null)
            {
                Object.Destroy(_gameRoot);
                _gameRoot = null;
            }
            DialogueManager instance = DialogueManager.Instance;
            if (instance != null)
            {
                Object.Destroy(instance.gameObject);
            }
            GameModeManager modeInstance = Object.FindObjectOfType<GameModeManager>();
            if (modeInstance != null)
            {
                Object.Destroy(modeInstance.gameObject);
            }
        }

        private static void StartGame(GameMode mode, int levelParameter)
        {
            Time.timeScale = 1f;

            if (_menuRoot != null)
            {
                Object.Destroy(_menuRoot);
                _menuRoot = null;
            }
            if (PixelShopManager.Instance != null)
            {
                Object.Destroy(PixelShopManager.Instance.gameObject);
            }
            DestroyGame();

            Camera camera = EnsureCamera();
            _gameRoot = new GameObject("ChronosGame");

            Transform world = new GameObject("World").transform;
            world.SetParent(_gameRoot.transform, false);

            LevelLayout layout = new LevelLayout();
            switch (mode)
            {
                case GameMode.Survival:
                    BuildSurvivalArena(world, layout);
                    SetSkyGradient(camera, new Color(0.22f, 0.16f, 0.30f), new Color(0.06f, 0.05f, 0.12f));
                    break;
                case GameMode.Speedrun:
                    BuildSpeedrunTrack(world, layout, levelParameter);
                    SetSkyGradient(camera, new Color(0.18f, 0.34f, 0.48f), new Color(0.05f, 0.09f, 0.16f));
                    break;
                default:
                    BuildStoryLevel(world, layout, levelParameter);
                    SetSkyGradient(camera, new Color(0.20f, 0.30f, 0.46f), new Color(0.06f, 0.08f, 0.14f));
                    break;
            }

            DestroyBackdrop();
            BackgroundScroller.Create(camera, layout.Theme, layout.MinX, layout.MaxX, 0f);

            GameSession session = GameSession.Create(mode, levelParameter);
            PixelPlayerController player = CreatePlayer(layout.Spawn, session);

            GameObject rules = new GameObject("LevelRules");
            rules.transform.SetParent(_gameRoot.transform, false);
            LevelBounds bounds = rules.AddComponent<LevelBounds>();
            bounds.MinX = layout.MinX + 0.4f;
            bounds.MaxX = layout.MaxX - 0.4f;
            bounds.KillY = layout.KillY;
            bounds.Player = player;

            CameraFollow follow = camera.GetComponent<CameraFollow>();
            follow.Target = player.transform;
            follow.LockY = false;
            float halfWidth = 12.5f;
            float cameraPad = 6f;
            float camMinX = layout.MinX + halfWidth - cameraPad;
            float camMaxX = layout.MaxX + cameraPad - halfWidth;
            if (camMaxX < camMinX)
            {
                float middle = (layout.MinX + layout.MaxX) * 0.5f;
                camMinX = middle;
                camMaxX = middle;
            }
            float camMinY = layout.MinY + 3.5f;
            float camMaxY = Mathf.Max(camMinY, layout.MaxY - 5.5f);
            follow.SetBounds(camMinX, camMaxX, camMinY, camMaxY);
            follow.SnapToTarget();

            _gameCanvas = UIFactory.CreateCanvas("GameCanvas", 20);
            GameHud hud = UIFactory.BuildGameHud(_gameCanvas, mode);
            hud.Bind(player);
            UIFactory.BuildTouchControls(_gameCanvas);
            DialogueManager.Create(_gameCanvas, player);

            GameObject modeGo = new GameObject("GameModeManager");
            modeGo.transform.SetParent(_gameRoot.transform, false);
            GameModeManager manager = modeGo.AddComponent<GameModeManager>();
            manager.ArenaMinX = layout.ArenaMinX;
            manager.ArenaMaxX = layout.ArenaMaxX;
            manager.ArenaFloorY = layout.ArenaFloorY;
            manager.Init(mode, levelParameter, player, hud);

            if (mode == GameMode.Speedrun)
            {
                AudioFx.PlayMusic(MusicMood.Speedrun);
            }
            else if (mode == GameMode.Survival)
            {
                AudioFx.PlayMusic(MusicMood.Survival);
            }
            else
            {
                AudioFx.PlayMusic(levelParameter >= ChronosCatalog.StoryLevelCount ? MusicMood.Boss : MusicMood.Story);
            }
        }

        private static PixelPlayerController CreatePlayer(Vector3 spawn, GameSession session)
        {
            GameObject go = new GameObject("Player");
            go.transform.SetParent(_gameRoot.transform, false);
            go.transform.position = spawn;

            SpriteRenderer renderer = go.AddComponent<SpriteRenderer>();
            renderer.sortingOrder = 20;

            BoxCollider2D collider = go.AddComponent<BoxCollider2D>();
            collider.size = new Vector2(0.62f, 1.5f);
            collider.offset = new Vector2(0f, 0.75f);

            Rigidbody2D body = go.AddComponent<Rigidbody2D>();
            body.gravityScale = 3.1f;
            body.freezeRotation = true;
            body.interpolation = RigidbodyInterpolation2D.Interpolate;

            go.AddComponent<Animator>();
            PixelPlayerController player = go.AddComponent<PixelPlayerController>();
            player.Init(session);
            return player;
        }

        // ------------------------------------------------------------------
        // CONSTRUCCION DE NIVELES
        // ------------------------------------------------------------------
        private static GameObject CreateSolid(Transform parent, string name, float startX, float endX, float topY, float height, GroundTheme theme)
        {
            float width = Mathf.Max(1f, endX - startX);
            GameObject go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.position = new Vector3((startX + endX) * 0.5f, topY - height * 0.5f, 0f);

            BoxCollider2D collider = go.AddComponent<BoxCollider2D>();
            collider.size = new Vector2(width, height);

            int tilesX = Mathf.CeilToInt(width);
            int tilesY = Mathf.CeilToInt(height);
            for (int tx = 0; tx < tilesX; tx++)
            {
                for (int ty = 0; ty < tilesY; ty++)
                {
                    GameObject tile = new GameObject("tile");
                    tile.transform.SetParent(go.transform, false);
                    tile.transform.localPosition = new Vector3(-width * 0.5f + tx + 0.5f, -height * 0.5f + ty + 0.5f, 0f);
                    SpriteRenderer renderer = tile.AddComponent<SpriteRenderer>();
                    renderer.sprite = SpriteFactory.Ground(theme, (tx + ty * 3) % 2);
                    renderer.sortingOrder = 5;
                }
            }
            return go;
        }

        private static GameObject CreatePlatform(Transform parent, float centerX, float topY, float width)
        {
            GameObject go = new GameObject("Platform");
            go.transform.SetParent(parent, false);
            go.transform.position = new Vector3(centerX, topY - 0.5f, 0f);

            BoxCollider2D collider = go.AddComponent<BoxCollider2D>();
            collider.size = new Vector2(width, 1f);

            int tiles = Mathf.Max(1, Mathf.CeilToInt(width));
            for (int i = 0; i < tiles; i++)
            {
                GameObject tile = new GameObject("tile");
                tile.transform.SetParent(go.transform, false);
                tile.transform.localPosition = new Vector3(-width * 0.5f + i + 0.5f, 0f, 0f);
                SpriteRenderer renderer = tile.AddComponent<SpriteRenderer>();
                renderer.sprite = SpriteFactory.Get(PixelArtType.Platform, 0);
                renderer.sortingOrder = 6;
            }
            return go;
        }

        private static GameObject CreateMovingPlatform(Transform parent, Vector2 pointA, Vector2 pointB, float width)
        {
            GameObject go = new GameObject("MovingPlatform");
            go.transform.SetParent(parent, false);
            go.transform.position = pointA;

            BoxCollider2D collider = go.AddComponent<BoxCollider2D>();
            collider.size = new Vector2(width, 1f);

            Rigidbody2D body = go.AddComponent<Rigidbody2D>();
            body.bodyType = RigidbodyType2D.Kinematic;
            body.useFullKinematicContacts = true;

            int tiles = Mathf.Max(1, Mathf.CeilToInt(width));
            for (int i = 0; i < tiles; i++)
            {
                GameObject tile = new GameObject("tile");
                tile.transform.SetParent(go.transform, false);
                tile.transform.localPosition = new Vector3(-width * 0.5f + i + 0.5f, 0f, 0f);
                SpriteRenderer renderer = tile.AddComponent<SpriteRenderer>();
                renderer.sprite = SpriteFactory.Get(PixelArtType.Platform, 0);
                renderer.sortingOrder = 7;
            }

            MovingPlatform platform = go.AddComponent<MovingPlatform>();
            platform.PointA = pointA;
            platform.PointB = pointB;
            platform.Speed = 2.4f;
            return go;
        }

        private static GameObject CreateSpikes(Transform parent, float x, float topY, int count)
        {
            GameObject go = new GameObject("Spikes");
            go.transform.SetParent(parent, false);
            go.transform.position = new Vector3(x + (count - 1) * 0.5f, topY + 0.3f, 0f);

            BoxCollider2D collider = go.AddComponent<BoxCollider2D>();
            collider.isTrigger = true;
            collider.size = new Vector2(count, 0.55f);
            collider.offset = Vector2.zero;

            StaticHazard hazard = go.AddComponent<StaticHazard>();
            hazard.Damage = 15;

            for (int i = 0; i < count; i++)
            {
                GameObject spike = new GameObject("spike");
                spike.transform.SetParent(go.transform, false);
                spike.transform.localPosition = new Vector3(-(count - 1) * 0.5f + i, 0f, 0f);
                SpriteRenderer renderer = spike.AddComponent<SpriteRenderer>();
                renderer.sprite = SpriteFactory.Get(PixelArtType.Spike, 0);
                renderer.sortingOrder = 8;
            }
            return go;
        }

        private static void CreateCoinRow(Transform parent, float startX, float y, int count, float spacing, int value)
        {
            for (int i = 0; i < count; i++)
            {
                GameObject go = new GameObject("Coin");
                go.transform.SetParent(parent, false);
                go.transform.position = new Vector3(startX + i * spacing, y, 0f);
                SpriteRenderer renderer = go.AddComponent<SpriteRenderer>();
                renderer.sprite = SpriteFactory.Get(PixelArtType.Coin, 0);
                renderer.sortingOrder = 16;

                BoxCollider2D collider = go.AddComponent<BoxCollider2D>();
                collider.isTrigger = true;
                collider.size = new Vector2(0.8f, 0.8f);

                go.AddComponent<CoinPickup>().Value = value;
            }
        }

        private static void CreateGem(Transform parent, float x, float y)
        {
            GameObject go = new GameObject("Gem");
            go.transform.SetParent(parent, false);
            go.transform.position = new Vector3(x, y, 0f);
            SpriteRenderer renderer = go.AddComponent<SpriteRenderer>();
            renderer.sprite = SpriteFactory.Get(PixelArtType.Gem, 0);
            renderer.sortingOrder = 17;

            BoxCollider2D collider = go.AddComponent<BoxCollider2D>();
            collider.isTrigger = true;
            collider.size = new Vector2(0.9f, 1.1f);

            go.AddComponent<GemPickup>().Value = 1;
        }

        private static void CreateHeart(Transform parent, float x, float y)
        {
            GameObject go = new GameObject("Heart");
            go.transform.SetParent(parent, false);
            go.transform.position = new Vector3(x, y, 0f);
            SpriteRenderer renderer = go.AddComponent<SpriteRenderer>();
            renderer.sprite = SpriteFactory.Get(PixelArtType.Heart, 0);
            renderer.sortingOrder = 17;

            BoxCollider2D collider = go.AddComponent<BoxCollider2D>();
            collider.isTrigger = true;
            collider.size = new Vector2(0.9f, 0.9f);

            go.AddComponent<HeartPickup>().Value = 25;
        }

        private static void CreateChest(Transform parent, float x, float y, int coins, int gems, string powerUpKey)
        {
            GameObject go = new GameObject("Chest");
            go.transform.SetParent(parent, false);
            go.transform.position = new Vector3(x, y + 0.4f, 0f);
            SpriteRenderer renderer = go.AddComponent<SpriteRenderer>();
            renderer.sprite = SpriteFactory.Get(PixelArtType.Chest, 0);
            renderer.sortingOrder = 15;

            BoxCollider2D collider = go.AddComponent<BoxCollider2D>();
            collider.isTrigger = true;
            collider.size = new Vector2(1.1f, 1.1f);

            LevelChest chest = go.AddComponent<LevelChest>();
            chest.CoinReward = coins;
            chest.GemReward = gems;
            chest.PowerUpKey = powerUpKey;
        }

        private static void CreateCheckpoint(Transform parent, float x, float y)
        {
            GameObject go = new GameObject("Checkpoint");
            go.transform.SetParent(parent, false);
            go.transform.position = new Vector3(x, y + 0.9f, 0f);
            SpriteRenderer renderer = go.AddComponent<SpriteRenderer>();
            renderer.sprite = SpriteFactory.Get(PixelArtType.Portal, 0);
            renderer.sortingOrder = 12;
            go.transform.localScale = new Vector3(1.4f, 1.4f, 1f);

            BoxCollider2D collider = go.AddComponent<BoxCollider2D>();
            collider.isTrigger = true;
            collider.size = new Vector2(1.2f, 1.8f);

            go.AddComponent<Checkpoint>();
        }

        private static void CreateGoalPortal(Transform parent, float x, float y)
        {
            GameObject go = new GameObject("GoalPortal");
            go.transform.SetParent(parent, false);
            go.transform.position = new Vector3(x, y + 1.4f, 0f);
            SpriteRenderer renderer = go.AddComponent<SpriteRenderer>();
            renderer.sprite = SpriteFactory.Get(PixelArtType.Portal, 0);
            renderer.sortingOrder = 12;
            go.transform.localScale = new Vector3(2.6f, 2.6f, 1f);

            BoxCollider2D collider = go.AddComponent<BoxCollider2D>();
            collider.isTrigger = true;
            collider.size = new Vector2(1.7f, 2.4f);

            go.AddComponent<GoalPortal>();
        }

        private static void CreateSpeedPad(Transform parent, float x, float y, float direction, float speed)
        {
            GameObject go = new GameObject("SpeedPad");
            go.transform.SetParent(parent, false);
            go.transform.position = new Vector3(x, y + 0.25f, 0f);
            SpriteRenderer renderer = go.AddComponent<SpriteRenderer>();
            renderer.sprite = SpriteFactory.Get(PixelArtType.Platform, 0);
            renderer.color = new Color(0.55f, 0.9f, 1f, 1f);
            renderer.sortingOrder = 9;

            BoxCollider2D collider = go.AddComponent<BoxCollider2D>();
            collider.isTrigger = true;
            collider.size = new Vector2(1.4f, 0.7f);

            SpeedPad pad = go.AddComponent<SpeedPad>();
            pad.Direction = direction;
            pad.BoostSpeed = speed;
        }

        private static Transform[] CreatePatrol(Transform parent, Vector2 a, Vector2 b)
        {
            GameObject root = new GameObject("Patrol");
            root.transform.SetParent(parent, false);

            GameObject pointA = new GameObject("A");
            pointA.transform.SetParent(root.transform, false);
            pointA.transform.position = a;

            GameObject pointB = new GameObject("B");
            pointB.transform.SetParent(root.transform, false);
            pointB.transform.position = b;

            return new Transform[] { pointA.transform, pointB.transform };
        }

        private static void CreateEnemy(Transform parent, EnemySpecies species, float x, float y, int tier, float patrolA, float patrolB)
        {
            PixelEnemyAI enemy = PixelEnemyAI.Spawn(species, new Vector2(x, y), null, tier, 1f);
            enemy.transform.SetParent(parent, true);
            if (Mathf.Abs(patrolB - patrolA) > 0.2f)
            {
                enemy.SetPatrolPoints(CreatePatrol(parent, new Vector2(patrolA, y), new Vector2(patrolB, y)));
            }
        }

        // ---------------- MODO HISTORIA ----------------
        private static void BuildStoryLevel(Transform world, LevelLayout layout, int level)
        {
            switch (level)
            {
                case 2:
                    BuildStoryLevel2(world, layout);
                    break;
                case 3:
                    BuildStoryLevel3(world, layout);
                    break;
                case 4:
                    BuildStoryLevel4(world, layout);
                    break;
                case 5:
                    BuildStoryLevel5(world, layout);
                    break;
                default:
                    BuildStoryLevel1(world, layout);
                    break;
            }
        }

        private static void BuildStoryLevel1(Transform world, LevelLayout layout)
        {
            layout.Theme = GroundTheme.Grass;
            layout.Spawn = new Vector3(2f, 1.5f, 0f);
            layout.MinX = -4f;
            layout.MaxX = 74f;
            layout.MaxY = 10f;
            layout.KillY = -10f;

            CreateSolid(world, "Ground", -2f, 22f, 0f, 4f, GroundTheme.Grass);
            CreateSolid(world, "GroundB", 27f, 48f, 0f, 4f, GroundTheme.Grass);
            CreateSolid(world, "GroundC", 53f, 74f, 0f, 4f, GroundTheme.Grass);
            CreatePlatform(world, 23.5f, 1.6f, 3f);
            CreatePlatform(world, 50.5f, 2.4f, 3f);

            CreateCoinRow(world, 6f, 1.4f, 4, 1.2f, 5);
            CreateCoinRow(world, 30f, 1.4f, 5, 1.2f, 5);
            CreateCoinRow(world, 56f, 1.4f, 4, 1.2f, 5);
            CreateGem(world, 23.5f, 3.2f);
            CreateHeart(world, 40f, 1.4f);

            CreateSpikes(world, 36f, 0f, 2);
            CreateChest(world, 44f, 0f, 90, 1, "tonic");
            CreateCheckpoint(world, 29f, 0f);

            CreateEnemy(world, EnemySpecies.Trashling, 14f, 1.2f, 0, 10f, 20f);
            CreateEnemy(world, EnemySpecies.Trashling, 33f, 1.2f, 0, 30f, 42f);
            CreateEnemy(world, EnemySpecies.Trashling, 60f, 1.2f, 0, 56f, 68f);

            CreateGoalPortal(world, 70f, 0f);
        }

        private static void BuildStoryLevel2(Transform world, LevelLayout layout)
        {
            layout.Theme = GroundTheme.Rust;
            layout.Spawn = new Vector3(2f, 1.5f, 0f);
            layout.MinX = -4f;
            layout.MaxX = 108f;
            layout.MaxY = 14f;
            layout.KillY = -12f;

            CreateSolid(world, "Ground", -2f, 20f, 0f, 4f, GroundTheme.Rust);
            CreateSolid(world, "GroundB", 25f, 40f, 0f, 4f, GroundTheme.Rust);
            CreateSolid(world, "GroundC", 52f, 74f, 0f, 4f, GroundTheme.Rust);
            CreateSolid(world, "GroundD", 80f, 108f, 0f, 4f, GroundTheme.Rust);
            CreatePlatform(world, 45f, 3.2f, 4f);
            CreateMovingPlatform(world, new Vector2(42f, 2.6f), new Vector2(50f, 2.6f), 3f);
            CreatePlatform(world, 22.5f, 2.0f, 3f);
            CreatePlatform(world, 76.5f, 3.6f, 3f);

            CreateCoinRow(world, 6f, 1.4f, 5, 1.2f, 5);
            CreateCoinRow(world, 44f, 4.6f, 3, 1.2f, 5);
            CreateCoinRow(world, 58f, 1.4f, 5, 1.2f, 5);
            CreateCoinRow(world, 86f, 1.4f, 5, 1.2f, 5);
            CreateGem(world, 50f, 3.4f);
            CreateGem(world, 76.5f, 4.8f);
            CreateHeart(world, 66f, 1.4f);

            CreateSpikes(world, 30f, 0f, 3);
            CreateSpikes(world, 92f, 0f, 2);
            CreateChest(world, 36f, 0f, 130, 1, "magnet");
            CreateCheckpoint(world, 27f, 0f);
            CreateCheckpoint(world, 82f, 0f);

            CreateEnemy(world, EnemySpecies.Trashling, 12f, 1.2f, 1, 8f, 18f);
            CreateEnemy(world, EnemySpecies.Trashling, 34f, 1.2f, 1, 28f, 38f);
            CreateEnemy(world, EnemySpecies.Bat, 45f, 6.5f, 1, 40f, 50f);
            CreateEnemy(world, EnemySpecies.Trashling, 62f, 1.2f, 1, 56f, 70f);
            CreateEnemy(world, EnemySpecies.Bat, 88f, 7f, 1, 84f, 96f);

            CreateGoalPortal(world, 104f, 0f);
        }

        private static void BuildStoryLevel3(Transform world, LevelLayout layout)
        {
            layout.Theme = GroundTheme.Grass;
            layout.Spawn = new Vector3(2f, 1.5f, 0f);
            layout.MinX = -4f;
            layout.MaxX = 96f;
            layout.MaxY = 30f;
            layout.KillY = -10f;

            CreateSolid(world, "Ground", -2f, 18f, 0f, 4f, GroundTheme.Grass);
            CreatePlatform(world, 24f, 3f, 4f);
            CreatePlatform(world, 31f, 6f, 4f);
            CreatePlatform(world, 38f, 9f, 4f);
            CreatePlatform(world, 45f, 12f, 4f);
            CreatePlatform(world, 52f, 9f, 4f);
            CreatePlatform(world, 59f, 6f, 4f);
            CreatePlatform(world, 66f, 3f, 4f);
            CreateSolid(world, "GroundB", 70f, 96f, 0f, 4f, GroundTheme.Grass);
            CreateMovingPlatform(world, new Vector2(46f, 15f), new Vector2(56f, 15f), 3f);

            CreateCoinRow(world, 22f, 4.4f, 3, 1.1f, 5);
            CreateCoinRow(world, 30f, 7.4f, 3, 1.1f, 5);
            CreateCoinRow(world, 44f, 13.4f, 3, 1.1f, 5);
            CreateCoinRow(world, 74f, 1.4f, 5, 1.2f, 5);
            CreateGem(world, 52f, 10.6f);
            CreateGem(world, 62f, 7.6f);
            CreateHeart(world, 36f, 10.4f);

            CreateChest(world, 84f, 0f, 160, 2, "shield");
            CreateCheckpoint(world, 45f, 12f);
            CreateCheckpoint(world, 72f, 0f);

            CreateEnemy(world, EnemySpecies.Bat, 28f, 5.5f, 2, 22f, 34f);
            CreateEnemy(world, EnemySpecies.Bat, 42f, 8.5f, 2, 36f, 48f);
            CreateEnemy(world, EnemySpecies.Bat, 56f, 11.5f, 2, 50f, 62f);
            CreateEnemy(world, EnemySpecies.Trashling, 78f, 1.2f, 2, 72f, 90f);
            CreateEnemy(world, EnemySpecies.Trashling, 88f, 1.2f, 2, 80f, 94f);

            CreateGoalPortal(world, 92f, 0f);
        }

        private static void BuildStoryLevel4(Transform world, LevelLayout layout)
        {
            layout.Theme = GroundTheme.Rust;
            layout.Spawn = new Vector3(2f, 1.5f, 0f);
            layout.MinX = -4f;
            layout.MaxX = 80f;
            layout.MaxY = 38f;
            layout.KillY = -10f;

            CreateSolid(world, "Ground", -2f, 20f, 0f, 4f, GroundTheme.Rust);
            CreatePlatform(world, 26f, 4f, 5f);
            CreatePlatform(world, 34f, 8f, 5f);
            CreatePlatform(world, 26f, 12f, 5f);
            CreatePlatform(world, 18f, 16f, 5f);
            CreatePlatform(world, 26f, 20f, 5f);
            CreatePlatform(world, 36f, 20f, 9f);
            CreatePlatform(world, 48f, 16f, 5f);
            CreatePlatform(world, 56f, 12f, 5f);
            CreateSolid(world, "GroundB", 60f, 80f, 8f, 4f, GroundTheme.Rust);

            CreateCoinRow(world, 24f, 5.4f, 3, 1.1f, 5);
            CreateCoinRow(world, 24f, 13.4f, 3, 1.1f, 5);
            CreateCoinRow(world, 44f, 21.4f, 3, 1.1f, 5);
            CreateCoinRow(world, 66f, 9.4f, 4, 1.2f, 5);
            CreateGem(world, 36f, 21.6f);
            CreateGem(world, 18f, 17.6f);
            CreateHeart(world, 56f, 13.4f);

            CreateSpikes(world, 12f, 0f, 2);
            CreateChest(world, 36f, 20f, 200, 2, "double");
            CreateCheckpoint(world, 18f, 16f);
            CreateCheckpoint(world, 60f, 8f);

            CreateEnemy(world, EnemySpecies.Warden, 40f, 21.2f, 2, 32f, 42f);
            CreateEnemy(world, EnemySpecies.Trashling, 30f, 13.2f, 2, 24f, 34f);
            CreateEnemy(world, EnemySpecies.Trashling, 30f, 5.2f, 2, 24f, 34f);
            CreateEnemy(world, EnemySpecies.Bat, 44f, 26f, 2, 38f, 50f);
            CreateEnemy(world, EnemySpecies.Bat, 52f, 18f, 2, 46f, 58f);
            CreateEnemy(world, EnemySpecies.Warden, 72f, 9.2f, 2, 64f, 78f);

            CreateGoalPortal(world, 76f, 8f);
        }

        private static void BuildStoryLevel5(Transform world, LevelLayout layout)
        {
            layout.Theme = GroundTheme.Void;
            layout.Spawn = new Vector3(2f, 1.5f, 0f);
            layout.MinX = -4f;
            layout.MaxX = 120f;
            layout.MaxY = 20f;
            layout.KillY = -12f;

            CreateSolid(world, "Ground", -2f, 26f, 0f, 4f, GroundTheme.Void);
            CreateSolid(world, "GroundB", 30f, 62f, 0f, 4f, GroundTheme.Void);
            CreateSolid(world, "GroundC", 68f, 120f, 0f, 4f, GroundTheme.Void);
            CreatePlatform(world, 28f, 3.4f, 3f);
            CreatePlatform(world, 65f, 3.4f, 3f);
            CreatePlatform(world, 46f, 4.5f, 6f);

            CreateCoinRow(world, 6f, 1.4f, 5, 1.2f, 5);
            CreateCoinRow(world, 34f, 1.4f, 6, 1.2f, 5);
            CreateCoinRow(world, 44f, 6.2f, 4, 1.2f, 5);
            CreateCoinRow(world, 74f, 1.4f, 6, 1.2f, 5);
            CreateGem(world, 46f, 6.4f);
            CreateGem(world, 30f, 4.8f);
            CreateGem(world, 67f, 4.8f);
            CreateHeart(world, 20f, 1.4f);
            CreateHeart(world, 92f, 1.4f);

            CreateSpikes(world, 38f, 0f, 3);
            CreateSpikes(world, 88f, 0f, 3);
            CreateChest(world, 56f, 0f, 260, 3, "tonic");
            CreateCheckpoint(world, 32f, 0f);
            CreateCheckpoint(world, 70f, 0f);

            CreateEnemy(world, EnemySpecies.Warden, 22f, 1.2f, 3, 14f, 24f);
            CreateEnemy(world, EnemySpecies.Trashling, 44f, 1.2f, 3, 34f, 52f);
            CreateEnemy(world, EnemySpecies.Bat, 50f, 7.5f, 3, 42f, 58f);
            CreateEnemy(world, EnemySpecies.Warden, 78f, 1.2f, 3, 72f, 86f);
            CreateEnemy(world, EnemySpecies.Trashling, 100f, 1.2f, 3, 94f, 112f);
            CreateEnemy(world, EnemySpecies.Bat, 104f, 8f, 3, 96f, 112f);

            CreateGoalPortal(world, 116f, 0f);
        }

        // ---------------- MODO SUPERVIVENCIA ----------------
        private static void BuildSurvivalArena(Transform world, LevelLayout layout)
        {
            layout.Theme = GroundTheme.Stone;
            layout.Spawn = new Vector3(0f, 1.6f, 0f);
            layout.MinX = -18f;
            layout.MaxX = 18f;
            layout.MinY = 0f;
            layout.MaxY = 16f;
            layout.KillY = -8f;
            layout.ArenaMinX = -15f;
            layout.ArenaMaxX = 15f;
            layout.ArenaFloorY = 0f;
            layout.IsArena = true;

            CreateSolid(world, "ArenaFloor", -18f, 18f, 0f, 4f, GroundTheme.Stone);
            CreateSolid(world, "ArenaWallL", -20f, -18f, 14f, 14f, GroundTheme.Stone);
            CreateSolid(world, "ArenaWallR", 18f, 20f, 14f, 14f, GroundTheme.Stone);
            CreateSolid(world, "ArenaRoof", -20f, 20f, 18f, 4f, GroundTheme.Stone);
            CreatePlatform(world, -10f, 4.5f, 5f);
            CreatePlatform(world, 10f, 4.5f, 5f);
            CreatePlatform(world, 0f, 8f, 5f);

            CreateHeart(world, -10f, 5.6f);
            CreateHeart(world, 10f, 5.6f);
            CreateGem(world, 0f, 9.2f);
            CreateChest(world, -15f, 0f, 120, 1, "tonic");
            CreateChest(world, 15f, 0f, 120, 1, "double");
        }

        // ---------------- MODO SPEEDRUN ----------------
        private static void BuildSpeedrunTrack(Transform world, LevelLayout layout, int track)
        {
            layout.Theme = GroundTheme.Stone;
            layout.Spawn = new Vector3(2f, 1.5f, 0f);
            layout.MinX = -4f;
            layout.MaxX = 176f;
            layout.MaxY = 16f;
            layout.KillY = -9f;

            CreateSolid(world, "Start", -2f, 24f, 0f, 4f, GroundTheme.Stone);

            float x = 30f;
            int index = 0;
            while (x < 168f)
            {
                float width = 8f + (index % 3) * 3f;
                CreateSolid(world, "Step" + index, x, x + width, 0f, 4f, GroundTheme.Stone);
                CreateCoinRow(world, x + 1.5f, 1.4f, 3, 1.1f, 5);
                CreateSpeedPad(world, x + width - 2.5f, 0f, 1f, 19f);
                if (index % 2 == 1)
                {
                    CreatePlatform(world, x + width + 2.5f, 2.6f, 3f);
                }
                x += width + (index % 3 == 0 ? 5.5f : (index % 3 == 1 ? 6.5f : 5f));
                index++;
            }

            CreateSolid(world, "Finish", 168f, 176f, 0f, 4f, GroundTheme.Stone);
            CreateGem(world, 60f, 2f);
            CreateGem(world, 120f, 2f);
            CreateGoalPortal(world, 172f, 0f);

            if (track >= 2)
            {
                CreateEnemy(world, EnemySpecies.Bat, 70f, 6f, 0, 60f, 80f);
                CreateEnemy(world, EnemySpecies.Bat, 130f, 6.5f, 0, 120f, 140f);
            }
            if (track >= 3)
            {
                CreateEnemy(world, EnemySpecies.Trashling, 100f, 4.4f, 0, 92f, 108f);
            }
        }
    }
}
