using UnityEngine;

namespace ChronosBlade
{
    /// <summary>
    /// Persistencia completa del juego mediante PlayerPrefs: monedas, gemas,
    /// personajes desbloqueados, armas, niveles de mejora, consumibles y records.
    /// </summary>
    public static class SaveSystem
    {
        private const string KeyCoins = "CBPL_Coins";
        private const string KeyGems = "CBPL_Gems";
        private const string KeySelectedCharacter = "CBPL_SelChar";
        private const string KeySelectedWeapon = "CBPL_SelWeapon";
        private const string KeyUnlockedCharacters = "CBPL_UnlockedChars";
        private const string KeyUnlockedWeapons = "CBPL_UnlockedWeapons";
        private const string KeyWeaponLevel = "CBPL_WeaponLvl_";
        private const string KeyPowerUp = "CBPL_PowerUp_";
        private const string KeyBestSurvivalKills = "CBPL_BestSurvivalKills";
        private const string KeyBestSurvivalCoins = "CBPL_BestSurvivalCoins";
        private const string KeyBestSpeedrunTime = "CBPL_BestSpeedrunTime";
        private const string KeyStoryProgress = "CBPL_StoryProgress";
        private const string KeyTotals = "CBPL_Totals";

        public static int Coins { get; set; }
        public static int Gems { get; set; }
        public static string SelectedCharacterId { get; set; }
        public static string SelectedWeaponId { get; set; }
        public static int BestSurvivalKills { get; set; }
        public static int BestSurvivalCoins { get; set; }
        public static float BestSpeedrunTime { get; set; }
        public static int StoryProgress { get; set; }

        private static bool _loaded;

        public static void Load()
        {
            if (_loaded)
            {
                return;
            }

            Coins = PlayerPrefs.GetInt(KeyCoins, ChronosCatalog.InitialCoins);
            Gems = PlayerPrefs.GetInt(KeyGems, ChronosCatalog.InitialGems);
            SelectedCharacterId = PlayerPrefs.GetString(KeySelectedCharacter, "kaen");
            SelectedWeaponId = PlayerPrefs.GetString(KeySelectedWeapon, "sword");
            BestSurvivalKills = PlayerPrefs.GetInt(KeyBestSurvivalKills, 0);
            BestSurvivalCoins = PlayerPrefs.GetInt(KeyBestSurvivalCoins, 0);
            BestSpeedrunTime = PlayerPrefs.GetFloat(KeyBestSpeedrunTime, 0f);
            StoryProgress = PlayerPrefs.GetInt(KeyStoryProgress, 1);

            if (!IsCharacterUnlocked("kaen"))
            {
                UnlockCharacter("kaen", false);
            }
            if (!IsWeaponUnlocked("sword"))
            {
                UnlockWeapon("sword", false);
            }
            if (GetWeaponLevel("sword") <= 0)
            {
                SetWeaponLevel("sword", 1, false);
            }

            _loaded = true;
        }

        public static void Save()
        {
            PlayerPrefs.SetInt(KeyCoins, Coins);
            PlayerPrefs.SetInt(KeyGems, Gems);
            PlayerPrefs.SetString(KeySelectedCharacter, SelectedCharacterId);
            PlayerPrefs.SetString(KeySelectedWeapon, SelectedWeaponId);
            PlayerPrefs.SetInt(KeyBestSurvivalKills, BestSurvivalKills);
            PlayerPrefs.SetInt(KeyBestSurvivalCoins, BestSurvivalCoins);
            PlayerPrefs.SetFloat(KeyBestSpeedrunTime, BestSpeedrunTime);
            PlayerPrefs.SetInt(KeyStoryProgress, StoryProgress);
            PlayerPrefs.Save();
        }

        public static void ResetAll()
        {
            PlayerPrefs.DeleteAll();
            _loaded = false;
            Load();
            Save();
        }

        // ---------------- Moneda ----------------
        public static int AddCoins(int amount)
        {
            Load();
            Coins = Mathf.Max(0, Coins + amount);
            return Coins;
        }

        public static int AddGems(int amount)
        {
            Load();
            Gems = Mathf.Max(0, Gems + amount);
            return Gems;
        }

        /// <summary>
        /// Verifica saldo (monedas + gemas) y descuenta automaticamente si alcanza.
        /// Devuelve true solo si la compra se completo.
        /// </summary>
        public static bool TrySpend(int coins, int gems)
        {
            Load();
            if (Coins < coins || Gems < gems)
            {
                return false;
            }
            Coins -= coins;
            Gems -= gems;
            Save();
            return true;
        }

        // ---------------- Personajes ----------------
        public static string GetUnlockedCharactersRaw()
        {
            return PlayerPrefs.GetString(KeyUnlockedCharacters, "kaen");
        }

        public static bool IsCharacterUnlocked(string id)
        {
            return ContainsEntry(GetUnlockedCharactersRaw(), id);
        }

        public static void UnlockCharacter(string id, bool save = true)
        {
            string raw = GetUnlockedCharactersRaw();
            if (!ContainsEntry(raw, id))
            {
                PlayerPrefs.SetString(KeyUnlockedCharacters, raw + "," + id);
            }
            if (save)
            {
                Save();
            }
        }

        // ---------------- Armas ----------------
        public static string GetUnlockedWeaponsRaw()
        {
            return PlayerPrefs.GetString(KeyUnlockedWeapons, "sword");
        }

        public static bool IsWeaponUnlocked(string id)
        {
            return ContainsEntry(GetUnlockedWeaponsRaw(), id);
        }

        public static void UnlockWeapon(string id, bool save = true)
        {
            string raw = GetUnlockedWeaponsRaw();
            if (!ContainsEntry(raw, id))
            {
                PlayerPrefs.SetString(KeyUnlockedWeapons, raw + "," + id);
            }
            if (save)
            {
                Save();
            }
        }

        public static int GetWeaponLevel(string id)
        {
            return PlayerPrefs.GetInt(KeyWeaponLevel + id, id == "sword" ? 1 : 0);
        }

        public static void SetWeaponLevel(string id, int level, bool save = true)
        {
            int max = ChronosCatalog.GetWeapon(id).MaxLevel;
            PlayerPrefs.SetInt(KeyWeaponLevel + id, Mathf.Clamp(level, 0, max));
            if (save)
            {
                Save();
            }
        }

        // ---------------- Potenciadores (inventario) ----------------
        public static int GetPowerUpCount(string key)
        {
            return PlayerPrefs.GetInt(KeyPowerUp + key, 0);
        }

        public static void AddPowerUp(string key, int amount)
        {
            PlayerPrefs.SetInt(KeyPowerUp + key, Mathf.Max(0, GetPowerUpCount(key) + amount));
            Save();
        }

        public static bool ConsumePowerUp(string key)
        {
            int current = GetPowerUpCount(key);
            if (current <= 0)
            {
                return false;
            }
            PlayerPrefs.SetInt(KeyPowerUp + key, current - 1);
            Save();
            return true;
        }

        // ---------------- Records ----------------
        public static bool RegisterSurvivalRun(int kills, int coinsEarned)
        {
            bool isRecord = false;
            if (kills > BestSurvivalKills)
            {
                BestSurvivalKills = kills;
                isRecord = true;
            }
            if (coinsEarned > BestSurvivalCoins)
            {
                BestSurvivalCoins = coinsEarned;
            }
            Save();
            return isRecord;
        }

        public static bool RegisterSpeedrunTime(float seconds)
        {
            if (seconds < 3f)
            {
                return false;
            }
            bool isRecord = BestSpeedrunTime <= 0f || seconds < BestSpeedrunTime;
            if (isRecord)
            {
                BestSpeedrunTime = seconds;
                Save();
            }
            return isRecord;
        }

        public static void RegisterStoryProgress(int levelCleared)
        {
            int next = Mathf.Clamp(levelCleared + 1, 1, ChronosCatalog.StoryLevelCount);
            if (next > StoryProgress)
            {
                StoryProgress = next;
                Save();
            }
        }

        public static string FormatSpeedrun(float seconds)
        {
            if (seconds <= 0f)
            {
                return "--:--:--";
            }
            int minutes = (int)(seconds / 60f);
            int secs = (int)(seconds % 60f);
            int millis = (int)((seconds * 100f) % 100f);
            return string.Format("{0:00}:{1:00}:{2:00}", minutes, secs, millis);
        }

        private static bool ContainsEntry(string raw, string id)
        {
            if (string.IsNullOrEmpty(raw) || string.IsNullOrEmpty(id))
            {
                return false;
            }
            string[] parts = raw.Split(',');
            for (int i = 0; i < parts.Length; i++)
            {
                if (parts[i].Trim() == id)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
