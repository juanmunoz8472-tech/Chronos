using UnityEngine;

namespace ChronosBlade
{
    /// <summary>
    /// Configuracion activa de la partida: modo, nivel de historia y loadout
    /// (personaje + arma + nivel de mejora) elegidos en la tienda.
    /// </summary>
    public class GameSession : MonoBehaviour
    {
        public static GameSession Instance { get; private set; }

        public GameMode Mode = GameMode.Story;
        public int StoryLevel = 1;
        public CharacterDefinition Character;
        public WeaponDefinition Weapon;
        public int WeaponLevel = 1;
        public int LevelSeed = 12345;

        public static GameSession Create(GameMode mode, int storyLevel)
        {
            GameObject go = new GameObject("GameSession");
            GameSession session = go.AddComponent<GameSession>();
            session.Mode = mode;
            session.StoryLevel = storyLevel;
            session.Character = ChronosCatalog.GetCharacter(SaveSystem.SelectedCharacterId);
            session.Weapon = ChronosCatalog.GetWeapon(SaveSystem.SelectedWeaponId);
            session.WeaponLevel = Mathf.Max(1, SaveSystem.GetWeaponLevel(session.Weapon.Id));
            session.LevelSeed = Random.Range(1000, 999999);
            return session;
        }

        private void Awake()
        {
            Instance = this;
        }

        private void OnDestroy()
        {
            if (Instance == this)
            {
                Instance = null;
            }
        }

        /// <summary>Daño final del arma equipada: base del arma x nivel x personaje x potenciador.</summary>
        public int ResolveDamage(float powerUpMultiplier)
        {
            int weaponDamage = ChronosCatalog.WeaponDamage(Weapon, WeaponLevel);
            float characterMultiplier = Character != null ? Character.DamageMultiplier : 1f;
            return Mathf.Max(1, Mathf.RoundToInt(weaponDamage * characterMultiplier * powerUpMultiplier));
        }
    }
}
