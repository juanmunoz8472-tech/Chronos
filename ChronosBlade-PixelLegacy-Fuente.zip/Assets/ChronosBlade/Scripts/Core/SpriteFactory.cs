using System.Collections.Generic;
using UnityEngine;

namespace ChronosBlade
{
    /// <summary>Catalogo de sprites generados por codigo (pixel art procedural 16x16).</summary>
    public enum PixelArtType
    {
        HeroIdle, HeroRun, HeroJump, HeroAttack, HeroHurt, HeroDie,
        TrashlingIdle, TrashlingRun, BatFly, WardenIdle, WardenRun,
        Coin, Gem, Heart, Chest, Portal, Spike, Platform,
        WeaponSword, WeaponGreatsword, WeaponDaggers, WeaponBoomerang,
        PowerTonic, PowerMagnet, PowerShield, PowerDoubleDamage,
        SlashEffect, ProjectileBlade, ProjectileBolt, Shadow, Particle
    }

    /// <summary>Estados de animacion del heroe (espejo de los parametros del Animator).</summary>
    public enum HeroAnim
    {
        Idle,
        Run,
        Jump,
        Attack,
        Hurt,
        Die
    }

    /// <summary>Temas visuales para tiles de suelo.</summary>
    public enum GroundTheme
    {
        Grass,
        Rust,
        Stone,
        Void
    }

    /// <summary>
    /// Genera todos los sprites del juego en tiempo de ejecucion con pixel art dibujado a mano,
    /// por lo que el proyecto no depende de ningun archivo de arte externo para verse bien.
    /// </summary>
    public static class SpriteFactory
    {
        public const int Size = 16;
        public const float PixelsPerUnit = 16f;

        private static readonly Dictionary<string, Sprite> Cache = new Dictionary<string, Sprite>();
        private static Sprite _white;

        // ---------------- Paleta base ----------------
        private static readonly Color32 Transparent = new Color32(0, 0, 0, 0);
        private static readonly Color32 Outline = new Color32(24, 26, 42, 255);
        private static readonly Color32 Skin = new Color32(240, 192, 144, 255);
        private static readonly Color32 SkinShade = new Color32(206, 150, 108, 255);
        private static readonly Color32 EyeWhite = new Color32(250, 250, 252, 255);
        private static readonly Color32 EyeDark = new Color32(28, 30, 46, 255);
        private static readonly Color32 Gold = new Color32(248, 200, 80, 255);
        private static readonly Color32 GoldDark = new Color32(190, 140, 40, 255);
        private static readonly Color32 Steel = new Color32(205, 212, 226, 255);
        private static readonly Color32 SteelDark = new Color32(120, 130, 152, 255);
        private static readonly Color32 Green = new Color32(110, 200, 90, 255);
        private static readonly Color32 GreenDark = new Color32(58, 130, 60, 255);
        private static readonly Color32 Purple = new Color32(150, 110, 220, 255);
        private static readonly Color32 Cyan = new Color32(120, 225, 255, 255);
        private static readonly Color32 Red = new Color32(220, 70, 70, 255);
        private static readonly Color32 Orange = new Color32(255, 160, 50, 255);

        private static readonly Color32[] HeroPalette0 = { new Color32(198, 62, 66, 255), new Color32(140, 38, 46, 255), new Color32(206, 214, 228, 255), new Color32(212, 96, 56, 255), Gold };
        private static readonly Color32[] HeroPalette1 = { new Color32(78, 178, 224, 255), new Color32(44, 118, 168, 255), new Color32(232, 242, 252, 255), new Color32(186, 152, 240, 255), Cyan };
        private static readonly Color32[] HeroPalette2 = { new Color32(120, 104, 82, 255), new Color32(78, 64, 50, 255), new Color32(196, 126, 62, 255), new Color32(214, 208, 198, 255), Orange };
        private static readonly Color32[] HeroPalette3 = { new Color32(92, 76, 120, 255), new Color32(56, 46, 78, 255), new Color32(132, 132, 156, 255), new Color32(140, 235, 165, 255), new Color32(90, 225, 140, 255) };

        public static Sprite White
        {
            get
            {
                if (_white == null)
                {
                    Texture2D tex = new Texture2D(1, 1, TextureFormat.RGBA32, false);
                    tex.filterMode = FilterMode.Point;
                    tex.wrapMode = TextureWrapMode.Clamp;
                    tex.SetPixel(0, 0, Color.white);
                    tex.Apply();
                    _white = Sprite.Create(tex, new Rect(0, 0, 1, 1), new Vector2(0.5f, 0.5f), 1f);
                    _white.name = "WhitePixel";
                }
                return _white;
            }
        }

        public static Sprite Get(PixelArtType type, int frame)
        {
            string key = type.ToString() + "_" + frame;
            Sprite cached;
            if (Cache.TryGetValue(key, out cached) && cached != null)
            {
                return cached;
            }

            Canvas c = new Canvas(Size, Size);
            switch (type)
            {
                case PixelArtType.HeroIdle: DrawHero(c, HeroPalette0, 0, 0, 0, 0, 0, frame); break;
                case PixelArtType.HeroRun: DrawHero(c, HeroPalette0, 1 + (frame % 3), 0, 0, 0, 0, 0); break;
                case PixelArtType.HeroJump: DrawHero(c, HeroPalette0, frame % 2 == 0 ? 4 : 5, 0, 0, 1, 0, 0); break;
                case PixelArtType.HeroAttack: DrawHero(c, HeroPalette0, 0, 0, 0, frame == 0 ? 1 : (frame == 1 ? 2 : 0), 0, frame == 1 ? 3 : 0); break;
                case PixelArtType.HeroHurt: DrawHero(c, HeroPalette0, 5, 0, 0, 3, 0, 2); break;
                case PixelArtType.HeroDie: DrawHero(c, HeroPalette0, 6, 0, 0, 3, 0, 2); break;
                case PixelArtType.TrashlingIdle: DrawTrashling(c, frame); break;
                case PixelArtType.TrashlingRun: DrawTrashling(c, frame % 2 + 2); break;
                case PixelArtType.BatFly: DrawBat(c, frame % 2); break;
                case PixelArtType.WardenIdle: DrawWarden(c, 0); break;
                case PixelArtType.WardenRun: DrawWarden(c, frame % 2 == 0 ? 1 : 2); break;
                case PixelArtType.Coin: DrawCoin(c, frame % 4); break;
                case PixelArtType.Gem: DrawGem(c); break;
                case PixelArtType.Heart: DrawHeart(c); break;
                case PixelArtType.Chest: DrawChest(c); break;
                case PixelArtType.Portal: DrawPortal(c, frame % 4); break;
                case PixelArtType.Spike: DrawSpike(c); break;
                case PixelArtType.Platform: DrawPlatformTile(c); break;
                case PixelArtType.WeaponSword: DrawWeaponIcon(c, 0); break;
                case PixelArtType.WeaponGreatsword: DrawWeaponIcon(c, 1); break;
                case PixelArtType.WeaponDaggers: DrawWeaponIcon(c, 2); break;
                case PixelArtType.WeaponBoomerang: DrawWeaponIcon(c, 3); break;
                case PixelArtType.PowerTonic: DrawPowerIcon(c, 0); break;
                case PixelArtType.PowerMagnet: DrawPowerIcon(c, 1); break;
                case PixelArtType.PowerShield: DrawPowerIcon(c, 2); break;
                case PixelArtType.PowerDoubleDamage: DrawPowerIcon(c, 3); break;
                case PixelArtType.SlashEffect: DrawSlash(c, frame % 3); break;
                case PixelArtType.ProjectileBlade: DrawProjectile(c, frame % 4, false); break;
                case PixelArtType.ProjectileBolt: DrawProjectile(c, frame % 4, true); break;
                case PixelArtType.Shadow: DrawShadow(c); break;
                case PixelArtType.Particle: DrawParticle(c); break;
            }

            Sprite sprite = c.Build(key);
            Cache[key] = sprite;
            return sprite;
        }

        /// <summary>Sprites del heroe coloreados segun el indice de paleta del personaje elegido.</summary>
        public static Sprite GetHero(int paletteIndex, HeroAnim anim, int frame)
        {
            Color32[] palette = GetHeroPalette(paletteIndex);
            string key = "Hero" + paletteIndex + "_" + anim + "_" + frame;
            Sprite cached;
            if (Cache.TryGetValue(key, out cached) && cached != null)
            {
                return cached;
            }

            Canvas c = new Canvas(Size, Size);
            switch (anim)
            {
                case HeroAnim.Idle:
                    DrawHero(c, palette, 0, 0, 0, 0, 0, frame % 4);
                    break;
                case HeroAnim.Run:
                    DrawHero(c, palette, 1 + (frame % 3), (frame / 3) % 2, 0, 0, 0, 0);
                    break;
                case HeroAnim.Jump:
                    DrawHero(c, palette, frame % 2 == 0 ? 4 : 5, 0, 0, frame % 2 == 0 ? 0 : 1, 0, 0);
                    break;
                case HeroAnim.Attack:
                    DrawHero(c, palette, 0, 0, 0, frame == 0 ? 1 : (frame == 1 ? 2 : 0), 0, frame == 1 ? 3 : 0);
                    break;
                case HeroAnim.Hurt:
                    DrawHero(c, palette, 3, 0, 0, 3, 0, 2);
                    break;
                case HeroAnim.Die:
                    DrawHero(c, palette, 6, 0, 0, 3, 0, 2);
                    break;
            }

            Sprite sprite = c.Build(key);
            Cache[key] = sprite;
            return sprite;
        }

        public static Color32[] GetHeroPalette(int index)
        {
            switch (index)
            {
                case 1: return HeroPalette1;
                case 2: return HeroPalette2;
                case 3: return HeroPalette3;
                default: return HeroPalette0;
            }
        }

        public static Sprite Ground(GroundTheme theme, int variant)
        {
            string key = "Ground_" + theme + "_" + variant;
            Sprite cached;
            if (Cache.TryGetValue(key, out cached) && cached != null)
            {
                return cached;
            }

            Canvas c = new Canvas(Size, Size);
            Color32 top;
            Color32 topDark;
            Color32 body;
            Color32 bodyDark;

            switch (theme)
            {
                case GroundTheme.Grass:
                    top = new Color32(112, 196, 92, 255);
                    topDark = new Color32(64, 140, 70, 255);
                    body = new Color32(122, 92, 66, 255);
                    bodyDark = new Color32(92, 68, 50, 255);
                    break;
                case GroundTheme.Rust:
                    top = new Color32(186, 112, 62, 255);
                    topDark = new Color32(126, 70, 42, 255);
                    body = new Color32(96, 74, 66, 255);
                    bodyDark = new Color32(70, 54, 50, 255);
                    break;
                case GroundTheme.Void:
                    top = new Color32(138, 108, 196, 255);
                    topDark = new Color32(88, 68, 140, 255);
                    body = new Color32(58, 48, 84, 255);
                    bodyDark = new Color32(42, 34, 62, 255);
                    break;
                default:
                    top = new Color32(150, 150, 162, 255);
                    topDark = new Color32(104, 104, 118, 255);
                    body = new Color32(78, 78, 92, 255);
                    bodyDark = new Color32(58, 58, 70, 255);
                    break;
            }

            c.Rect(0, 0, Size, 12, body);
            c.Rect(0, 11, Size, 5, bodyDark);
            c.Rect(0, 12, Size, 4, top);
            c.Rect(0, 12, Size, 1, topDark);

            // Variacion de textura por variante (determinista, sin aleatoriedad global).
            int[] speckX = variant % 2 == 0 ? new int[] { 3, 8, 12 } : new int[] { 5, 6, 13 };
            int[] speckY = variant % 2 == 0 ? new int[] { 8, 5, 9 } : new int[] { 6, 3, 7 };
            for (int i = 0; i < speckX.Length; i++)
            {
                c.Set(speckX[i], speckY[i], bodyDark);
            }

            c.Set(variant % 2 == 0 ? 1 : 14, 10, topDark);
            c.Set(variant % 2 == 0 ? 14 : 4, 2, bodyDark);

            Sprite sprite = c.Build(key);
            Cache[key] = sprite;
            return sprite;
        }

        /// <summary>Degradado vertical de 1 pixel de ancho por 32 de alto para fondos.</summary>
        public static Sprite Gradient(Color top, Color bottom)
        {
            string key = "Grad_" + (int)(top.r * 255) + "_" + (int)(top.g * 255) + "_" + (int)(top.b * 255) + "_" + (int)(bottom.r * 255) + "_" + (int)(bottom.g * 255) + "_" + (int)(bottom.b * 255);
            Sprite cached;
            if (Cache.TryGetValue(key, out cached) && cached != null)
            {
                return cached;
            }

            Texture2D tex = new Texture2D(1, 32, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Point;
            tex.wrapMode = TextureWrapMode.Clamp;
            for (int y = 0; y < 32; y++)
            {
                float t = y / 31f;
                tex.SetPixel(0, y, Color.Lerp(bottom, top, t));
            }
            tex.Apply();
            Sprite sprite = Sprite.Create(tex, new Rect(0, 0, 1, 32), new Vector2(0.5f, 0.5f), 1f);
            sprite.name = key;
            Cache[key] = sprite;
            return sprite;
        }

        /// <summary>Silueta de colinas lejanas para las capas de parallax (64x32).</summary>
        public static Sprite Hills(Color color, int seed)
        {
            string key = "Hills_" + seed;
            Sprite cached;
            if (Cache.TryGetValue(key, out cached) && cached != null)
            {
                return cached;
            }

            Random.State previous = Random.state;
            Random.InitState(seed);
            Canvas c = new Canvas(64, 32);
            float phase = Random.Range(0f, 6.28f);
            float phase2 = Random.Range(0f, 6.28f);
            float baseHeight = Random.Range(9f, 15f);
            for (int x = 0; x < 64; x++)
            {
                float h = baseHeight + Mathf.Sin(x * 0.16f + phase) * 5f + Mathf.Sin(x * 0.07f + phase2) * 4f;
                int height = Mathf.Clamp(Mathf.RoundToInt(h), 4, 31);
                for (int y = 0; y < height; y++)
                {
                    c.Set(x, y, color);
                }
            }
            Random.state = previous;

            Sprite sprite = c.Build(key);
            Cache[key] = sprite;
            return sprite;
        }

        /// <summary>Nube pixelada simple para la capa de fondo mas lejana.</summary>
        public static Sprite Cloud(Color color)
        {
            Sprite cached;
            if (Cache.TryGetValue("Cloud", out cached) && cached != null)
            {
                return cached;
            }

            Canvas c = new Canvas(24, 12);
            c.Rect(3, 3, 18, 5, color);
            c.Rect(6, 7, 12, 3, color);
            c.Rect(1, 4, 4, 3, color);
            c.Rect(19, 4, 4, 3, color);
            c.Rect(9, 9, 6, 2, color);
            Sprite sprite = c.Build("Cloud");
            Cache["Cloud"] = sprite;
            return sprite;
        }

        // ------------------------------------------------------------------
        // HEROE
        // legPose: 0 quieto, 1/2/3 caminar, 4 salto, 5 caida, 6 yaciendo
        // swordPose: 0 reposo, 1 preparacion, 2 corte diagonal, 3 suelta
        // eyeMode: 0 normal, 1 parpadeo, 2 muerto, 3 golpeado
        // ------------------------------------------------------------------
        private static void DrawHero(Canvas c, Color32[] p, int legPose, int lift, int lean, int swordPose, int armPose, int eyeMode)
        {
            Color32 cloth = p[0];
            Color32 clothDark = p[1];
            Color32 armor = p[2];
            Color32 hair = p[3];
            Color32 accent = p[4];

            if (legPose == 6)
            {
                // Pose de muerte: heroe yaciendo sobre el suelo.
                c.Rect(2, 0, 12, 3, clothDark);
                c.Rect(3, 1, 9, 3, cloth);
                c.Rect(1, 1, 2, 2, armor);
                c.Rect(12, 2, 3, 4, Skin);
                c.Rect(12, 5, 3, 1, hair);
                c.Set(13, 3, EyeDark);
                c.Rect(4, 0, 1, 1, Outline);
                c.Rect(7, 0, 1, 1, Outline);
                c.Rect(10, 0, 1, 1, Outline);
                // Espada suelta junto al cuerpo.
                c.Rect(0, 5, 6, 1, Steel);
                c.Rect(0, 5, 1, 1, accent);
                c.Set(0, 4, Gold);
                c.Set(1, 4, Gold);
                return;
            }

            int y = lift;

            // Piernas y botas segun pose.
            switch (legPose)
            {
                case 4: // salto: piernas recogidas
                    c.Rect(4, 2 + y, 3, 3, cloth);
                    c.Rect(9, 2 + y, 3, 3, cloth);
                    c.Rect(4, 1, 4, 2, clothDark);
                    c.Rect(8, 1, 4, 2, clothDark);
                    break;
                case 5: // caida: piernas estiradas y abiertas
                    c.Rect(3, 1, 3, 5, cloth);
                    c.Rect(10, 1, 3, 5, cloth);
                    c.Rect(2, 0, 4, 2, clothDark);
                    c.Rect(10, 0, 4, 2, clothDark);
                    break;
                case 1:
                    c.Rect(3, 2, 3, 4, cloth);
                    c.Rect(10, 2, 3, 4, cloth);
                    c.Rect(2, 0, 4, 2, clothDark);
                    c.Rect(10, 0, 4, 2, clothDark);
                    break;
                case 2:
                    c.Rect(4, 2, 3, 4, cloth);
                    c.Rect(8, 2, 3, 4, cloth);
                    c.Rect(4, 0, 3, 2, clothDark);
                    c.Rect(9, 0, 3, 2, clothDark);
                    break;
                case 3:
                    c.Rect(5, 2, 3, 4, cloth);
                    c.Rect(9, 2, 3, 4, cloth);
                    c.Rect(5, 0, 3, 2, clothDark);
                    c.Rect(9, 0, 3, 2, clothDark);
                    break;
                default:
                    c.Rect(4, 2, 3, 4, cloth);
                    c.Rect(9, 2, 3, 4, cloth);
                    c.Rect(3, 0, 4, 2, clothDark);
                    c.Rect(9, 0, 4, 2, clothDark);
                    break;
            }

            // Cadera y torso.
            c.Rect(3, 6 + y, 10, 1, Outline);
            c.Rect(3, 7 + y, 10, 4, cloth);
            c.Rect(3, 7 + y, 2, 4, clothDark);
            c.Rect(6, 7 + y, 4, 4, armor);
            c.Rect(6, 10 + y, 4, 1, SteelDark);

            // Hombreras.
            c.Rect(1, 9 + y, 3, 3, armor);
            c.Rect(1, 9 + y, 3, 1, SteelDark);
            c.Rect(12, 9 + y, 3, 3, armor);
            c.Rect(12, 9 + y, 3, 1, SteelDark);

            // Brazos.
            c.Rect(2, 7 + y, 2, 2, cloth);
            if (armPose == 1 || armPose == 3)
            {
                c.Rect(12, 10 + y, 2, 3, cloth);
            }
            else
            {
                c.Rect(12, 7 + y, 2, 2, cloth);
            }

            // Cabeza, pelo y rostro.
            c.Rect(5, 11 + y, 6, 4, Skin);
            c.Rect(5, 11 + y, 1, 2, SkinShade);
            c.Rect(5, 14 + y, 6, 1, hair);
            c.Rect(6, 15 + y, 4, 1, hair);
            c.Set(5, 12 + y, hair);
            c.Set(5, 13 + y, hair);
            c.Set(10, 12 + y, hair);
            c.Set(10, 13 + y, hair);

            switch (eyeMode)
            {
                case 1:
                    c.Set(6, 12 + y, SkinShade);
                    c.Set(9, 12 + y, SkinShade);
                    break;
                case 2:
                    c.Set(6, 12 + y, EyeDark);
                    c.Set(7, 13 + y, EyeDark);
                    c.Set(6, 13 + y, EyeDark);
                    c.Set(7, 12 + y, EyeDark);
                    c.Set(9, 12 + y, EyeDark);
                    c.Set(10, 13 + y, EyeDark);
                    c.Set(9, 13 + y, EyeDark);
                    c.Set(10, 12 + y, EyeDark);
                    break;
                case 3:
                    c.Rect(6, 12 + y, 2, 1, EyeWhite);
                    c.Rect(9, 12 + y, 1, 1, EyeWhite);
                    c.Set(7, 12 + y, EyeDark);
                    break;
                default:
                    c.Set(6, 12 + y, EyeDark);
                    c.Set(9, 12 + y, EyeDark);
                    break;
            }

            // Espada en la mano derecha.
            int handX = 13;
            int handY = 7 + y;
            switch (swordPose)
            {
                case 1: // preparacion: filo en diagonal hacia arriba
                    c.Set(handX, handY + 1, Gold);
                    c.Set(handX, handY + 2, Gold);
                    c.Set(handX + 1, handY + 3, Steel);
                    c.Set(handX + 1, handY + 4, Steel);
                    c.Set(handX + 2, handY + 5, Steel);
                    c.Set(handX + 2, handY + 6, Steel);
                    c.Set(handX + 2, handY + 7, accent);
                    c.Set(handX, handY + 3, SteelDark);
                    break;
                case 2: // corte diagonal descendente + estela
                    c.Set(handX, handY, Gold);
                    c.Set(handX + 1, handY - 1, Steel);
                    c.Set(handX + 2, handY - 2, Steel);
                    c.Set(handX + 2, handY - 3, accent);
                    c.Set(handX - 1, handY + 3, accent);
                    c.Set(handX - 2, handY + 4, accent);
                    c.Set(handX - 3, handY + 5, accent);
                    break;
                case 3: // arma suelta (golpeado)
                    c.Set(handX + 1, handY - 2, Steel);
                    c.Set(handX + 2, handY - 3, SteelDark);
                    break;
                default: // reposo: filo vertical a la derecha
                    c.Set(handX, handY, Gold);
                    c.Set(handX, handY + 1, Gold);
                    c.Set(handX - 1, handY + 2, GoldDark);
                    c.Set(handX, handY + 2, Gold);
                    c.Set(handX + 1, handY + 2, GoldDark);
                    c.Set(handX, handY + 3, Steel);
                    c.Set(handX, handY + 4, Steel);
                    c.Set(handX, handY + 5, Steel);
                    c.Set(handX, handY + 6, Steel);
                    c.Set(handX, handY + 7, accent);
                    break;
            }

            // Detalle de capa/acento en el torso.
            c.Set(5, 8 + y, accent);
        }

        // ------------------------------------------------------------------
        // ENEMIGOS
        // ------------------------------------------------------------------
        private static void DrawTrashling(Canvas c, int frame)
        {
            Color32 body = new Color32(126, 176, 82, 255);
            Color32 bodyDark = new Color32(78, 122, 54, 255);
            Color32 belly = new Color32(178, 214, 130, 255);

            int bob = frame % 2 == 0 ? 0 : 1;
            int y = bob;

            c.Rect(3, 1, 3, 3, bodyDark);
            c.Rect(10, 1, 3, 3, bodyDark);
            c.Rect(4, 0, 3, 1, Outline);
            c.Rect(9, 0, 3, 1, Outline);

            c.Rect(4, 3 + y, 8, 6, body);
            c.Rect(5, 3 + y, 6, 2, belly);
            c.Rect(4, 8 + y, 8, 1, bodyDark);
            c.Rect(2, 5 + y, 2, 3, bodyDark);
            c.Rect(12, 5 + y, 2, 3, bodyDark);
            c.Rect(3, 10 + y, 2, 2, bodyDark);
            c.Rect(11, 10 + y, 2, 2, bodyDark);

            // Ojos.
            c.Rect(5, 7 + y, 2, 2, EyeWhite);
            c.Rect(9, 7 + y, 2, 2, EyeWhite);
            c.Set(6, 7 + y, EyeDark);
            c.Set(9, 7 + y, EyeDark);

            // Boca con colmillos.
            c.Rect(6, 4 + y, 4, 1, Outline);
            c.Set(6, 5 + y, EyeWhite);
            c.Set(9, 5 + y, EyeWhite);

            // Orejas puntiagudas.
            c.Set(2, 9 + y, bodyDark);
            c.Set(13, 9 + y, bodyDark);
        }

        private static void DrawBat(Canvas c, int frame)
        {
            Color32 body = new Color32(94, 74, 140, 255);
            Color32 bodyDark = new Color32(58, 44, 92, 255);
            Color32 wing = new Color32(126, 100, 180, 255);

            int wingY = frame == 0 ? 12 : 6;

            // Cuerpo.
            c.Rect(6, 6, 4, 5, body);
            c.Rect(6, 10, 4, 2, bodyDark);
            // Orejas.
            c.Set(6, 12, bodyDark);
            c.Set(9, 12, bodyDark);
            // Ojos rojos.
            c.Set(6, 9, Red);
            c.Set(9, 9, Red);
            // Colmillos.
            c.Set(7, 7, EyeWhite);
            c.Set(8, 7, EyeWhite);

            // Alas segun fotograma.
            c.Rect(1, wingY, 5, 2, wing);
            c.Rect(10, wingY, 5, 2, wing);
            if (frame == 0)
            {
                c.Rect(2, 10, 3, 2, wing);
                c.Rect(11, 10, 3, 2, wing);
                c.Set(1, 12, bodyDark);
                c.Set(14, 12, bodyDark);
            }
            else
            {
                c.Rect(1, 5, 4, 2, bodyDark);
                c.Rect(11, 5, 4, 2, bodyDark);
                c.Set(1, 4, bodyDark);
                c.Set(14, 4, bodyDark);
            }
        }

        private static void DrawWarden(Canvas c, int frame)
        {
            Color32 armor = new Color32(178, 116, 60, 255);
            Color32 armorDark = new Color32(112, 68, 36, 255);
            Color32 iron = new Color32(96, 92, 108, 255);
            Color32 ironDark = new Color32(62, 58, 74, 255);

            int step = frame == 1 ? -1 : (frame == 2 ? 1 : 0);

            // Piernas.
            c.Rect(3 + (step > 0 ? 1 : 0), 0, 4, 4, ironDark);
            c.Rect(9 - (step < 0 ? 1 : 0), 0, 4, 4, ironDark);
            c.Rect(2, 0, 5, 2, iron);
            c.Rect(9, 0, 5, 2, iron);

            // Torso ancho.
            c.Rect(2, 4, 12, 6, armor);
            c.Rect(2, 4, 12, 1, armorDark);
            c.Rect(6, 5, 4, 4, ironDark);

            // Hombreras grandes.
            c.Rect(0, 8, 4, 3, armorDark);
            c.Rect(12, 8, 4, 3, armorDark);
            c.Set(0, 10, Orange);
            c.Set(15, 10, Orange);

            // Casco con cuernos.
            c.Rect(5, 10, 6, 4, iron);
            c.Rect(5, 13, 6, 1, ironDark);
            c.Set(4, 14, ironDark);
            c.Set(11, 14, ironDark);
            c.Set(4, 13, iron);
            c.Set(11, 13, iron);

            // Visor con ojos encendidos.
            c.Rect(6, 12, 4, 1, Outline);
            c.Set(6, 12, Red);
            c.Set(9, 12, Red);

            // Pendientes de escudo en la espalda.
            c.Rect(13, 5, 2, 4, armorDark);
        }

        // ------------------------------------------------------------------
        // OBJETOS
        // ------------------------------------------------------------------
        private static void DrawCoin(Canvas c, int frame)
        {
            int[] radius = { 5, 3, 1, 3 };
            int rx = radius[frame % 4];
            Disc(c, 8, 8, rx, 5, GoldDark);
            Disc(c, 8, 8, Mathf.Max(0, rx - 1), 4, Gold);
            if (rx > 2)
            {
                c.Set(7, 10, new Color32(255, 240, 180, 255));
                c.Set(6, 9, new Color32(255, 240, 180, 255));
            }
        }

        private static void DrawGem(Canvas c)
        {
            Color32 gem = new Color32(120, 226, 255, 255);
            Color32 gemDark = new Color32(58, 148, 214, 255);
            c.Set(8, 14, gemDark);
            c.Rect(6, 12, 4, 2, gemDark);
            c.Rect(4, 9, 8, 3, gem);
            c.Rect(5, 6, 6, 3, gem);
            c.Rect(6, 4, 4, 2, gemDark);
            c.Rect(7, 2, 2, 2, gemDark);
            c.Set(6, 11, EyeWhite);
            c.Set(7, 12, EyeWhite);
            c.Set(6, 12, new Color32(200, 250, 255, 255));
        }

        private static void DrawHeart(Canvas c)
        {
            Color32 heart = new Color32(232, 74, 92, 255);
            Color32 heartDark = new Color32(170, 40, 62, 255);
            c.Rect(3, 9, 4, 3, heartDark);
            c.Rect(9, 9, 4, 3, heartDark);
            c.Rect(4, 8, 8, 2, heart);
            c.Rect(5, 6, 6, 2, heart);
            c.Rect(6, 4, 4, 2, heart);
            c.Rect(7, 3, 2, 1, heartDark);
            c.Set(5, 10, new Color32(255, 160, 170, 255));
        }

        private static void DrawChest(Canvas c)
        {
            Color32 wood = new Color32(150, 100, 58, 255);
            Color32 woodDark = new Color32(104, 66, 36, 255);
            c.Rect(1, 2, 14, 8, wood);
            c.Rect(1, 2, 14, 1, woodDark);
            c.Rect(1, 9, 14, 1, woodDark);
            c.Rect(1, 6, 14, 1, Gold);
            c.Rect(7, 4, 3, 5, GoldDark);
            c.Set(8, 6, Gold);
            c.Set(1, 2, woodDark);
            c.Set(14, 2, woodDark);
            c.Set(2, 10, woodDark);
            c.Set(13, 10, woodDark);
        }

        private static void DrawPortal(Canvas c, int frame)
        {
            Color32 ring = Purple;
            Color32 ringDark = new Color32(96, 68, 168, 255);
            int grow = frame % 2;
            Disc(c, 8, 8, 5 + grow, 7, ringDark);
            Disc(c, 8, 8, 4 + grow, 6, ring);
            Disc(c, 8, 8, 2, 4, new Color32(230, 210, 255, 255));
            if (frame >= 2)
            {
                Disc(c, 8, 8, 1, 2, Color.white);
            }
            c.Set(3, 11, Cyan);
            c.Set(12, 5, Cyan);
        }

        private static void DrawSpike(Canvas c)
        {
            Color32 metal = new Color32(178, 186, 204, 255);
            Color32 metalDark = new Color32(104, 112, 132, 255);
            c.Rect(0, 0, 16, 3, metalDark);
            c.Set(4, 3, metalDark);
            c.Set(3, 4, metalDark);
            c.Set(2, 5, metal);
            c.Set(1, 6, metal);
            c.Set(0, 7, metal);
            c.Set(11, 3, metalDark);
            c.Set(12, 4, metalDark);
            c.Set(13, 5, metal);
            c.Set(14, 6, metal);
            c.Set(15, 7, metal);
            c.Rect(6, 3, 4, 4, metal);
            c.Set(7, 7, metalDark);
            c.Set(8, 7, metalDark);
        }

        private static void DrawPlatformTile(Canvas c)
        {
            Color32 top = new Color32(214, 168, 96, 255);
            Color32 body = new Color32(150, 110, 64, 255);
            Color32 bodyDark = new Color32(108, 76, 44, 255);
            c.Rect(0, 0, 16, 5, body);
            c.Rect(0, 4, 16, 1, top);
            c.Rect(0, 0, 16, 1, bodyDark);
            c.Set(3, 2, bodyDark);
            c.Set(12, 2, bodyDark);
            c.Set(8, 3, bodyDark);
            c.Set(5, 3, top);
            c.Set(11, 3, top);
        }

        private static void DrawWeaponIcon(Canvas c, int kind)
        {
            switch (kind)
            {
                case 1: // Gran Espada de Fuego
                    c.Rect(6, 2, 4, 9, new Color32(190, 200, 216, 255));
                    c.Rect(7, 11, 2, 3, new Color32(255, 220, 150, 255));
                    c.Rect(3, 2, 10, 2, GoldDark);
                    c.Rect(7, 0, 2, 2, new Color32(120, 80, 40, 255));
                    c.Set(5, 6, Orange);
                    c.Set(10, 8, Orange);
                    c.Set(4, 10, Orange);
                    c.Set(11, 11, new Color32(255, 90, 40, 255));
                    break;
                case 2: // Dagas Rapidas
                    c.Rect(3, 6, 2, 8, new Color32(190, 220, 230, 255));
                    c.Set(2, 13, Cyan);
                    c.Rect(2, 4, 4, 2, GoldDark);
                    c.Rect(3, 2, 2, 2, new Color32(110, 70, 40, 255));
                    c.Rect(10, 5, 2, 8, new Color32(160, 200, 214, 255));
                    c.Set(11, 12, Cyan);
                    c.Rect(9, 3, 4, 2, GoldDark);
                    break;
                case 3: // Lanza Bumeran
                    c.Rect(2, 10, 5, 2, new Color32(150, 210, 230, 255));
                    c.Rect(4, 6, 8, 2, new Color32(150, 210, 230, 255));
                    c.Rect(10, 3, 2, 4, new Color32(120, 190, 220, 255));
                    c.Set(2, 12, Cyan);
                    c.Set(13, 2, Cyan);
                    c.Rect(5, 8, 5, 1, new Color32(220, 245, 255, 255));
                    break;
                default: // Espada Inicial
                    c.Rect(7, 3, 2, 9, new Color32(210, 220, 236, 255));
                    c.Set(7, 12, new Color32(250, 250, 255, 255));
                    c.Rect(4, 3, 8, 2, GoldDark);
                    c.Rect(7, 0, 2, 3, new Color32(120, 80, 40, 255));
                    c.Set(5, 6, SteelDark);
                    c.Set(10, 8, SteelDark);
                    break;
            }
        }

        private static void DrawPowerIcon(Canvas c, int kind)
        {
            switch (kind)
            {
                case 0: // Tónico de invulnerabilidad (reloj de arena dorado)
                    c.Rect(3, 13, 10, 2, Gold);
                    c.Rect(3, 1, 10, 2, Gold);
                    c.Rect(4, 12, 8, 1, GoldDark);
                    c.Rect(5, 10, 6, 2, new Color32(255, 236, 170, 255));
                    c.Rect(6, 8, 4, 2, new Color32(255, 236, 170, 255));
                    c.Rect(7, 6, 2, 2, new Color32(255, 236, 170, 255));
                    c.Rect(5, 3, 6, 2, new Color32(255, 236, 170, 255));
                    c.Set(4, 11, Cyan);
                    c.Set(11, 11, Cyan);
                    break;
                case 1: // Imán
                    c.Rect(3, 3, 3, 8, new Color32(210, 70, 70, 255));
                    c.Rect(10, 3, 3, 8, new Color32(210, 70, 70, 255));
                    c.Rect(3, 10, 10, 3, new Color32(210, 70, 70, 255));
                    c.Rect(3, 1, 3, 2, new Color32(220, 226, 236, 255));
                    c.Rect(10, 1, 3, 2, new Color32(220, 226, 236, 255));
                    c.Set(6, 6, new Color32(255, 140, 140, 255));
                    break;
                case 2: // Escudo
                    c.Rect(3, 8, 10, 5, new Color32(78, 150, 226, 255));
                    c.Rect(4, 5, 8, 3, new Color32(78, 150, 226, 255));
                    c.Rect(6, 3, 4, 2, new Color32(56, 116, 186, 255));
                    c.Rect(7, 1, 2, 2, new Color32(56, 116, 186, 255));
                    c.Rect(7, 4, 2, 8, Gold);
                    c.Rect(4, 8, 8, 1, Gold);
                    break;
                default: // Daño x2 (rayo)
                    c.Set(9, 13, new Color32(255, 214, 92, 255));
                    c.Rect(6, 9, 4, 3, new Color32(255, 214, 92, 255));
                    c.Rect(5, 7, 5, 2, new Color32(255, 170, 40, 255));
                    c.Rect(6, 5, 4, 2, new Color32(255, 170, 40, 255));
                    c.Rect(7, 2, 3, 3, new Color32(255, 214, 92, 255));
                    c.Set(5, 10, new Color32(255, 255, 220, 255));
                    break;
            }
        }

        private static void DrawSlash(Canvas c, int frame)
        {
            Color32 glow = new Color32(255, 255, 255, 230);
            float radius = 3f + frame * 2f;
            for (int i = 0; i < 16; i++)
            {
                float t = i / 15f;
                float ang = Mathf.Lerp(-0.9f, 0.9f, t);
                int x = Mathf.RoundToInt(3 + Mathf.Cos(ang) * radius * 1.4f);
                int y = Mathf.RoundToInt(8 + Mathf.Sin(ang) * radius);
                if (x >= 0 && x < 16 && y >= 0 && y < 16)
                {
                    c.Set(x, y, glow);
                    c.Set(x, y + 1, new Color32(160, 230, 255, 160));
                }
            }
        }

        private static void DrawProjectile(Canvas c, int frame, bool bolt)
        {
            if (bolt)
            {
                Color32 core = new Color32(180, 240, 255, 255);
                Color32 tail = new Color32(90, 170, 240, 255);
                c.Rect(2 + (frame % 2), 6, 11, 4, tail);
                c.Rect(4 + (frame % 2), 7, 9, 2, core);
                c.Set(1, 7, tail);
                c.Set(1, 8, tail);
                return;
            }

            // Cuchilla giratoria de 2 aspas que rota con el fotograma.
            Color32 blade = new Color32(196, 226, 244, 255);
            Color32 bladeDark = new Color32(120, 168, 200, 255);
            if (frame % 2 == 0)
            {
                c.Rect(7, 3, 2, 10, blade);
                c.Rect(3, 7, 10, 2, bladeDark);
                c.Set(7, 13, Color.white);
                c.Set(8, 2, Color.white);
                c.Set(2, 7, Color.white);
                c.Set(13, 8, Color.white);
            }
            else
            {
                c.Set(5, 5, blade);
                c.Set(6, 6, blade);
                c.Set(7, 7, blade);
                c.Set(8, 8, bladeDark);
                c.Set(9, 9, bladeDark);
                c.Set(10, 10, blade);
                c.Set(10, 5, bladeDark);
                c.Set(9, 6, bladeDark);
                c.Set(6, 9, blade);
                c.Set(5, 10, blade);
                c.Set(7, 8, Color.white);
                c.Set(8, 7, Color.white);
            }
        }

        private static void DrawShadow(Canvas c)
        {
            Color32 shadow = new Color32(20, 18, 30, 110);
            Disc(c, 8, 8, 6, 3, shadow);
            Disc(c, 8, 8, 4, 2, new Color32(20, 18, 30, 150));
        }

        private static void DrawParticle(Canvas c)
        {
            Color32 glow = new Color32(255, 255, 255, 230);
            c.Set(7, 7, glow);
            c.Set(8, 7, glow);
            c.Set(7, 8, glow);
            c.Set(8, 8, glow);
        }

        // ------------------------------------------------------------------
        // Utilidades de dibujo
        // ------------------------------------------------------------------
        private static void Disc(Canvas c, int cx, int cy, int rx, int ry, Color32 color)
        {
            if (rx <= 0 || ry <= 0)
            {
                c.Set(cx, cy, color);
                return;
            }
            for (int y = -ry; y <= ry; y++)
            {
                for (int x = -rx; x <= rx; x++)
                {
                    float nx = rx == 0 ? 0f : (float)x / rx;
                    float ny = ry == 0 ? 0f : (float)y / ry;
                    if (nx * nx + ny * ny <= 1.05f)
                    {
                        c.Set(cx + x, cy + y, color);
                    }
                }
            }
        }

        private sealed class Canvas
        {
            public readonly int W;
            public readonly int H;
            public readonly Color32[] Pixels;

            public Canvas(int w, int h)
            {
                W = w;
                H = h;
                Pixels = new Color32[w * h];
                for (int i = 0; i < Pixels.Length; i++)
                {
                    Pixels[i] = new Color32(0, 0, 0, 0);
                }
            }

            public void Set(int x, int y, Color32 color)
            {
                if (x < 0 || y < 0 || x >= W || y >= H)
                {
                    return;
                }
                Pixels[y * W + x] = color;
            }

            public void Rect(int x, int y, int w, int h, Color32 color)
            {
                for (int yy = y; yy < y + h; yy++)
                {
                    for (int xx = x; xx < x + w; xx++)
                    {
                        Set(xx, yy, color);
                    }
                }
            }

            public Sprite Build(string name)
            {
                Texture2D tex = new Texture2D(W, H, TextureFormat.RGBA32, false);
                tex.filterMode = FilterMode.Point;
                tex.wrapMode = TextureWrapMode.Clamp;
                tex.SetPixels32(Pixels);
                tex.Apply();
                Sprite sprite = Sprite.Create(tex, new Rect(0, 0, W, H), new Vector2(0.5f, 0.5f), PixelsPerUnit, 0, SpriteMeshType.FullRect);
                sprite.name = name;
                return sprite;
            }
        }
    }
}
