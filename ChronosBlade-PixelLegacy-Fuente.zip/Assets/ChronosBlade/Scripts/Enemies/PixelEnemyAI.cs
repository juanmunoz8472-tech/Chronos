using System.Collections;
using UnityEngine;

namespace ChronosBlade
{
    /// <summary>
    /// IA generica de enemigos: patrulla entre puntos, detecta al jugador por
    /// proximidad, lo persigue, ataca y suelta monedas/gemas al morir.
    /// Tres especies: Trashling (terrestre), Bat (volador) y Warden (guardian pesado).
    /// </summary>
    public class PixelEnemyAI : MonoBehaviour
    {
        // ---------------- Configuracion ----------------
        public EnemySpecies Species;
        public int MaxHealth = 30;
        public int CurrentHealth = 30;
        public int ContactDamage = 10;
        public int CoinDrop = 4;
        public int GemDropChance = 8;
        public float MoveSpeed = 2.3f;
        public float ChaseSpeedMultiplier = 1.4f;
        public float DetectionRange = 6.5f;
        public float AttackRange = 1.0f;
        public float AttackCooldown = 1.1f;
        public float KnockbackResistance;
        public bool IsFlying;
        public float VisualScale = 1f;

        public bool IsDead { get; private set; }
        public bool IsDying { get; private set; }

        // ---------------- Referencias ----------------
        private Rigidbody2D _rb;
        private SpriteRenderer _renderer;
        private Animator _animator;
        private Transform[] _patrolPoints;
        private PixelPlayerController _player;

        // ---------------- Estado ----------------
        private Vector2 _homePosition;
        private int _patrolIndex;
        private float _patrolDirection = -1f;
        private float _patrolEdge;
        private float _verticalVelocity;
        private bool _grounded;
        private float _attackTimer;
        private float _hurtFlashTimer;
        private float _frameTimer;
        private int _frameIndex;
        private float _bobPhase;
        private float _knockbackVelocity;
        private float _blockedTimer;
        private float _lastPositionX;
        private float _lifetime;
        private float _jumpCooldown;

        private void Awake()
        {
            _rb = GetComponent<Rigidbody2D>();
            if (_rb == null)
            {
                _rb = gameObject.AddComponent<Rigidbody2D>();
            }
            _rb.bodyType = RigidbodyType2D.Kinematic;
            _rb.useFullKinematicContacts = true;
            _rb.freezeRotation = true;

            _renderer = GetComponentInChildren<SpriteRenderer>();
            _animator = GetComponentInChildren<Animator>();
        }

        /// <summary>Fabricacion completa de un enemigo listo para pelear.</summary>
        public static PixelEnemyAI Spawn(EnemySpecies species, Vector2 position, Transform[] patrolPoints, int tier, float speedMultiplier = 1f)
        {
            GameObject go = new GameObject("Enemy_" + species);
            go.transform.position = position;

            SpriteRenderer renderer = go.AddComponent<SpriteRenderer>();
            renderer.sortingOrder = 18;

            BoxCollider2D collider = go.AddComponent<BoxCollider2D>();
            Rigidbody2D rb = go.AddComponent<Rigidbody2D>();
            rb.bodyType = RigidbodyType2D.Kinematic;
            rb.useFullKinematicContacts = true;

            PixelEnemyAI enemy = go.AddComponent<PixelEnemyAI>();
            enemy.Configure(species, tier, speedMultiplier);
            enemy._patrolPoints = patrolPoints;

            collider.size = enemy.IsFlying ? new Vector2(0.78f, 0.7f) : new Vector2(0.78f, 1.3f);
            collider.offset = enemy.IsFlying ? new Vector2(0f, 0.1f) : new Vector2(0f, 0.65f);

            return enemy;
        }

        /// <summary>Estadisticas por especie y nivel de dificultad (oleadas).</summary>
        public void Configure(EnemySpecies species, int tier, float speedMultiplier)
        {
            Species = species;
            tier = Mathf.Max(0, tier);
            float multiplier = Mathf.Max(0.5f, speedMultiplier);

            switch (species)
            {
                case EnemySpecies.Bat:
                    MaxHealth = 18 + tier * 7;
                    ContactDamage = 8 + tier * 2;
                    CoinDrop = 3 + tier;
                    MoveSpeed = 3.0f * multiplier;
                    IsFlying = true;
                    DetectionRange = 8.5f;
                    AttackRange = 0.95f;
                    AttackCooldown = 0.95f;
                    KnockbackResistance = 0.25f;
                    VisualScale = 1f;
                    break;
                case EnemySpecies.Warden:
                    MaxHealth = 80 + tier * 24;
                    ContactDamage = 18 + tier * 4;
                    CoinDrop = 12 + tier * 3;
                    GemDropChance = 30;
                    MoveSpeed = 1.8f * multiplier;
                    IsFlying = false;
                    DetectionRange = 7.5f;
                    AttackRange = 1.25f;
                    AttackCooldown = 1.35f;
                    KnockbackResistance = 0.7f;
                    VisualScale = 1.25f;
                    break;
                default:
                    MaxHealth = 26 + tier * 9;
                    ContactDamage = 10 + tier * 2;
                    CoinDrop = 4 + tier;
                    GemDropChance = 8;
                    MoveSpeed = 2.4f * multiplier;
                    IsFlying = false;
                    DetectionRange = 6.5f;
                    AttackRange = 1.0f;
                    AttackCooldown = 1.1f;
                    KnockbackResistance = 0f;
                    VisualScale = 1f;
                    break;
            }

            CurrentHealth = MaxHealth;
            _homePosition = transform.position;
            _patrolEdge = species == EnemySpecies.Warden ? 2.2f : 3.2f;
            transform.localScale = Vector3.one * VisualScale;
            _bobPhase = Random.Range(0f, Mathf.PI * 2f);
        }

        public void SetPatrolPoints(Transform[] points)
        {
            _patrolPoints = points;
        }

        private void Start()
        {
            _player = GameModeManager.Instance != null ? GameModeManager.Instance.Player : null;
            if (_player == null)
            {
                _player = FindObjectOfType<PixelPlayerController>();
            }

            if (_renderer != null)
            {
                _renderer.sprite = SpriteFor(0);
            }

            if (GameModeManager.Instance != null)
            {
                GameModeManager.Instance.RegisterEnemy(this);
            }

            // Pequeña proteccion al aparecer para que no ataquen instantaneamente.
            _attackTimer = 0.5f;
        }

        private void Update()
        {
            if (IsDying)
            {
                return;
            }

            _lifetime += Time.deltaTime;
            if (_jumpCooldown > 0f)
            {
                _jumpCooldown -= Time.deltaTime;
            }

            // Seguridad: si cae fuera del mundo, se elimina para no dejar basura.
            if (transform.position.y < -40f)
            {
                if (GameModeManager.Instance != null)
                {
                    GameModeManager.Instance.UnregisterEnemy(this);
                }
                Destroy(gameObject);
                return;
            }

            if (_hurtFlashTimer > 0f)
            {
                _hurtFlashTimer -= Time.deltaTime;
                if (_renderer != null)
                {
                    _renderer.color = _hurtFlashTimer > 0f ? new Color(1f, 0.6f, 0.6f, 1f) : Color.white;
                }
            }

            UpdateAnimation();

            if (_animator != null)
            {
                _animator.SetFloat("Speed", Mathf.Abs(_patrolDirection) * MoveSpeed);
                _animator.SetBool("Grounded", _grounded);
                _animator.SetBool("Dead", IsDead);
            }
        }

        private void FixedUpdate()
        {
            if (IsDead || IsDying)
            {
                return;
            }

            if (_player == null || _player.IsDead)
            {
                Patrol();
                ApplyManualGravity();
                return;
            }

            Vector2 enemyPosition = transform.position;
            Vector2 playerPosition = _player.transform.position;
            Vector2 toPlayer = playerPosition - enemyPosition;

            if (Mathf.Sqrt(toPlayer.sqrMagnitude) < DetectionRange)
            {
                bool playerAbove = playerPosition.y > enemyPosition.y + 1.2f;
                float horizontal = Mathf.Sign(toPlayer.x);
                float distance = Mathf.Abs(toPlayer.x);

                if (distance > AttackRange * 0.7f || Mathf.Abs(toPlayer.y) > 1.4f)
                {
                    MoveHorizontal(horizontal, MoveSpeed * ChaseSpeedMultiplier);
                }
                else
                {
                    Decelerate();
                }

                if (IsFlying)
                {
                    float targetY = playerPosition.y + 0.6f;
                    float dy = Mathf.Clamp((targetY - enemyPosition.y) * 2.4f, -MoveSpeed, MoveSpeed);
                    _verticalVelocity = Mathf.Lerp(_verticalVelocity, dy, 0.12f);
                }
                else if (playerAbove && _grounded && _jumpCooldown <= 0f)
                {
                    // Salto corto para alcanzar plataformas cercanas.
                    _verticalVelocity = 9.5f;
                    _jumpCooldown = 1.6f;
                }

                TryAttack(toPlayer);
                _blockedTimer = 0f;
            }
            else
            {
                Patrol();
            }

            ApplyManualGravity();

            if (_knockbackVelocity != 0f)
            {
                _knockbackVelocity = Mathf.MoveTowards(_knockbackVelocity, 0f, 26f * Time.fixedDeltaTime);
            }
        }

        private void Patrol()
        {
            if (_patrolPoints != null && _patrolPoints.Length > 1)
            {
                Transform target = _patrolPoints[_patrolIndex];
                if (target == null)
                {
                    _patrolIndex = (_patrolIndex + 1) % _patrolPoints.Length;
                    return;
                }
                float deltaX = target.position.x - transform.position.x;
                if (Mathf.Abs(deltaX) < 0.25f)
                {
                    _patrolIndex = (_patrolIndex + 1) % _patrolPoints.Length;
                }
                else
                {
                    MoveHorizontal(Mathf.Sign(deltaX), MoveSpeed);
                }
                return;
            }

            // Sin puntos asignados: patrulla alrededor del origen.
            float offset = transform.position.x - _homePosition.x;
            if (offset > _patrolEdge)
            {
                _patrolDirection = -1f;
            }
            else if (offset < -_patrolEdge)
            {
                _patrolDirection = 1f;
            }
            MoveHorizontal(_patrolDirection, MoveSpeed);
        }

        private void MoveHorizontal(float direction, float speed)
        {
            if (Mathf.Abs(direction) < 0.05f)
            {
                Decelerate();
                return;
            }

            Vector2 current = transform.position;

            // Deteccion de pared: si llevamos rato empujando y no avanzamos, invertimos.
            if (_blockedTimer > 0.15f && Mathf.Abs(current.x - _lastPositionX) < 0.01f)
            {
                _blockedTimer = 0f;
                _patrolDirection = -Mathf.Sign(direction);
                if (_patrolPoints != null && _patrolPoints.Length > 1)
                {
                    _patrolIndex = (_patrolIndex + 1) % _patrolPoints.Length;
                }
                _lastPositionX = current.x;
                return;
            }

            _blockedTimer += Time.fixedDeltaTime;
            _lastPositionX = current.x;

            float step = direction * speed * Time.fixedDeltaTime + _knockbackVelocity * Time.fixedDeltaTime;
            Vector2 move = current + new Vector2(step, 0f);
            if (_rb != null)
            {
                _rb.MovePosition(move);
            }
            else
            {
                transform.position = move;
            }

            if (_renderer != null)
            {
                _renderer.flipX = direction > 0f;
            }
        }

        private void Decelerate()
        {
            _blockedTimer = 0f;
        }

        private void ApplyManualGravity()
        {
            if (IsFlying)
            {
                _bobPhase += Time.fixedDeltaTime * 2.6f;
                float targetY = transform.position.y + _verticalVelocity * Time.fixedDeltaTime + Mathf.Sin(_bobPhase) * 0.008f;
                Vector2 target = new Vector2(transform.position.x, targetY);
                if (_rb != null)
                {
                    _rb.MovePosition(target);
                }
                else
                {
                    transform.position = target;
                }
                _grounded = false;
                return;
            }

            _verticalVelocity += Physics2D.gravity.y * 3.2f * Time.fixedDeltaTime;
            _verticalVelocity = Mathf.Max(_verticalVelocity, -26f);

            Vector2 next = (Vector2)transform.position + new Vector2(0f, _verticalVelocity * Time.fixedDeltaTime);

            Collider2D[] hits = Physics2D.OverlapBoxAll(next + new Vector2(0f, -0.62f), new Vector2(0.6f, 0.16f), 0f);
            _grounded = false;
            for (int i = 0; i < hits.Length; i++)
            {
                Collider2D hit = hits[i];
                if (hit == null || hit.isTrigger || hit.transform == transform || hit.GetComponentInParent<PixelEnemyAI>() == this)
                {
                    continue;
                }
                if (hit.GetComponentInParent<PixelEnemyAI>() != null)
                {
                    continue;
                }
                if (_verticalVelocity <= 0.1f)
                {
                    _grounded = true;
                    _verticalVelocity = 0f;
                    break;
                }
            }

            if (_rb != null)
            {
                _rb.MovePosition(next);
            }
            else
            {
                transform.position = next;
            }
        }

        private void TryAttack(Vector2 toPlayer)
        {
            if (_attackTimer > 0f)
            {
                _attackTimer -= Time.fixedDeltaTime;
                return;
            }

            float distance = toPlayer.magnitude;
            if (distance > AttackRange + 0.35f)
            {
                return;
            }

            _attackTimer = AttackCooldown;
            if (_player != null)
            {
                _player.TakeDamage(ContactDamage, transform.position.x);
            }
            Vfx.Puff(transform.position + Vector3.up * 0.5f, new Color(1f, 0.55f, 0.45f), 4);
            StartCoroutine(LungeAnimation());
            AudioFx.Play(Sfx.Hit, 0.45f);
        }

        private IEnumerator LungeAnimation()
        {
            Vector3 baseScale = Vector3.one * VisualScale;
            float elapsed = 0f;
            while (elapsed < 0.18f)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / 0.18f;
                float punch = 1f + Mathf.Sin(t * Mathf.PI) * 0.16f;
                transform.localScale = new Vector3(baseScale.x * punch, baseScale.y / punch, 1f);
                yield return null;
            }
            transform.localScale = baseScale;
        }

        /// <summary>Aplica daño al enemigo. Devuelve true si lo mata.</summary>
        public bool TakeDamage(int amount, Vector2 direction, float knockback)
        {
            if (IsDead || IsDying || amount <= 0)
            {
                return false;
            }

            CurrentHealth -= amount;
            _hurtFlashTimer = 0.14f;
            if (_renderer != null)
            {
                _renderer.color = new Color(1f, 0.55f, 0.55f, 1f);
            }

            float resistance = Mathf.Clamp01(1f - KnockbackResistance);
            _knockbackVelocity = Mathf.Sign(direction.x) * knockback * resistance;
            if (!IsFlying && resistance > 0.01f)
            {
                _verticalVelocity = Mathf.Max(_verticalVelocity, 3.2f * resistance);
            }

            if (CurrentHealth <= 0)
            {
                StartCoroutine(DieRoutine());
                return true;
            }

            return false;
        }

        /// <summary>Muerte: animacion, drop de monedas/gemas y aviso al gestor de modo.</summary>
        private IEnumerator DieRoutine()
        {
            IsDead = true;
            IsDying = true;

            BoxCollider2D collider = GetComponent<BoxCollider2D>();
            if (collider != null)
            {
                collider.enabled = false;
            }

            AudioFx.Play(Species == EnemySpecies.Warden ? Sfx.Defeat : Sfx.Die, 0.6f);
            Vfx.Spark(transform.position + Vector3.up * 0.6f, new Color(1f, 0.8f, 0.4f), 8);
            CameraFollow.Shake(Species == EnemySpecies.Warden ? 0.4f : 0.18f, 0.2f);

            SpawnDrops();

            if (GameModeManager.Instance != null)
            {
                GameModeManager.Instance.AddKill(CoinDrop);
                GameModeManager.Instance.UnregisterEnemy(this);
            }

            float elapsed = 0f;
            float duration = 0.55f;
            Vector3 baseScale = transform.localScale;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;
                transform.Rotate(0f, 0f, 420f * Time.deltaTime);
                transform.localScale = baseScale * (1f - t * 0.55f);
                if (_renderer != null)
                {
                    _renderer.color = new Color(1f, 1f - t * 0.6f, 1f - t * 0.6f, 1f - t);
                }
                yield return null;
            }

            Destroy(gameObject);
        }

        private void SpawnDrops()
        {
            int coinCount = Mathf.Clamp(CoinDrop / 3, 1, 6);
            int perCoin = Mathf.Max(1, CoinDrop / coinCount);
            for (int i = 0; i < coinCount; i++)
            {
                GameObject coinGo = new GameObject("Coin");
                coinGo.transform.position = transform.position + new Vector3(Random.Range(-0.7f, 0.7f), Random.Range(0.2f, 0.9f), 0f);
                SpriteRenderer renderer = coinGo.AddComponent<SpriteRenderer>();
                renderer.sprite = SpriteFactory.Get(PixelArtType.Coin, i % 4);
                renderer.sortingOrder = 16;
                renderer.transform.localScale = Vector3.one * 0.9f;
                CoinPickup coin = coinGo.AddComponent<CoinPickup>();
                coin.Value = perCoin;
            }

            if (Random.Range(0, 100) < GemDropChance)
            {
                GameObject gemGo = new GameObject("Gem");
                gemGo.transform.position = transform.position + new Vector3(Random.Range(-0.3f, 0.3f), 0.8f, 0f);
                SpriteRenderer renderer = gemGo.AddComponent<SpriteRenderer>();
                renderer.sprite = SpriteFactory.Get(PixelArtType.Gem, 0);
                renderer.sortingOrder = 17;
                renderer.transform.localScale = Vector3.one * 0.8f;
                GemPickup gem = gemGo.AddComponent<GemPickup>();
                gem.Value = 1;
            }

            if (Random.Range(0, 100) < 5)
            {
                GameObject heartGo = new GameObject("Heart");
                heartGo.transform.position = transform.position + new Vector3(0f, 0.9f, 0f);
                SpriteRenderer renderer = heartGo.AddComponent<SpriteRenderer>();
                renderer.sprite = SpriteFactory.Get(PixelArtType.Heart, 0);
                renderer.sortingOrder = 17;
                heartGo.AddComponent<HeartPickup>().Value = 20;
            }
        }

        // ------------------------------------------------------------------
        // ANIMACION PROCEDURAL
        // ------------------------------------------------------------------
        private Sprite SpriteFor(int frame)
        {
            switch (Species)
            {
                case EnemySpecies.Bat:
                    return SpriteFactory.Get(PixelArtType.BatFly, frame % 2);
                case EnemySpecies.Warden:
                    return SpriteFactory.Get(PixelArtType.WardenRun, frame % 3);
                default:
                    return SpriteFactory.Get(PixelArtType.TrashlingRun, frame % 2);
            }
        }

        private void UpdateAnimation()
        {
            if (_renderer == null)
            {
                return;
            }

            bool moving = Mathf.Abs(_patrolDirection) > 0.05f || IsFlying;
            float fps = Species == EnemySpecies.Warden ? 5f : 8f;
            _frameTimer += Time.deltaTime * (moving ? fps : fps * 0.35f);
            if (_frameTimer >= 1f)
            {
                _frameTimer = 0f;
                _frameIndex++;
            }
            _renderer.sprite = SpriteFor(_frameIndex);
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(transform.position, DetectionRange);
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(transform.position, AttackRange);
        }
    }
}
