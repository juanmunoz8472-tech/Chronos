using System.Collections.Generic;
using UnityEngine;

namespace ChronosBlade
{
    /// <summary>Base comun de los objetos recolectables (monedas, gemas, corazones).</summary>
    public abstract class PickupBase : MonoBehaviour
    {
        public int Value = 1;

        private bool _attracted;
        private float _attractSpeed;
        private Vector3 _attractTarget;
        private float _bobPhase;
        private Vector3 _basePosition;
        private SpriteRenderer _renderer;

        protected SpriteRenderer Renderer { get { return _renderer; } }

        protected virtual void Awake()
        {
            _renderer = GetComponent<SpriteRenderer>();
            _basePosition = transform.position;
            _bobPhase = Random.Range(0f, Mathf.PI * 2f);
        }

        public void AttractTo(Vector3 target, float speed)
        {
            _attracted = true;
            _attractSpeed = speed;
            _attractTarget = target + Vector3.up * 0.8f;
        }

        protected virtual void Update()
        {
            if (_attracted)
            {
                transform.position = Vector3.MoveTowards(transform.position, _attractTarget, _attractSpeed * Time.deltaTime);
                if (Vector3.Distance(transform.position, _attractTarget) < 0.35f)
                {
                    Collect(null);
                }
                return;
            }

            _bobPhase += Time.deltaTime * 3f;
            transform.position = _basePosition + Vector3.up * (Mathf.Sin(_bobPhase) * 0.09f);
        }

        protected void OnTriggerEnter2D(Collider2D other)
        {
            PixelPlayerController player = other != null ? other.GetComponentInParent<PixelPlayerController>() : null;
            if (player != null)
            {
                Collect(player);
            }
        }

        protected abstract void Collect(PixelPlayerController player);
    }

    /// <summary>Moneda dorada. Drop principal de los enemigos.</summary>
    public class CoinPickup : PickupBase
    {
        protected override void Collect(PixelPlayerController player)
        {
            if (player == null && GameModeManager.Instance != null)
            {
                player = GameModeManager.Instance.Player;
            }
            if (player == null)
            {
                return;
            }
            player.AddCoins(Value);
            AudioFx.Play(Sfx.Coin, 0.7f);
            Vfx.Spark(transform.position, new Color(1f, 0.85f, 0.35f), 4);
            Destroy(gameObject);
        }
    }

    /// <summary>Gema de cronos. Drop raro de enemigos y de cofres.</summary>
    public class GemPickup : PickupBase
    {
        protected override void Collect(PixelPlayerController player)
        {
            if (player == null && GameModeManager.Instance != null)
            {
                player = GameModeManager.Instance.Player;
            }
            if (player == null)
            {
                return;
            }
            player.AddGems(Value);
            AudioFx.Play(Sfx.Gem, 0.85f);
            Vfx.Spark(transform.position, new Color(0.6f, 0.95f, 1f), 7);
            Destroy(gameObject);
        }
    }

    /// <summary>Corazon que restaura salud.</summary>
    public class HeartPickup : PickupBase
    {
        protected override void Collect(PixelPlayerController player)
        {
            if (player == null)
            {
                return;
            }
            player.Heal(Value);
            Destroy(gameObject);
        }
    }

    /// <summary>Cofre de nivel: entrega monedas y, opcionalmente, un potenciador al inventario.</summary>
    public class LevelChest : MonoBehaviour
    {
        public int CoinReward = 120;
        public int GemReward = 1;
        public string PowerUpKey = "";
        private bool _opened;

        private void OnTriggerEnter2D(Collider2D other)
        {
            PixelPlayerController player = other != null ? other.GetComponentInParent<PixelPlayerController>() : null;
            if (player == null || _opened)
            {
                return;
            }
            _opened = true;

            player.AddCoins(CoinReward);
            if (GemReward > 0)
            {
                player.AddGems(GemReward);
            }
            if (!string.IsNullOrEmpty(PowerUpKey))
            {
                SaveSystem.AddPowerUp(PowerUpKey, 1);
            }

            AudioFx.Play(Sfx.Purchase, 0.9f);
            Vfx.Spark(transform.position + Vector3.up * 0.5f, new Color(1f, 0.85f, 0.4f), 12);
            CameraFollow.Shake(0.15f, 0.15f);

            SpriteRenderer renderer = GetComponent<SpriteRenderer>();
            if (renderer != null)
            {
                renderer.color = new Color(1f, 1f, 1f, 0.45f);
            }
            if (GameModeManager.Instance != null && GameModeManager.Instance.Hud != null)
            {
                GameModeManager.Instance.Hud.ShowToast("COFRE ABIERTO: +" + CoinReward + " MONEDAS", new Color(1f, 0.9f, 0.5f));
            }
        }
    }

    /// <summary>Pinchos/estaticos que dañan al jugador con un pequeño enfriamiento.</summary>
    public class StaticHazard : MonoBehaviour
    {
        public int Damage = 15;
        public float KnockbackX = 6f;
        private float _cooldown;

        private void Update()
        {
            if (_cooldown > 0f)
            {
                _cooldown -= Time.deltaTime;
            }
        }

        private void OnTriggerStay2D(Collider2D other)
        {
            if (_cooldown > 0f)
            {
                return;
            }
            PixelPlayerController player = other != null ? other.GetComponentInParent<PixelPlayerController>() : null;
            if (player == null || player.IsDead)
            {
                return;
            }
            _cooldown = 0.85f;
            player.TakeDamage(Damage, transform.position.x);
            Vfx.Spark(transform.position, new Color(1f, 0.5f, 0.4f), 5);
        }
    }

    /// <summary>Plataforma movil que transporta al jugador entre dos puntos.</summary>
    public class MovingPlatform : MonoBehaviour
    {
        public Vector2 PointA;
        public Vector2 PointB;
        public float Speed = 2.2f;
        public float PauseTime = 0.35f;

        private Rigidbody2D _rb;
        private readonly List<PixelPlayerController> _riders = new List<PixelPlayerController>();
        private float _progress;
        private int _direction = 1;
        private float _pauseTimer;
        private Vector2 _lastPosition;

        private void Awake()
        {
            _rb = GetComponent<Rigidbody2D>();
            if (_rb == null)
            {
                _rb = gameObject.AddComponent<Rigidbody2D>();
            }
            _rb.bodyType = RigidbodyType2D.Kinematic;
            _rb.useFullKinematicContacts = true;
            _lastPosition = transform.position;
        }

        private void FixedUpdate()
        {
            if (_pauseTimer > 0f)
            {
                _pauseTimer -= Time.fixedDeltaTime;
                return;
            }

            float length = Vector2.Distance(PointA, PointB);
            if (length < 0.01f)
            {
                return;
            }

            _progress += (_direction * Speed * Time.fixedDeltaTime) / length;
            if (_progress >= 1f)
            {
                _progress = 1f;
                _direction = -1;
                _pauseTimer = PauseTime;
            }
            else if (_progress <= 0f)
            {
                _progress = 0f;
                _direction = 1;
                _pauseTimer = PauseTime;
            }

            Vector2 target = Vector2.Lerp(PointA, PointB, _progress);
            Vector2 delta = target - (Vector2)transform.position;

            if (_rb != null)
            {
                _rb.MovePosition(target);
            }
            else
            {
                transform.position = target;
            }

            for (int i = _riders.Count - 1; i >= 0; i--)
            {
                PixelPlayerController rider = _riders[i];
                if (rider == null)
                {
                    _riders.RemoveAt(i);
                    continue;
                }
                rider.AddPlatformDelta(delta);
            }
        }

        private void OnCollisionEnter2D(Collision2D collision)
        {
            PixelPlayerController player = collision.collider != null ? collision.collider.GetComponentInParent<PixelPlayerController>() : null;
            if (player != null && !_riders.Contains(player))
            {
                _riders.Add(player);
            }
        }

        private void OnCollisionExit2D(Collision2D collision)
        {
            PixelPlayerController player = collision.collider != null ? collision.collider.GetComponentInParent<PixelPlayerController>() : null;
            if (player != null)
            {
                _riders.Remove(player);
            }
        }
    }

    /// <summary>Placa de impulso del modo Speedrun: acelera al jugador horizontalmente.</summary>
    public class SpeedPad : MonoBehaviour
    {
        public float BoostSpeed = 18f;
        public float Direction = 1f;
        private float _cooldown;

        private void Update()
        {
            if (_cooldown > 0f)
            {
                _cooldown -= Time.deltaTime;
            }
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            if (_cooldown > 0f)
            {
                return;
            }
            PixelPlayerController player = other != null ? other.GetComponentInParent<PixelPlayerController>() : null;
            if (player == null)
            {
                return;
            }
            _cooldown = 0.8f;
            player.SetExternalVelocity(new Vector2(BoostSpeed * Mathf.Sign(Direction), Mathf.Max(player.transform.position.y, 3f)));
            player.BoostX(BoostSpeed * Mathf.Sign(Direction));
            CameraFollow.Shake(0.12f, 0.12f);
        }
    }

    /// <summary>Limites del nivel y plano de muerte por caida.</summary>
    public class LevelBounds : MonoBehaviour
    {
        public float MinX = -40f;
        public float MaxX = 400f;
        public float KillY = -12f;
        public PixelPlayerController Player;

        private void LateUpdate()
        {
            if (Player == null || Player.IsDead)
            {
                return;
            }

            Vector3 position = Player.transform.position;
            if (position.x < MinX)
            {
                position.x = MinX;
                Player.SetExternalVelocity(new Vector2(0f, 0f));
                Player.transform.position = position;
            }
            else if (position.x > MaxX)
            {
                position.x = MaxX;
                Player.SetExternalVelocity(new Vector2(0f, 0f));
                Player.transform.position = position;
            }

            if (position.y < KillY && GameModeManager.Instance != null)
            {
                GameModeManager.Instance.HandleFall(Player);
            }
        }
    }

    /// <summary>Portal Temporal: meta del nivel de historia y de la pista de Speedrun.</summary>
    public class GoalPortal : MonoBehaviour
    {
        private bool _reached;
        private SpriteRenderer _renderer;

        private void Awake()
        {
            _renderer = GetComponent<SpriteRenderer>();
        }

        private void Update()
        {
            if (_renderer != null)
            {
                _renderer.sprite = SpriteFactory.Get(PixelArtType.Portal, (int)(Time.time * 8f) % 4);
                float pulse = 1f + Mathf.Sin(Time.time * 4f) * 0.05f;
                transform.localScale = new Vector3(pulse, pulse, 1f);
            }
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            if (_reached)
            {
                return;
            }
            PixelPlayerController player = other != null ? other.GetComponentInParent<PixelPlayerController>() : null;
            if (player == null)
            {
                return;
            }
            _reached = true;
            AudioFx.Play(Sfx.Goal, 1f);
            Vfx.Spark(transform.position, new Color(0.75f, 0.6f, 1f), 14);
            if (GameModeManager.Instance != null)
            {
                GameModeManager.Instance.OnGoalReached();
            }
        }
    }

    /// <summary>Punto de control: fija el respawn y cura al jugador la primera vez.</summary>
    public class Checkpoint : MonoBehaviour
    {
        public Vector3 SpawnOffset = new Vector3(0f, 1.2f, 0f);

        private bool _activated;
        private SpriteRenderer _renderer;

        private void Awake()
        {
            _renderer = GetComponent<SpriteRenderer>();
            if (_renderer != null)
            {
                _renderer.color = new Color(0.65f, 0.7f, 0.85f, 0.85f);
            }
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            if (_activated)
            {
                return;
            }
            PixelPlayerController player = other != null ? other.GetComponentInParent<PixelPlayerController>() : null;
            if (player == null)
            {
                return;
            }
            _activated = true;
            if (GameModeManager.Instance != null)
            {
                GameModeManager.Instance.SetCheckpoint(transform.position + SpawnOffset);
            }
            player.Heal(Mathf.RoundToInt(player.MaxHealth * 0.3f));
            AudioFx.Play(Sfx.PowerUp, 0.7f);
            Vfx.Spark(transform.position, new Color(0.7f, 1f, 0.8f), 8);
            if (_renderer != null)
            {
                _renderer.color = new Color(0.6f, 1f, 0.7f, 1f);
            }
            if (GameModeManager.Instance != null && GameModeManager.Instance.Hud != null)
            {
                GameModeManager.Instance.Hud.ShowToast("PUNTO DE CONTROL ACTIVADO", new Color(0.6f, 1f, 0.8f));
            }
        }
    }
}
