using UnityEngine;

namespace ChronosBlade
{
    /// <summary>
    /// Camara 2D con suavizado, limites de nivel y screen shake.
    /// Pensada para pantalla horizontal (Landscape).
    /// </summary>
    public class CameraFollow : MonoBehaviour
    {
        public Transform Target;
        public Vector3 Offset = new Vector3(0f, 1.9f, -10f);
        public float SmoothTime = 0.16f;
        public float LookAhead = 1.6f;

        public float MinX = -1000f;
        public float MaxX = 1000f;
        public float MinY = -1000f;
        public float MaxY = 1000f;
        public bool LockY;
        public float FixedY = 3f;

        private static CameraFollow _instance;
        private Vector3 _velocity;
        private float _shakeTimer;
        private float _shakeAmount;

        public static CameraFollow Instance
        {
            get { return _instance; }
        }

        private void Awake()
        {
            _instance = this;
        }

        private void OnDestroy()
        {
            if (_instance == this)
            {
                _instance = null;
            }
        }

        /// <summary>Activa una sacudida de camara (impactos, muertes, explosiones).</summary>
        public static void Shake(float amount, float duration)
        {
            if (_instance == null)
            {
                return;
            }
            _instance._shakeAmount = Mathf.Max(_instance._shakeAmount, amount);
            _instance._shakeTimer = Mathf.Max(_instance._shakeTimer, duration);
        }

        public void SnapToTarget()
        {
            if (Target == null)
            {
                return;
            }
            transform.position = Clamp(DesiredPosition(Target.position, Vector3.zero));
            _velocity = Vector3.zero;
        }

        public void SetBounds(float minX, float maxX, float minY, float maxY)
        {
            MinX = minX;
            MaxX = maxX;
            MinY = minY;
            MaxY = maxY;
        }

        private void LateUpdate()
        {
            if (Target == null)
            {
                return;
            }

            Vector3 desired = DesiredPosition(Target.position, _velocity);
            Vector3 smoothed = Vector3.SmoothDamp(transform.position, desired, ref _velocity, SmoothTime);
            smoothed = Clamp(smoothed);
            smoothed.z = -10f;

            if (_shakeTimer > 0f)
            {
                _shakeTimer -= Time.unscaledDeltaTime;
                float strength = _shakeAmount * Mathf.Clamp01(_shakeTimer / 0.25f);
                smoothed += new Vector3(Random.Range(-strength, strength), Random.Range(-strength, strength), 0f);
                if (_shakeTimer <= 0f)
                {
                    _shakeAmount = 0f;
                }
            }

            transform.position = smoothed;
        }

        private Vector3 DesiredPosition(Vector3 targetPosition, Vector3 currentVelocity)
        {
            float lookAhead = Mathf.Clamp(currentVelocity.x * 0.18f, -LookAhead, LookAhead);
            float y = LockY ? FixedY : targetPosition.y + Offset.y;
            return new Vector3(targetPosition.x + lookAhead + Offset.x, y, Offset.z);
        }

        private Vector3 Clamp(Vector3 position)
        {
            position.x = Mathf.Clamp(position.x, MinX, MaxX);
            if (!LockY)
            {
                position.y = Mathf.Clamp(position.y, MinY, MaxY);
            }
            return position;
        }
    }
}
