using System.Collections.Generic;
using UnityEngine;

namespace ChronosBlade
{
    /// <summary>
    /// Fondo con parallax por capas (colinas, ruinas y nubes) generado con pixel art
    /// procedural. Cada capa se desplaza a distinta velocidad al mover la camara.
    /// </summary>
    public class BackgroundScroller : MonoBehaviour
    {
        /// <summary>Instancia activa del fondo (solo puede existir una a la vez).</summary>
        public static BackgroundScroller Current { get; private set; }

        private class Layer
        {
            public Transform Transform;
            public float Factor;
            public float BaseX;
        }

        private readonly List<Layer> _layers = new List<Layer>();
        private Transform _camera;
        private float _cameraStartX;
        private float _span;

        public static BackgroundScroller Create(Camera camera, GroundTheme theme, float worldMinX, float worldMaxX, float baseY)
        {
            GameObject root = new GameObject("Backdrop");
            BackgroundScroller scroller = root.AddComponent<BackgroundScroller>();
            scroller.Build(camera, theme, worldMinX, worldMaxX, baseY);
            return scroller;
        }

        private void Awake()
        {
            Current = this;
        }

        private void OnDestroy()
        {
            if (Current == this)
            {
                Current = null;
            }
        }

        private void Build(Camera camera, GroundTheme theme, float worldMinX, float worldMaxX, float baseY)
        {
            _camera = camera != null ? camera.transform : null;
            _cameraStartX = _camera != null ? _camera.position.x : 0f;
            _span = Mathf.Max(40f, worldMaxX - worldMinX);

            Color farColor;
            Color midColor;
            Color cloudColor;

            switch (theme)
            {
                case GroundTheme.Rust:
                    farColor = new Color(0.20f, 0.14f, 0.20f, 0.95f);
                    midColor = new Color(0.32f, 0.20f, 0.24f, 0.95f);
                    cloudColor = new Color(0.55f, 0.42f, 0.42f, 0.55f);
                    break;
                case GroundTheme.Void:
                    farColor = new Color(0.16f, 0.13f, 0.28f, 0.95f);
                    midColor = new Color(0.26f, 0.20f, 0.42f, 0.95f);
                    cloudColor = new Color(0.52f, 0.45f, 0.85f, 0.5f);
                    break;
                case GroundTheme.Stone:
                    farColor = new Color(0.14f, 0.16f, 0.22f, 0.95f);
                    midColor = new Color(0.22f, 0.25f, 0.33f, 0.95f);
                    cloudColor = new Color(0.5f, 0.55f, 0.65f, 0.45f);
                    break;
                default:
                    farColor = new Color(0.16f, 0.26f, 0.34f, 0.95f);
                    midColor = new Color(0.22f, 0.36f, 0.42f, 0.95f);
                    cloudColor = new Color(0.75f, 0.82f, 0.88f, 0.5f);
                    break;
            }

            // Capa lejana: colinas altas.
            AddLayer(SpriteFactory.Hills(farColor, 2001), 0.28f, baseY + 1.2f, 4.0f, 3.2f, -30);
            // Capa media: colinas bajas + siluetas de ruinas.
            AddLayer(SpriteFactory.Hills(midColor, 4551), 0.48f, baseY - 0.6f, 4.0f, 2.4f, -25);
            AddLayer(SpriteFactory.Hills(midColor, 9773), 0.62f, baseY - 2.2f, 5.0f, 1.7f, -20);

            // Nubes a distintas alturas.
            for (int i = 0; i < 4; i++)
            {
                float factor = 0.10f + i * 0.05f;
                float y = baseY + 6.5f + i * 1.8f;
                int cloudOrder = -35 + i;
                AddLayer(SpriteFactory.Cloud(cloudColor), factor, y, 2.2f + i * 0.4f, 2f + i * 0.4f, cloudOrder);
            }
        }

        private void AddLayer(Sprite sprite, float factor, float y, float scaleX, float scaleY, int order)
        {
            GameObject go = new GameObject("BgLayer_" + _layers.Count);
            go.transform.SetParent(transform, true);
            SpriteRenderer renderer = go.AddComponent<SpriteRenderer>();
            renderer.sprite = sprite;
            renderer.sortingOrder = order;

            float width = sprite.bounds.size.x * scaleX;
            go.transform.position = new Vector3(0f, y, 0f);
            go.transform.localScale = new Vector3(scaleX, scaleY, 1f);

            Layer layer = new Layer();
            layer.Transform = go.transform;
            layer.Factor = factor;
            layer.BaseX = 0f;
            _layers.Add(layer);

            // Copias adicionales para cubrir todo el ancho del nivel.
            int copies = Mathf.CeilToInt(_span / Mathf.Max(1f, width)) + 2;
            for (int i = 1; i <= copies; i++)
            {
                GameObject copy = new GameObject("BgLayer_" + _layers.Count + "_" + i);
                copy.transform.SetParent(transform, true);
                SpriteRenderer copyRenderer = copy.AddComponent<SpriteRenderer>();
                copyRenderer.sprite = sprite;
                copyRenderer.sortingOrder = order;
                copy.transform.position = new Vector3(i * width, y, 0f);
                copy.transform.localScale = new Vector3(scaleX, scaleY, 1f);

                Layer copyLayer = new Layer();
                copyLayer.Transform = copy.transform;
                copyLayer.Factor = factor;
                copyLayer.BaseX = i * width;
                _layers.Add(copyLayer);
            }
        }

        private void LateUpdate()
        {
            if (_camera == null)
            {
                return;
            }

            float traveled = _camera.position.x - _cameraStartX;
            for (int i = 0; i < _layers.Count; i++)
            {
                Layer layer = _layers[i];
                if (layer.Transform == null)
                {
                    continue;
                }
                Vector3 position = layer.Transform.position;
                position.x = layer.BaseX + traveled * (1f - layer.Factor) * 0.55f;
                layer.Transform.position = position;
            }
        }
    }
}
