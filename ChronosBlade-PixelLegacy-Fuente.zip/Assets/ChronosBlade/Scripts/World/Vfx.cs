using UnityEngine;

namespace ChronosBlade
{
    /// <summary>Particula simple de vida corta usada por todos los efectos del juego.</summary>
    public class VfxSprite : MonoBehaviour
    {
        public float Life = 0.3f;
        public Vector2 Velocity;
        public float StartScale = 1f;
        public float EndScale = 0.2f;
        public float Spin;
        public Color BaseColor = Color.white;
        public Sprite[] Frames;
        public float FrameRate = 20f;

        private float _elapsed;
        private SpriteRenderer _renderer;

        private void Awake()
        {
            _renderer = GetComponent<SpriteRenderer>();
        }

        private void Update()
        {
            _elapsed += Time.deltaTime;
            float k = Life <= 0f ? 1f : Mathf.Clamp01(_elapsed / Life);

            transform.position += (Vector3)(Velocity * Time.deltaTime);
            Velocity *= 1f - Time.deltaTime * 1.6f;
            transform.localScale = Vector3.one * Mathf.Lerp(StartScale, EndScale, k);
            if (Spin != 0f)
            {
                transform.Rotate(0f, 0f, Spin * Time.deltaTime);
            }

            if (_renderer != null)
            {
                Color color = BaseColor;
                color.a = Mathf.Lerp(BaseColor.a, 0f, k);
                _renderer.color = color;
                if (Frames != null && Frames.Length > 0)
                {
                    int index = Mathf.Clamp((int)(_elapsed * FrameRate), 0, Frames.Length - 1);
                    _renderer.sprite = Frames[index];
                }
            }

            if (k >= 1f)
            {
                Destroy(gameObject);
            }
        }
    }

    /// <summary>Fabrica de efectos visuales pixel art.</summary>
    public static class Vfx
    {
        private static Transform _root;

        private static Transform Root()
        {
            if (_root == null)
            {
                GameObject rootGo = new GameObject("VfxRoot");
                _root = rootGo.transform;
            }
            return _root;
        }

        /// <summary>Arco de corte orientado segun la direccion del ataque.</summary>
        public static void Slash(Vector2 position, Vector2 direction, Color color, float scale = 1f)
        {
            GameObject go = new GameObject("VfxSlash");
            go.transform.SetParent(Root(), true);
            go.transform.position = position;
            go.transform.localScale = Vector3.one * scale;

            SpriteRenderer renderer = go.AddComponent<SpriteRenderer>();
            renderer.sprite = SpriteFactory.Get(PixelArtType.SlashEffect, 0);
            renderer.sortingOrder = 30;
            renderer.color = color;

            VfxSprite vfx = go.AddComponent<VfxSprite>();
            vfx.Life = 0.16f;
            vfx.StartScale = scale;
            vfx.EndScale = scale * 1.7f;
            vfx.BaseColor = color;
            vfx.FrameRate = 22f;
            vfx.Frames = new Sprite[]
            {
                SpriteFactory.Get(PixelArtType.SlashEffect, 0),
                SpriteFactory.Get(PixelArtType.SlashEffect, 1),
                SpriteFactory.Get(PixelArtType.SlashEffect, 2)
            };

            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            go.transform.rotation = Quaternion.Euler(0f, 0f, angle);
        }

        /// <summary>Nube de polvo (saltos, aterrizajes, muertes).</summary>
        public static void Puff(Vector2 position, Color color, int count)
        {
            for (int i = 0; i < count; i++)
            {
                GameObject go = new GameObject("VfxPuff");
                go.transform.SetParent(Root(), true);
                go.transform.position = position + new Vector2(Random.Range(-0.18f, 0.18f), Random.Range(-0.1f, 0.15f));

                SpriteRenderer renderer = go.AddComponent<SpriteRenderer>();
                renderer.sprite = SpriteFactory.Get(PixelArtType.Particle, 0);
                renderer.sortingOrder = 28;
                renderer.color = color;

                VfxSprite vfx = go.AddComponent<VfxSprite>();
                vfx.Life = Random.Range(0.25f, 0.45f);
                vfx.Velocity = new Vector2(Random.Range(-2.2f, 2.2f), Random.Range(0.6f, 3.2f));
                vfx.StartScale = Random.Range(0.8f, 1.6f) * 0.5f;
                vfx.EndScale = 0.1f;
                vfx.BaseColor = color;
            }
        }

        /// <summary>Chispas radiales (impactos, recolectar gemas, muerte).</summary>
        public static void Spark(Vector3 position, Color color, int count)
        {
            for (int i = 0; i < count; i++)
            {
                GameObject go = new GameObject("VfxSpark");
                go.transform.SetParent(Root(), true);
                go.transform.position = position;

                SpriteRenderer renderer = go.AddComponent<SpriteRenderer>();
                renderer.sprite = SpriteFactory.Get(PixelArtType.Particle, 0);
                renderer.sortingOrder = 32;
                renderer.color = color;

                float angle = Random.Range(0f, Mathf.PI * 2f);
                float speed = Random.Range(3.5f, 8.5f);

                VfxSprite vfx = go.AddComponent<VfxSprite>();
                vfx.Life = Random.Range(0.22f, 0.42f);
                vfx.Velocity = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * speed;
                vfx.StartScale = Random.Range(1f, 2f);
                vfx.EndScale = 0.05f;
                vfx.Spin = Random.Range(-360f, 360f);
                vfx.BaseColor = color;
            }
        }
    }
}
