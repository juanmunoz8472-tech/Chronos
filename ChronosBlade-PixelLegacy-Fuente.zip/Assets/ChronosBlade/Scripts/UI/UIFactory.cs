using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace ChronosBlade
{
    /// <summary>
    /// Fabrica de UI 100% por codigo, optimizada para pantalla HORIZONTAL (Landscape):
    /// canvas escalable a 1280x720, HUD lateral, joystick a la izquierda y botones
    /// de accion a la derecha. Sin prefabs ni escenas configuradas a mano.
    /// </summary>
    public static class UIFactory
    {
        public static readonly Color PanelColor = new Color(0.06f, 0.07f, 0.12f, 0.86f);
        public static readonly Color PanelLight = new Color(0.14f, 0.16f, 0.24f, 0.92f);
        public static readonly Color Accent = new Color(1f, 0.72f, 0.25f, 1f);
        public static readonly Color AccentBlue = new Color(0.45f, 0.78f, 1f, 1f);
        public static readonly Color AccentRed = new Color(1f, 0.42f, 0.42f, 1f);
        public static readonly Color TextColor = new Color(0.94f, 0.95f, 1f, 1f);

        private static Font _font;

        public static Font UIFont
        {
            get
            {
                if (_font == null)
                {
                    _font = Font.CreateDynamicFontFromOSFont(new string[] { "Arial", "Helvetica", "Liberation Sans", "DejaVu Sans" }, 32);
                }
                if (_font == null)
                {
                    try
                    {
                        _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
                    }
                    catch (System.Exception)
                    {
                        _font = null;
                    }
                }
                if (_font == null)
                {
                    try
                    {
                        _font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                    }
                    catch (System.Exception)
                    {
                        _font = null;
                    }
                }
                return _font;
            }
        }

        // ------------------------------------------------------------------
        // INFRAESTRUCTURA
        // ------------------------------------------------------------------
        public static Canvas CreateCanvas(string name, int sortingOrder)
        {
            EnsureEventSystem();

            GameObject go = new GameObject(name);
            Canvas canvas = go.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = sortingOrder;

            CanvasScaler scaler = go.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1280f, 720f);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            scaler.referencePixelsPerUnit = 100f;

            go.AddComponent<GraphicRaycaster>();
            return canvas;
        }

        public static void EnsureEventSystem()
        {
            EventSystem existing = Object.FindObjectOfType<EventSystem>();
            if (existing != null)
            {
                return;
            }
            GameObject go = new GameObject("EventSystem");
            go.AddComponent<EventSystem>();
            go.AddComponent<StandaloneInputModule>();
        }

        public static RectTransform CreateRect(Transform parent, string name, Vector2 anchorMin, Vector2 anchorMax, Vector2 pivot, Vector2 sizeDelta, Vector2 anchoredPosition)
        {
            GameObject go = new GameObject(name);
            go.transform.SetParent(parent, false);
            RectTransform rect = go.AddComponent<RectTransform>();
            rect.anchorMin = anchorMin;
            rect.anchorMax = anchorMax;
            rect.pivot = pivot;
            rect.sizeDelta = sizeDelta;
            rect.anchoredPosition = anchoredPosition;
            return rect;
        }

        public static Image CreateImage(Transform parent, string name, Sprite sprite, Color color, Vector2 anchorMin, Vector2 anchorMax, Vector2 pivot, Vector2 sizeDelta, Vector2 anchoredPosition)
        {
            RectTransform rect = CreateRect(parent, name, anchorMin, anchorMax, pivot, sizeDelta, anchoredPosition);
            Image image = rect.gameObject.AddComponent<Image>();
            image.sprite = sprite;
            image.color = color;
            image.raycastTarget = false;
            return image;
        }

        public static Image CreatePanel(Transform parent, string name, Color color, Vector2 anchorMin, Vector2 anchorMax, Vector2 pivot, Vector2 sizeDelta, Vector2 anchoredPosition)
        {
            Image image = CreateImage(parent, name, SpriteFactory.White, color, anchorMin, anchorMax, pivot, sizeDelta, anchoredPosition);
            return image;
        }

        public static Text CreateText(Transform parent, string name, string content, int fontSize, TextAnchor alignment, Color color, Vector2 anchorMin, Vector2 anchorMax, Vector2 pivot, Vector2 sizeDelta, Vector2 anchoredPosition)
        {
            RectTransform rect = CreateRect(parent, name, anchorMin, anchorMax, pivot, sizeDelta, anchoredPosition);
            Text text = rect.gameObject.AddComponent<Text>();
            text.font = UIFont;
            text.text = content;
            text.fontSize = fontSize;
            text.alignment = alignment;
            text.color = color;
            text.fontStyle = FontStyle.Bold;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Overflow;
            text.supportRichText = true;
            text.raycastTarget = false;

            Outline outline = rect.gameObject.AddComponent<Outline>();
            outline.effectColor = new Color(0f, 0f, 0f, 0.85f);
            outline.effectDistance = new Vector2(1.4f, -1.4f);
            return text;
        }

        public static Button CreateButton(Transform parent, string name, string label, int fontSize, Color baseColor, Vector2 anchorMin, Vector2 anchorMax, Vector2 pivot, Vector2 sizeDelta, Vector2 anchoredPosition, UnityEngine.Events.UnityAction onClick)
        {
            RectTransform rect = CreateRect(parent, name, anchorMin, anchorMax, pivot, sizeDelta, anchoredPosition);
            Image image = rect.gameObject.AddComponent<Image>();
            image.sprite = SpriteFactory.White;
            image.color = baseColor;
            image.raycastTarget = true;

            Button button = rect.gameObject.AddComponent<Button>();
            button.targetGraphic = image;
            ColorBlock colors = button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1.12f, 1.12f, 1.12f, 1f);
            colors.pressedColor = new Color(0.78f, 0.78f, 0.82f, 1f);
            colors.selectedColor = Color.white;
            colors.disabledColor = new Color(0.45f, 0.45f, 0.5f, 0.6f);
            colors.fadeDuration = 0.08f;
            button.colors = colors;

            if (onClick != null)
            {
                button.onClick.AddListener(onClick);
            }

            Text text = CreateText(rect, "Label", label, fontSize, TextAnchor.MiddleCenter, TextColor,
                Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            text.rectTransform.anchorMin = Vector2.zero;
            text.rectTransform.anchorMax = Vector2.one;
            text.rectTransform.offsetMin = new Vector2(6f, 4f);
            text.rectTransform.offsetMax = new Vector2(-6f, -4f);

            return button;
        }

        public static Image CreateBar(Transform parent, string name, Color fillColor, Vector2 anchorMin, Vector2 anchorMax, Vector2 pivot, Vector2 sizeDelta, Vector2 anchoredPosition, out Text label)
        {
            Image background = CreatePanel(parent, name, new Color(0f, 0f, 0f, 0.75f), anchorMin, anchorMax, pivot, sizeDelta, anchoredPosition);
            Image border = CreatePanel(background.transform, "Border", new Color(0.35f, 0.38f, 0.5f, 0.9f), Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            border.rectTransform.offsetMin = new Vector2(-2f, -2f);
            border.rectTransform.offsetMax = new Vector2(2f, 2f);

            Image fill = CreatePanel(background.transform, "Fill", fillColor, Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            fill.rectTransform.offsetMin = new Vector2(3f, 3f);
            fill.rectTransform.offsetMax = new Vector2(-3f, -3f);
            fill.type = Image.Type.Filled;
            fill.fillMethod = Image.FillMethod.Horizontal;
            fill.fillOrigin = (int)Image.OriginHorizontal.Left;
            fill.fillAmount = 1f;

            label = CreateText(background.transform, "Label", "", 20, TextAnchor.MiddleCenter, TextColor,
                Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            label.rectTransform.offsetMin = Vector2.zero;
            label.rectTransform.offsetMax = Vector2.zero;

            return fill;
        }

        // ------------------------------------------------------------------
        // HUD DE JUEGO (layout Landscape)
        // ------------------------------------------------------------------
        public static GameHud BuildGameHud(Canvas canvas, GameMode mode)
        {
            RectTransform root = CreateRect(canvas.transform, "GameHud", Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            GameHud hud = root.gameObject.AddComponent<GameHud>();

            // Vida (arriba-izquierda).
            Text healthLabel;
            Image healthFill = CreateBar(root, "HealthBar", new Color(0.95f, 0.28f, 0.32f, 1f),
                new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(0f, 1f),
                new Vector2(340f, 40f), new Vector2(18f, -18f), out healthLabel);
            hud.HealthFill = healthFill;
            hud.HealthText = healthLabel;

            hud.CharacterText = CreateText(root, "CharacterName", "KAEN", 22, TextAnchor.UpperLeft, Accent,
                new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(340f, 30f), new Vector2(18f, -62f));

            hud.WeaponIcon = CreateImage(root, "WeaponIcon", SpriteFactory.Get(PixelArtType.WeaponSword, 0), Color.white,
                new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(40f, 40f), new Vector2(18f, -96f));
            hud.WeaponText = CreateText(root, "WeaponName", "ESPADA INICIAL", 20, TextAnchor.UpperLeft, TextColor,
                new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(360f, 30f), new Vector2(64f, -96f));

            // Moneda y gemas (arriba-derecha).
            hud.CoinsText = CreateText(root, "Coins", "0", 26, TextAnchor.UpperRight, new Color(1f, 0.86f, 0.4f),
                new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(220f, 32f), new Vector2(-112f, -18f));
            hud.GemsText = CreateText(root, "Gems", "0", 26, TextAnchor.UpperRight, new Color(0.6f, 0.95f, 1f),
                new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(220f, 32f), new Vector2(-112f, -56f));

            // Informacion del modo (arriba-centro).
            hud.CenterText = CreateText(root, "CenterText", "", 38, TextAnchor.UpperCenter, TextColor,
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(720f, 52f), new Vector2(0f, -16f));
            hud.SubText = CreateText(root, "SubText", "", 22, TextAnchor.UpperCenter, AccentBlue,
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(760f, 34f), new Vector2(0f, -68f));

            // Iconos de potenciadores activos (derecha, bajo las gemas).
            hud.EffectIcons = new Image[4];
            hud.EffectFrames = new Image[4];
            for (int i = 0; i < 4; i++)
            {
                Image frame = CreateImage(root, "EffectFrame" + i, SpriteFactory.White, new Color(0f, 0f, 0f, 0.55f),
                    new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(58f, 58f), new Vector2(-18f - i * 64f, -100f));
                Image icon = CreateImage(frame.transform, "Icon", SpriteFactory.Get(PixelArtType.PowerTonic, 0), Color.white,
                    Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), new Vector2(-10f, -10f), Vector2.zero);
                icon.rectTransform.offsetMin = new Vector2(5f, 5f);
                icon.rectTransform.offsetMax = new Vector2(-5f, -5f);
                icon.enabled = false;
                frame.enabled = false;
                hud.EffectFrames[i] = frame;
                hud.EffectIcons[i] = icon;
            }

            // Aviso emergente.
            hud.ToastText = CreateText(root, "Toast", "", 24, TextAnchor.UpperCenter, Accent,
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(800f, 36f), new Vector2(0f, -350f));
            hud.ToastText.enabled = false;

            // Boton de pausa (siempre visible).
            CreateButton(root, "PauseButton", "II", 30, new Color(0.18f, 0.2f, 0.3f, 0.85f),
                new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(74f, 60f), new Vector2(-18f, -18f),
                delegate
                {
                    AudioFx.Play(Sfx.UiClick);
                    if (GameModeManager.Instance != null)
                    {
                        GameModeManager.Instance.TogglePause();
                    }
                });

            string title;
            switch (mode)
            {
                case GameMode.Survival:
                    title = "SUPERVIVENCIA";
                    break;
                case GameMode.Speedrun:
                    title = "SPEEDRUN";
                    break;
                default:
                    title = "MODO HISTORIA";
                    break;
            }
            hud.SetCenter(title, "");

            return hud;
        }

        // ------------------------------------------------------------------
        // CONTROLES TACTILES (Landscape: joystick izquierda, acciones derecha)
        // ------------------------------------------------------------------
        public static void BuildTouchControls(Canvas canvas)
        {
            RectTransform root = CreateRect(canvas.transform, "TouchControls", Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);

            // --- Joystick (izquierda) ---
            Image stickBackground = CreateImage(root, "JoystickBase", SpriteFactory.White, new Color(0.85f, 0.88f, 1f, 0.16f),
                Vector2.zero, Vector2.zero, Vector2.zero, new Vector2(300f, 300f), new Vector2(36f, 36f));
            stickBackground.raycastTarget = true;
            Image stickBorder = CreateImage(stickBackground.transform, "Border", SpriteFactory.White, new Color(0.9f, 0.95f, 1f, 0.22f),
                Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            stickBorder.rectTransform.offsetMin = new Vector2(-3f, -3f);
            stickBorder.rectTransform.offsetMax = new Vector2(3f, 3f);

            Image handle = CreateImage(stickBackground.transform, "Handle", SpriteFactory.White, new Color(1f, 1f, 1f, 0.45f),
                new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(130f, 130f), Vector2.zero);

            VirtualJoystick joystick = stickBackground.gameObject.AddComponent<VirtualJoystick>();
            joystick.Background = stickBackground.rectTransform;
            joystick.Handle = handle.rectTransform;
            joystick.Radius = 110f;

            // Etiquetas de direccion sobre el joystick.
            Text stickHint = CreateText(stickBackground.transform, "Hint", "MOVER", 18, TextAnchor.LowerCenter, new Color(1f, 1f, 1f, 0.6f),
                new Vector2(0f, 0f), new Vector2(1f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 26f), new Vector2(0f, 6f));
            stickHint.rectTransform.offsetMin = new Vector2(0f, 8f);

            // --- Boton de ataque (abajo-derecha, el mas grande) ---
            TouchButton attackButton = CreateActionButton(root, "AttackButton", "ATACAR", AccentRed,
                new Vector2(1f, 0f), new Vector2(-150f, 140f), new Vector2(200f, 200f), TouchButton.TouchAction.Attack);

            // --- Boton de salto / doble salto ---
            TouchButton jumpButton = CreateActionButton(root, "JumpButton", "SALTO", AccentBlue,
                new Vector2(1f, 0f), new Vector2(-360f, 230f), new Vector2(165f, 165f), TouchButton.TouchAction.Jump);

            // --- Ranura de potenciadores consumibles ---
            float slotX = -110f;
            for (int i = 0; i < ChronosCatalog.PowerUps.Count; i++)
            {
                PowerUpDefinition definition = ChronosCatalog.PowerUps[i];
                Image slot = CreateImage(root, "PowerSlot_" + definition.Key, SpriteFactory.White, new Color(0.12f, 0.14f, 0.22f, 0.8f),
                    new Vector2(1f, 0f), new Vector2(1f, 0f), new Vector2(1f, 0f), new Vector2(94f, 94f), new Vector2(slotX, 330f));
                slot.raycastTarget = true;

                Image icon = CreateImage(slot.transform, "Icon", definition.Icon == PixelArtType.PowerTonic ? SpriteFactory.Get(PixelArtType.PowerTonic, 0) : SpriteFactory.Get(definition.Icon, 0), Color.white,
                    Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), new Vector2(-24f, -24f), Vector2.zero);
                icon.rectTransform.offsetMin = new Vector2(16f, 16f);
                icon.rectTransform.offsetMax = new Vector2(-8f, -8f);

                Text count = CreateText(slot.transform, "Count", "0", 20, TextAnchor.LowerRight, Color.white,
                    Vector2.zero, Vector2.one, new Vector2(1f, 0f), new Vector2(40f, 26f), new Vector2(-4f, 4f));
                count.rectTransform.offsetMin = new Vector2(0f, 0f);
                count.rectTransform.offsetMax = new Vector2(0f, 0f);

                PowerUpSlotUI slotUi = slot.gameObject.AddComponent<PowerUpSlotUI>();
                slotUi.Definition = definition;
                slotUi.CountLabel = count;
                slotUi.Icon = icon;

                slotX -= 104f;
            }

            // Etiqueta recordatoria del teclado (util para pruebas en editor).
            CreateText(root, "KeyboardHint", "[TECLADO] A/D mover - ESPACIO saltar - J atacar - 1..4 potenciadores", 17,
                TextAnchor.LowerLeft, new Color(1f, 1f, 1f, 0.42f),
                new Vector2(0f, 0f), new Vector2(0f, 0f), new Vector2(0f, 0f), new Vector2(760f, 26f), new Vector2(40f, 344f));
        }

        private static TouchButton CreateActionButton(Transform parent, string name, string label, Color color, Vector2 anchor, Vector2 position, Vector2 size, TouchButton.TouchAction action)
        {
            Image image = CreateImage(parent, name, SpriteFactory.White, new Color(color.r, color.g, color.b, 0.55f),
                anchor, anchor, anchor, size, position);
            image.raycastTarget = true;

            Image inner = CreateImage(image.transform, "Inner", SpriteFactory.White, new Color(color.r * 1.2f, color.g * 1.2f, color.b * 1.2f, 0.35f),
                Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            inner.rectTransform.offsetMin = new Vector2(10f, 10f);
            inner.rectTransform.offsetMax = new Vector2(-10f, -10f);

            CreateText(image.transform, "Label", label, 26, TextAnchor.MiddleCenter, Color.white,
                Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);

            TouchButton button = image.gameObject.AddComponent<TouchButton>();
            button.Action = action;
            button.Target = image;
            button.NormalColor = new Color(color.r, color.g, color.b, 0.55f);
            button.PressedColor = new Color(color.r, color.g, color.b, 0.95f);
            return button;
        }
    }

    /// <summary>Joystick virtual para la esquina inferior izquierda (Landscape).</summary>
    public class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IDragHandler
    {
        public RectTransform Background;
        public RectTransform Handle;
        public float Radius = 110f;

        public void OnPointerDown(PointerEventData eventData)
        {
            UpdateStick(eventData);
        }

        public void OnDrag(PointerEventData eventData)
        {
            UpdateStick(eventData);
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            if (Handle != null)
            {
                Handle.anchoredPosition = Vector2.zero;
            }
            if (InputHub.Instance != null)
            {
                InputHub.Instance.SetStick(Vector2.zero);
            }
        }

        private void UpdateStick(PointerEventData eventData)
        {
            if (Background == null)
            {
                return;
            }
            Vector2 local;
            bool ok = RectTransformUtility.ScreenPointToLocalPointInRectangle(Background, eventData.position, eventData.pressEventCamera, out local);
            if (!ok)
            {
                return;
            }

            Vector2 clamped = Vector2.ClampMagnitude(local, Radius);
            if (Handle != null)
            {
                Handle.anchoredPosition = clamped;
            }
            if (InputHub.Instance != null)
            {
                InputHub.Instance.SetStick(clamped / Radius);
            }
        }
    }

    /// <summary>Boton tactil de accion (salto, ataque, potenciador).</summary>
    public class TouchButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler
    {
        public enum TouchAction
        {
            Jump,
            Attack,
            PowerUp
        }

        public TouchAction Action = TouchAction.Jump;
        public Image Target;
        public Color NormalColor = Color.white;
        public Color PressedColor = Color.white;
        public string PowerUpKey = "";

        public void OnPointerDown(PointerEventData eventData)
        {
            if (Target != null)
            {
                Target.color = PressedColor;
            }

            if (InputHub.Instance == null)
            {
                return;
            }

            switch (Action)
            {
                case TouchAction.Jump:
                    InputHub.Instance.SetJumpHeld(true);
                    break;
                case TouchAction.Attack:
                    InputHub.Instance.SetAttackHeld(true);
                    break;
                case TouchAction.PowerUp:
                    if (GameModeManager.Instance != null && GameModeManager.Instance.Player != null
                        && GameModeManager.Instance.Player.PowerUps != null && !string.IsNullOrEmpty(PowerUpKey))
                    {
                        GameModeManager.Instance.Player.PowerUps.ActivateFromInventory(PowerUpKey);
                    }
                    break;
            }
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            Release();
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            Release();
        }

        private void Release()
        {
            if (Target != null)
            {
                Target.color = NormalColor;
            }
            if (InputHub.Instance == null)
            {
                return;
            }
            if (Action == TouchAction.Jump)
            {
                InputHub.Instance.SetJumpHeld(false);
            }
            else if (Action == TouchAction.Attack)
            {
                InputHub.Instance.SetAttackHeld(false);
            }
        }
    }

    /// <summary>Ranura de consumible del HUD: muestra icono y cantidad disponible.</summary>
    public class PowerUpSlotUI : MonoBehaviour, IPointerDownHandler
    {
        public PowerUpDefinition Definition;
        public Text CountLabel;
        public Image Icon;

        private int _lastCount = -1;

        private void Update()
        {
            if (Definition == null)
            {
                return;
            }
            int count = SaveSystem.GetPowerUpCount(Definition.Key);
            if (count != _lastCount)
            {
                _lastCount = count;
                if (CountLabel != null)
                {
                    CountLabel.text = "x" + count;
                    CountLabel.color = count > 0 ? Color.white : new Color(1f, 1f, 1f, 0.35f);
                }
                if (Icon != null)
                {
                    Icon.color = count > 0 ? Color.white : new Color(1f, 1f, 1f, 0.3f);
                }
            }
        }

        public void OnPointerDown(PointerEventData eventData)
        {
            AudioFx.Play(Sfx.UiClick, 0.5f);
            if (GameModeManager.Instance != null && GameModeManager.Instance.Player != null && Definition != null)
            {
                GameModeManager.Instance.Player.PowerUps.ActivateFromInventory(Definition.Key);
            }
        }
    }

    /// <summary>HUD principal: vida, arma, moneda, gemas, informacion del modo y potenciadores activos.</summary>
    public class GameHud : MonoBehaviour
    {
        public Image HealthFill;
        public Text HealthText;
        public Text CharacterText;
        public Image WeaponIcon;
        public Text WeaponText;
        public Text CoinsText;
        public Text GemsText;
        public Text CenterText;
        public Text SubText;
        public Text ToastText;
        public Image[] EffectIcons;
        public Image[] EffectFrames;

        private PixelPlayerController _player;
        private float _toastTimer;

        public void Bind(PixelPlayerController player)
        {
            _player = player;
            if (_player != null)
            {
                if (CharacterText != null)
                {
                    CharacterText.text = _player.Character.DisplayName;
                }
                if (WeaponText != null)
                {
                    WeaponText.text = _player.Weapon.DisplayName + "  LV." + _player.Weapons.Level;
                }
                if (WeaponIcon != null)
                {
                    WeaponIcon.sprite = SpriteFactory.Get(WeaponIconType(_player.Weapon.Kind), 0);
                }
                _player.OnHealthChanged += RefreshHealth;
                _player.OnCurrencyChanged += RefreshCurrency;
            }
            RefreshHealth();
            RefreshCurrency();
        }

        private static PixelArtType WeaponIconType(WeaponKind kind)
        {
            switch (kind)
            {
                case WeaponKind.FireGreatsword: return PixelArtType.WeaponGreatsword;
                case WeaponKind.FastDaggers: return PixelArtType.WeaponDaggers;
                case WeaponKind.BoomerangLance: return PixelArtType.WeaponBoomerang;
                default: return PixelArtType.WeaponSword;
            }
        }

        public void RefreshHealth()
        {
            if (_player == null)
            {
                return;
            }
            if (HealthFill != null)
            {
                HealthFill.fillAmount = _player.MaxHealth <= 0 ? 0f : (float)_player.CurrentHealth / _player.MaxHealth;
                HealthFill.color = _player.CurrentHealth > _player.MaxHealth * 0.35f
                    ? new Color(0.95f, 0.28f, 0.32f, 1f)
                    : new Color(1f, 0.6f, 0.2f, 1f);
            }
            if (HealthText != null)
            {
                HealthText.text = _player.CurrentHealth + " / " + _player.MaxHealth;
            }
        }

        public void RefreshCurrency()
        {
            if (_player == null)
            {
                return;
            }
            if (CoinsText != null)
            {
                CoinsText.text = "MONEDAS " + _player.Coins;
            }
            if (GemsText != null)
            {
                GemsText.text = "GEMAS " + _player.Gems;
            }
        }

        public void SetCenter(string center, string sub)
        {
            if (CenterText != null)
            {
                CenterText.text = center;
            }
            if (SubText != null)
            {
                SubText.text = sub;
            }
        }

        public void ShowToast(string message, Color color)
        {
            if (ToastText == null)
            {
                return;
            }
            ToastText.text = message;
            ToastText.color = color;
            ToastText.enabled = true;
            _toastTimer = 2.6f;
        }

        private void Update()
        {
            if (_toastTimer > 0f)
            {
                _toastTimer -= Time.unscaledDeltaTime;
                if (_toastTimer <= 0f && ToastText != null)
                {
                    ToastText.enabled = false;
                }
                else if (ToastText != null)
                {
                    Color color = ToastText.color;
                    color.a = Mathf.Clamp01(_toastTimer);
                    ToastText.color = color;
                }
            }

            UpdateEffectIcons();
        }

        private void UpdateEffectIcons()
        {
            if (_player == null || _player.PowerUps == null || EffectIcons == null)
            {
                return;
            }

            int slot = 0;
            for (int i = 0; i < ChronosCatalog.PowerUps.Count && slot < EffectIcons.Length; i++)
            {
                PowerUpDefinition definition = ChronosCatalog.PowerUps[i];
                float remaining = _player.PowerUps.RemainingSeconds(definition.Id);
                bool active = definition.Duration > 0f ? remaining > 0f : remaining > 0f;

                if (EffectFrames != null && slot < EffectFrames.Length && EffectFrames[slot] != null)
                {
                    EffectFrames[slot].enabled = active;
                }
                if (active)
                {
                    EffectIcons[slot].enabled = true;
                    EffectIcons[slot].sprite = SpriteFactory.Get(definition.Icon, 0);
                    float ratio = definition.Duration > 0f ? Mathf.Clamp01(remaining / definition.Duration) : 1f;
                    Color color = Color.white;
                    color.a = 0.35f + ratio * 0.65f;
                    EffectIcons[slot].color = color;
                    if (EffectIcons[slot].transform.parent != null)
                    {
                        Image frame = EffectIcons[slot].transform.parent.GetComponent<Image>();
                        if (frame != null)
                        {
                            frame.color = new Color(0.1f, 0.12f, 0.2f, 0.55f + ratio * 0.35f);
                        }
                    }
                    slot++;
                }
                else if (EffectIcons[slot] != null)
                {
                    EffectIcons[slot].enabled = false;
                    slot++;
                }
            }
        }

        private void OnDestroy()
        {
            if (_player != null)
            {
                _player.OnHealthChanged -= RefreshHealth;
                _player.OnCurrencyChanged -= RefreshCurrency;
            }
        }
    }
}
