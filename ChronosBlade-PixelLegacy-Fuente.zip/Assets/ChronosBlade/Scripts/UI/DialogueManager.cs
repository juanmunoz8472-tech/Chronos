using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace ChronosBlade
{
    /// <summary>Una linea de dialogo: hablante, texto y color del nombre.</summary>
    public class DialogueLine
    {
        public string Speaker;
        public string Text;
        public Color SpeakerColor;

        public DialogueLine(string speaker, string text, Color speakerColor)
        {
            Speaker = speaker;
            Text = text;
            SpeakerColor = speakerColor;
        }
    }

    /// <summary>
    /// Cuadro de dialogo narrativo (Modo Historia) con efecto maquina de escribir,
    /// salto de texto y congelamiento del movimiento del jugador durante la charla.
    /// El cuadro se coloca en la parte superior-centro, optimizado para Landscape.
    /// </summary>
    public class DialogueManager : MonoBehaviour
    {
        public static DialogueManager Instance { get; private set; }

        public bool IsPlaying { get; private set; }
        public float CharactersPerSecond = 46f;
        public bool AutoAdvance = true;

        private RectTransform _box;
        private Text _speakerText;
        private Text _bodyText;
        private Text _hintText;
        private Image _panel;

        private PixelPlayerController _player;
        private System.Action _onComplete;
        private List<DialogueLine> _lines = new List<DialogueLine>();
        private int _index;
        private string _fullLine = "";
        private float _charProgress;
        private float _autoTimer;
        private bool _lineFinished;

        public static DialogueManager Create(Canvas canvas, PixelPlayerController player)
        {
            if (Instance != null)
            {
                Instance.AttachPlayer(player);
                return Instance;
            }

            RectTransform root = UIFactory.CreateRect(canvas.transform, "DialogueManager", Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            DialogueManager manager = root.gameObject.AddComponent<DialogueManager>();
            manager.Build(player);
            Instance = manager;
            return manager;
        }

        public void AttachPlayer(PixelPlayerController player)
        {
            _player = player;
        }

        private void Build(PixelPlayerController player)
        {
            _player = player;

            _panel = UIFactory.CreatePanel(transform, "DialogueBox", new Color(0.05f, 0.06f, 0.11f, 0.92f),
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f),
                new Vector2(950f, 200f), new Vector2(0f, -118f));
            _box = _panel.rectTransform;

            Image border = UIFactory.CreatePanel(_box, "Border", new Color(0.95f, 0.72f, 0.25f, 0.85f),
                Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            border.rectTransform.offsetMin = new Vector2(-4f, -4f);
            border.rectTransform.offsetMax = new Vector2(4f, 4f);
            border.transform.SetAsFirstSibling();

            Image inner = UIFactory.CreatePanel(_box, "Inner", new Color(0.05f, 0.06f, 0.11f, 1f),
                Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            inner.rectTransform.offsetMin = new Vector2(2f, 2f);
            inner.rectTransform.offsetMax = new Vector2(-2f, -2f);
            inner.transform.SetSiblingIndex(1);

            _speakerText = UIFactory.CreateText(_box, "Speaker", "LYRA", 28, TextAnchor.UpperLeft, ChronosCatalog.SpeakerLyra,
                new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(500f, 36f), new Vector2(26f, -14f));
            _speakerText.rectTransform.anchorMin = new Vector2(0f, 1f);
            _speakerText.rectTransform.anchorMax = new Vector2(0f, 1f);

            _bodyText = UIFactory.CreateText(_box, "Body", "", 25, TextAnchor.UpperLeft, UIFactory.TextColor,
                new Vector2(0f, 1f), new Vector2(1f, 1f), new Vector2(0.5f, 1f), new Vector2(-56f, 108f), new Vector2(0f, -58f));
            _bodyText.lineSpacing = 1.15f;

            _hintText = UIFactory.CreateText(_box, "Hint", "[TAP / ESPACIO] SIGUIENTE", 18, TextAnchor.LowerRight, new Color(1f, 1f, 1f, 0.55f),
                new Vector2(1f, 0f), new Vector2(1f, 0f), new Vector2(1f, 0f), new Vector2(420f, 30f), new Vector2(-22f, 12f));

            // Tocar el cuadro avanza/adelanta el texto (y tambien lo salta si esta escribiendo).
            Button boxButton = _panel.gameObject.AddComponent<Button>();
            boxButton.transition = Selectable.Transition.None;
            boxButton.onClick.AddListener(delegate { Advance(); });

            SetVisible(false);
        }

        private void SetVisible(bool visible)
        {
            if (_box != null)
            {
                _box.gameObject.SetActive(visible);
            }
        }

        /// <summary>Reproduce una conversacion completa y avisa al terminar.</summary>
        public void Play(List<DialogueLine> lines, System.Action onComplete)
        {
            if (lines == null || lines.Count == 0)
            {
                if (onComplete != null)
                {
                    onComplete();
                }
                return;
            }

            _lines = lines;
            _index = 0;
            _onComplete = onComplete;
            IsPlaying = true;
            SetVisible(true);
            FreezePlayer(true);
            StartLine(0);
        }

        private void StartLine(int index)
        {
            _index = index;
            DialogueLine line = _lines[_index];
            _fullLine = line.Text;
            _speakerText.text = line.Speaker;
            _speakerText.color = line.SpeakerColor;
            _bodyText.text = "";
            _charProgress = 0f;
            _autoTimer = 0f;
            _lineFinished = false;
            _hintText.text = "[TAP / ESPACIO] SIGUIENTE";
        }

        /// <summary>Avance manual: completa la linea o pasa a la siguiente.</summary>
        public void Advance()
        {
            if (!IsPlaying)
            {
                return;
            }

            if (!_lineFinished)
            {
                _charProgress = _fullLine.Length;
                _bodyText.text = _fullLine;
                _lineFinished = true;
                _autoTimer = 0f;
                return;
            }

            if (_index + 1 < _lines.Count)
            {
                StartLine(_index + 1);
            }
            else
            {
                Finish();
            }
        }

        /// <summary>Salta toda la conversacion de una vez.</summary>
        public void SkipAll()
        {
            if (!IsPlaying)
            {
                return;
            }
            Finish();
        }

        private void Finish()
        {
            IsPlaying = false;
            SetVisible(false);
            FreezePlayer(false);
            System.Action callback = _onComplete;
            _onComplete = null;
            _lines.Clear();
            if (callback != null)
            {
                callback();
            }
        }

        private void Update()
        {
            if (!IsPlaying)
            {
                return;
            }

            InputHub hub = InputHub.Instance;
            if (hub != null && hub.ConsumeAdvance())
            {
                AudioFx.Play(Sfx.UiClick, 0.35f);
                Advance();
                if (!IsPlaying)
                {
                    return;
                }
            }

            if (!_lineFinished)
            {
                _charProgress += Time.unscaledDeltaTime * CharactersPerSecond;
                int visible = Mathf.Clamp(Mathf.FloorToInt(_charProgress), 0, _fullLine.Length);
                string shown = _fullLine.Substring(0, visible);
                bool typing = visible < _fullLine.Length;
                _bodyText.text = shown + (typing && Mathf.PingPong(Time.unscaledTime * 3.5f, 1f) > 0.5f ? "|" : "");
                if (!typing)
                {
                    _lineFinished = true;
                    _bodyText.text = _fullLine;
                    _autoTimer = 0f;
                }
            }
            else if (AutoAdvance)
            {
                _autoTimer += Time.unscaledDeltaTime;
                float wait = ChronosCatalog.AutoAdvanceSeconds(_fullLine.Length);
                _hintText.text = "[TAP / ESPACIO] SIGUIENTE   (" + Mathf.CeilToInt(Mathf.Max(0f, wait - _autoTimer)) + ")";
                if (_autoTimer >= wait)
                {
                    Advance();
                }
            }
        }

        private void FreezePlayer(bool frozen)
        {
            if (_player == null && GameModeManager.Instance != null)
            {
                _player = GameModeManager.Instance.Player;
            }
            if (_player != null)
            {
                _player.FreezeForDialogue(frozen);
            }
        }

        private void OnDestroy()
        {
            if (Instance == this)
            {
                Instance = null;
            }
        }
    }
}
