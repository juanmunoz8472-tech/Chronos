using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace ChronosBlade
{
    /// <summary>
    /// Gestor centralizado de los 3 modos de juego:
    ///  - Historia: niveles con dialogos narrativos, checkpoints y portal final.
    ///  - Survival/Arcade: oleadas continuas con contador de bajas y dificultad creciente.
    ///  - Speedrun: cronometro de precision MM:SS:MS con records guardados.
    /// Tambien maneja pausa, vidas, muertes, recompensas y pantallas de resultado.
    /// </summary>
    public class GameModeManager : MonoBehaviour
    {
        public static GameModeManager Instance { get; private set; }

        // ---------------- Estado publico ----------------
        public GameMode Mode { get; private set; }
        public int StoryLevel { get; private set; }
        public PixelPlayerController Player { get; private set; }
        public GameHud Hud { get; private set; }
        public int Kills { get; private set; }
        public int Deaths { get; private set; }
        public int CoinsEarned { get; private set; }
        public float SpeedrunTime { get; private set; }
        public Vector3 LastCheckpoint { get; set; }
        public bool IsRunning { get; private set; }

        // ---------------- Configuracion de escenario ----------------
        public float ArenaMinX = -14f;
        public float ArenaMaxX = 14f;
        public float ArenaFloorY = 0f;
        public float SpawnHeight = 1.4f;

        // ---------------- Interno ----------------
        private float _spawnTimer;
        private float _runTimer;
        private bool _paused;
        private GameObject _pauseScreen;
        private GameObject _resultScreen;
        private bool _finished;
        private int _lastWave = 1;
        private readonly List<PixelEnemyAI> _enemies = new List<PixelEnemyAI>();
        private Transform[] _survivalPatrolA;
        private Transform[] _survivalPatrolB;

        public int AliveEnemies { get { return _enemies.Count; } }

        // ------------------------------------------------------------------
        // INICIALIZACION
        // ------------------------------------------------------------------
        public void Init(GameMode mode, int storyLevel, PixelPlayerController player, GameHud hud)
        {
            Instance = this;
            Mode = mode;
            StoryLevel = storyLevel;
            Player = player;
            Hud = hud;
            Kills = 0;
            Deaths = 0;
            CoinsEarned = 0;
            SpeedrunTime = 0f;
            _finished = false;
            _paused = false;

            if (Player != null)
            {
                LastCheckpoint = Player.transform.position;
                Player.OnCurrencyChanged += TrackCoins;
            }

            // Puntos de patrulla auxiliares para el modo Supervivencia.
            _survivalPatrolA = BuildPatrolPoints(new Vector3(ArenaMinX + 3f, ArenaFloorY + SpawnHeight * 0.5f, 0f), new Vector3(ArenaMaxX - 3f, ArenaFloorY + SpawnHeight * 0.5f, 0f));
            _survivalPatrolB = BuildPatrolPoints(new Vector3(ArenaMinX + 6f, ArenaFloorY + 4.5f, 0f), new Vector3(ArenaMaxX - 6f, ArenaFloorY + 4.5f, 0f));

            switch (Mode)
            {
                case GameMode.Survival:
                    StartCoroutine(SurvivalIntro());
                    break;
                case GameMode.Speedrun:
                    StartCoroutine(SpeedrunIntro());
                    break;
                default:
                    StartCoroutine(StoryIntro());
                    break;
            }
        }

        private Transform[] BuildPatrolPoints(Vector3 a, Vector3 b)
        {
            Transform[] points = new Transform[2];
            GameObject goA = new GameObject("PatrolA");
            goA.transform.position = a;
            GameObject goB = new GameObject("PatrolB");
            goB.transform.position = b;
            points[0] = goA.transform;
            points[1] = goB.transform;
            return points;
        }

        private void TrackCoins()
        {
            if (Player != null)
            {
                CoinsEarned = Player.Coins;
            }
        }

        private void OnDestroy()
        {
            if (Player != null)
            {
                Player.OnCurrencyChanged -= TrackCoins;
            }
            if (Instance == this)
            {
                Instance = null;
            }
        }

        // ------------------------------------------------------------------
        // ARRANQUES POR MODO
        // ------------------------------------------------------------------
        private IEnumerator StoryIntro()
        {
            IsRunning = false;
            if (Hud != null)
            {
                Hud.SetCenter(ChronosCatalog.StoryLevelName(StoryLevel), ChronosCatalog.StoryObjective(StoryLevel));
            }

            yield return new WaitForSeconds(0.35f);

            DialogueManager dialogue = DialogueManager.Instance;
            if (dialogue != null)
            {
                dialogue.AttachPlayer(Player);
                bool done = false;
                dialogue.Play(ChronosCatalog.StoryIntro(StoryLevel), delegate { done = true; });
                while (!done)
                {
                    yield return null;
                }
            }

            IsRunning = true;
            if (Hud != null)
            {
                Hud.ShowToast(ChronosCatalog.StoryObjective(StoryLevel), new Color(0.7f, 0.95f, 1f));
            }
        }

        private IEnumerator SurvivalIntro()
        {
            IsRunning = false;
            if (Hud != null)
            {
                Hud.ShowToast("SOBREVIVE. LAS OLEADAS NO TIENEN FIN.", new Color(1f, 0.5f, 0.5f));
            }

            yield return StartCoroutine(CountdownRoutine("SUPERVIVENCIA"));

            IsRunning = true;
            _spawnTimer = 0.4f;
            SpawnWaveEnemies(3);
        }

        private IEnumerator SpeedrunIntro()
        {
            IsRunning = false;
            if (Hud != null)
            {
                Hud.SetCenter("SPEEDRUN", "META: " + SaveSystem.FormatSpeedrun(ChronosCatalog.SpeedrunParTime(StoryLevel)) + "  |  RECORD: " + SaveSystem.FormatSpeedrun(SaveSystem.BestSpeedrunTime));
            }

            yield return StartCoroutine(CountdownRoutine("PREPARADO"));

            SpeedrunTime = 0f;
            IsRunning = true;
        }

        private IEnumerator CountdownRoutine(string label)
        {
            string[] steps = { "3", "2", "1", "¡YA!" };
            for (int i = 0; i < steps.Length; i++)
            {
                if (Hud != null)
                {
                    Hud.SetCenter(label, steps[i]);
                }
                AudioFx.Play(Sfx.UiClick, 0.6f);
                yield return new WaitForSeconds(0.62f);
            }
            if (Hud != null)
            {
                if (Mode == GameMode.Survival)
                {
                    Hud.SetCenter("SUPERVIVENCIA", "");
                }
                else if (Mode == GameMode.Speedrun)
                {
                    Hud.SetCenter("SPEEDRUN", "");
                }
            }
        }

        // ------------------------------------------------------------------
        // BUCLE
        // ------------------------------------------------------------------
        private void Update()
        {
            InputHub hub = InputHub.Instance;
            if (hub != null && hub.ConsumeCancel() && !_finished)
            {
                TogglePause();
            }

            if (_paused || _finished || !IsRunning)
            {
                return;
            }

            switch (Mode)
            {
                case GameMode.Survival:
                    UpdateSurvival();
                    break;
                case GameMode.Speedrun:
                    UpdateSpeedrun();
                    break;
                default:
                    UpdateStory();
                    break;
            }
        }

        private void UpdateStory()
        {
            _runTimer += Time.deltaTime;
        }

        private void UpdateSpeedrun()
        {
            SpeedrunTime += Time.deltaTime;
            if (Hud != null)
            {
                float par = ChronosCatalog.SpeedrunParTime(StoryLevel);
                string state = SpeedrunTime <= par ? "EN RITMO" : "RETRASADO";
                Hud.SetCenter(SaveSystem.FormatSpeedrun(SpeedrunTime),
                    "RECORD " + SaveSystem.FormatSpeedrun(SaveSystem.BestSpeedrunTime) + "  |  META " + SaveSystem.FormatSpeedrun(par) + "  |  " + state);
            }
        }

        private void UpdateSurvival()
        {
            int wave = ChronosCatalog.SurvivalWave(Kills);
            if (wave != _lastWave)
            {
                _lastWave = wave;
                AudioFx.Play(Sfx.Wave, 0.9f);
                if (Hud != null)
                {
                    Hud.ShowToast("OLEADA " + wave + " — MAX VIVOS " + ChronosCatalog.SurvivalMaxAlive(Kills), new Color(1f, 0.75f, 0.35f));
                }
                SpawnWaveEnemies(2);
            }

            if (Hud != null)
            {
                Hud.SetCenter("BAJAS " + Kills, "OLEADA " + wave + "  |  ENEMIGOS " + AliveEnemies + "  |  RECORD " + SaveSystem.BestSurvivalKills);
            }

            _spawnTimer -= Time.deltaTime;
            if (_spawnTimer <= 0f)
            {
                _spawnTimer = ChronosCatalog.SurvivalSpawnInterval(Kills);
                if (AliveEnemies < ChronosCatalog.SurvivalMaxAlive(Kills))
                {
                    SpawnSurvivalEnemy(0);
                }
            }
        }

        private void SpawnWaveEnemies(int count)
        {
            for (int i = 0; i < count; i++)
            {
                SpawnSurvivalEnemy(-1);
            }
        }

        /// <summary>Genera un enemigo segun la oleada actual. offsetX fija la posicion si se desea.</summary>
        private void SpawnSurvivalEnemy(int offsetX)
        {
            int wave = ChronosCatalog.SurvivalWave(Kills);
            int tier = Mathf.Clamp((wave - 1) / 2, 0, 4);
            float speedMultiplier = Mathf.Clamp(1f + Kills * 0.004f, 1f, 1.4f);

            EnemySpecies species;
            int roll = Random.Range(0, 100);
            if (wave >= 5 && roll < 18)
            {
                species = EnemySpecies.Warden;
            }
            else if (wave >= 2 && roll < 45)
            {
                species = EnemySpecies.Bat;
            }
            else
            {
                species = EnemySpecies.Trashling;
            }

            float x = offsetX != 0 ? offsetX : Random.Range(ArenaMinX + 1.5f, ArenaMaxX - 1.5f);
            float y = species == EnemySpecies.Bat
                ? ArenaFloorY + Random.Range(4f, 7f) + SpawnHeight
                : ArenaFloorY + SpawnHeight;

            Vector3 spawnPosition = new Vector3(x, y, 0f);
            Transform[] patrol = species == EnemySpecies.Bat ? _survivalPatrolB : _survivalPatrolA;

            PixelEnemyAI enemy = PixelEnemyAI.Spawn(species, spawnPosition, patrol, tier, speedMultiplier);
            Vfx.Puff(spawnPosition, new Color(0.8f, 0.5f, 1f), 6);
        }

        // ------------------------------------------------------------------
        // REGISTRO DE ENEMIGOS
        // ------------------------------------------------------------------
        public void RegisterEnemy(PixelEnemyAI enemy)
        {
            if (enemy != null && !_enemies.Contains(enemy))
            {
                _enemies.Add(enemy);
            }
        }

        public void UnregisterEnemy(PixelEnemyAI enemy)
        {
            _enemies.Remove(enemy);
        }

        /// <summary>Suma una baja y entrega el valor en monedas ya contabilizado por el enemigo.</summary>
        public void AddKill(int coinValue)
        {
            Kills++;
            if (Hud != null && coinValue > 0)
            {
                // Solo informamos visualmente cada 5 bajas para no saturar la pantalla.
                if (Kills % 5 == 0)
                {
                    Hud.ShowToast("RACHA DE " + Kills + " BAJAS", new Color(1f, 0.85f, 0.4f));
                }
            }
        }

        // ------------------------------------------------------------------
        // EVENTOS DE JUGADOR
        // ------------------------------------------------------------------
        public void SetCheckpoint(Vector3 position)
        {
            LastCheckpoint = position;
        }

        /// <summary>Caida fuera del nivel: respawn en el ultimo checkpoint con penalizacion.</summary>
        public void HandleFall(PixelPlayerController player)
        {
            if (player == null || player.IsDead || _finished)
            {
                return;
            }

            if (Mode == GameMode.Speedrun)
            {
                SpeedrunTime += 3f;
                if (Hud != null)
                {
                    Hud.ShowToast("CAIDA: +3 s DE PENALIZACION", new Color(1f, 0.6f, 0.4f));
                }
                player.RespawnAt(LastCheckpoint + Vector3.up * 0.4f);
                CameraFollow follow = CameraFollow.Instance;
                if (follow != null)
                {
                    follow.SnapToTarget();
                }
                return;
            }

            if (Mode == GameMode.Survival)
            {
                player.TakeDamage(20, player.transform.position.x + 1f);
                player.RespawnAt(LastCheckpoint + Vector3.up * 0.4f);
                return;
            }

            Deaths++;
            player.RespawnAt(LastCheckpoint + Vector3.up * 0.4f);
            CameraFollow storyFollow = CameraFollow.Instance;
            if (storyFollow != null)
            {
                storyFollow.SnapToTarget();
            }
            if (Hud != null)
            {
                Hud.ShowToast("DE VUELTA EN EL PUNTO DE CONTROL", new Color(0.8f, 0.9f, 1f));
            }
        }

        public void OnPlayerDied()
        {
            if (_finished)
            {
                return;
            }

            switch (Mode)
            {
                case GameMode.Survival:
                    EndSurvival();
                    break;
                case GameMode.Speedrun:
                    EndSpeedrun(false);
                    break;
                default:
                    EndStory(false);
                    break;
            }
        }

        public void OnGoalReached()
        {
            if (_finished)
            {
                return;
            }

            if (Mode == GameMode.Speedrun)
            {
                IsRunning = false;
                EndSpeedrun(true);
            }
            else if (Mode == GameMode.Story)
            {
                IsRunning = false;
                StartCoroutine(StoryVictoryRoutine());
            }
        }

        // ------------------------------------------------------------------
        // FINALES DE PARTIDA
        // ------------------------------------------------------------------
        private IEnumerator StoryVictoryRoutine()
        {
            DialogueManager dialogue = DialogueManager.Instance;
            if (dialogue != null)
            {
                bool done = false;
                dialogue.Play(ChronosCatalog.StoryOutro(StoryLevel), delegate { done = true; });
                while (!done)
                {
                    yield return null;
                }
            }
            EndStory(true);
        }

        private void EndStory(bool completed)
        {
            _finished = true;
            IsRunning = false;
            int reward = 0;
            if (completed)
            {
                reward = 60 * StoryLevel + Kills * 4;
                if (Player != null)
                {
                    Player.AddCoins(reward);
                }
                SaveSystem.RegisterStoryProgress(StoryLevel);
                AudioFx.Play(Sfx.Victory, 1f);
            }
            else
            {
                AudioFx.Play(Sfx.Defeat, 1f);
            }

            List<string> lines = new List<string>();
            lines.Add(ChronosCatalog.StoryLevelName(StoryLevel));
            lines.Add("ENEMIGOS DERROTADOS: " + Kills);
            lines.Add("GEMAS RECOLECTADAS: " + (Player != null ? Player.Gems : 0));
            lines.Add(completed ? "RECOMPENSA: +" + reward + " MONEDAS" : "CAIDAS: " + Deaths);

            List<ResultButton> buttons = new List<ResultButton>();
            if (completed)
            {
                if (StoryLevel < ChronosCatalog.StoryLevelCount)
                {
                    int nextLevel = StoryLevel + 1;
                    buttons.Add(new ResultButton("SIGUIENTE NIVEL", UIFactory.Accent, delegate { SceneBuilder.StartStory(nextLevel); }));
                }
                else
                {
                    buttons.Add(new ResultButton("VOLVER AL MENU", UIFactory.Accent, delegate { SceneBuilder.LoadMainMenu(); }));
                }
                buttons.Add(new ResultButton("REPETIR NIVEL", UIFactory.AccentBlue, delegate { SceneBuilder.StartStory(StoryLevel); }));
            }
            else
            {
                buttons.Add(new ResultButton("REINTENTAR NIVEL", UIFactory.AccentRed, delegate { SceneBuilder.StartStory(StoryLevel); }));
            }
            buttons.Add(new ResultButton("MENU PRINCIPAL", UIFactory.PanelLight, delegate { SceneBuilder.LoadMainMenu(); }));

            ShowResultScreen(completed ? "NIVEL COMPLETADO" : "HAS CAIDO EN COMBATE",
                completed ? new Color(0.55f, 1f, 0.7f) : new Color(1f, 0.5f, 0.5f),
                completed ? "El tiempo vuelve a fluir en tu favor." : "El Nucleo de Vex se burla de tu derrota.",
                lines, buttons);
        }

        private void EndSurvival()
        {
            _finished = true;
            IsRunning = false;
            bool record = SaveSystem.RegisterSurvivalRun(Kills, CoinsEarned);
            AudioFx.Play(Sfx.Defeat, 1f);

            List<string> lines = new List<string>();
            lines.Add("BAJAS TOTALES: " + Kills);
            lines.Add("OLEADA ALCANZADA: " + ChronosCatalog.SurvivalWave(Kills));
            lines.Add("MONEDAS RECOLECTADAS: " + CoinsEarned);
            lines.Add("GEMAS: " + (Player != null ? Player.Gems : 0));
            lines.Add(record ? "¡NUEVO RECORD PERSONAL!" : "RECORD ACTUAL: " + SaveSystem.BestSurvivalKills + " BAJAS");

            List<ResultButton> buttons = new List<ResultButton>();
            buttons.Add(new ResultButton("REINTENTAR", UIFactory.Accent, delegate { SceneBuilder.StartSurvival(); }));
            buttons.Add(new ResultButton("MENU PRINCIPAL", UIFactory.PanelLight, delegate { SceneBuilder.LoadMainMenu(); }));

            ShowResultScreen("GAME OVER", new Color(1f, 0.45f, 0.45f),
                record ? "¡Has grabado tu nombre en el tiempo!" : "Las oleadas no perdonaron... esta vez.",
                lines, buttons);
        }

        private void EndSpeedrun(bool reachedGoal)
        {
            _finished = true;
            IsRunning = false;

            float finalTime = Mathf.Max(SpeedrunTime, 0.01f);
            bool record = reachedGoal && SaveSystem.RegisterSpeedrunTime(finalTime);
            AudioFx.Play(reachedGoal ? Sfx.Victory : Sfx.Defeat, 1f);

            List<string> lines = new List<string>();
            lines.Add("TIEMPO: " + SaveSystem.FormatSpeedrun(finalTime));
            lines.Add("META (PAR): " + SaveSystem.FormatSpeedrun(ChronosCatalog.SpeedrunParTime(StoryLevel)));
            lines.Add("RECORD: " + SaveSystem.FormatSpeedrun(SaveSystem.BestSpeedrunTime));
            lines.Add(reachedGoal ? "NIVEL SUPERADO" : "PRUEBA FALLIDA");
            if (record)
            {
                lines.Add("¡NUEVO RECORD!");
            }

            List<ResultButton> buttons = new List<ResultButton>();
            buttons.Add(new ResultButton("REINTENTAR", UIFactory.Accent, delegate { SceneBuilder.StartSpeedrun(StoryLevel); }));
            buttons.Add(new ResultButton("MENU PRINCIPAL", UIFactory.PanelLight, delegate { SceneBuilder.LoadMainMenu(); }));

            ShowResultScreen(reachedGoal ? "META ALCANZADA" : "CRONOMETRO DETENIDO",
                reachedGoal ? new Color(0.6f, 0.95f, 1f) : new Color(1f, 0.5f, 0.5f),
                reachedGoal ? "Precision quirurgica, cronomante." : "El tiempo tambien cobra sus deudas.",
                lines, buttons);
        }

        // ------------------------------------------------------------------
        // PAUSA Y PANTALLAS
        // ------------------------------------------------------------------
        public void TogglePause()
        {
            if (_finished)
            {
                return;
            }

            if (_paused)
            {
                Resume();
            }
            else
            {
                Pause();
            }
        }

        public void Pause()
        {
            if (_paused || _finished)
            {
                return;
            }
            _paused = true;
            Time.timeScale = 0f;

            Canvas canvas = SceneBuilder.FindGameCanvas();
            if (canvas == null)
            {
                return;
            }

            Image dim = UIFactory.CreatePanel(canvas.transform, "PauseScreen", new Color(0f, 0f, 0f, 0.72f),
                Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            dim.raycastTarget = true;
            _pauseScreen = dim.gameObject;

            Image card = UIFactory.CreatePanel(dim.transform, "Card", UIFactory.PanelColor,
                new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(620f, 460f), Vector2.zero);

            UIFactory.CreateText(card.transform, "Title", "PAUSA", 44, TextAnchor.UpperCenter, UIFactory.Accent,
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(520f, 52f), new Vector2(0f, -24f));

            UIFactory.CreateText(card.transform, "Info",
                SaveSystem.FormatSpeedrun(SpeedrunTime) + "   |   BAJAS " + Kills + "   |   MONEDAS " + (Player != null ? Player.Coins : 0)
                + "\n\nMUSICA: " + (AudioFx.MusicEnabled ? "ACTIVADA" : "DESACTIVADA"),
                22, TextAnchor.MiddleCenter, UIFactory.TextColor,
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(540f, 120f), new Vector2(0f, -92f));

            UIFactory.CreateButton(card.transform, "Resume", "CONTINUAR", 28, UIFactory.Accent,
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(460f, 74f), new Vector2(0f, -226f),
                delegate { AudioFx.Play(Sfx.UiClick); Resume(); });

            UIFactory.CreateButton(card.transform, "ToggleMusic", "MUSICA ON/OFF", 26, UIFactory.AccentBlue,
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(460f, 66f), new Vector2(0f, -308f),
                delegate
                {
                    AudioFx.ToggleMusic();
                    AudioFx.Play(Sfx.UiClick);
                });

            UIFactory.CreateButton(card.transform, "Restart", "REINTENTAR", 26, UIFactory.AccentRed,
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(220f, 60f), new Vector2(-120f, -382f),
                delegate
                {
                    AudioFx.Play(Sfx.UiClick);
                    RestartCurrentMode();
                });

            UIFactory.CreateButton(card.transform, "Menu", "MENU", 26, UIFactory.PanelLight,
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(220f, 60f), new Vector2(120f, -382f),
                delegate
                {
                    AudioFx.Play(Sfx.UiClick);
                    Time.timeScale = 1f;
                    SceneBuilder.LoadMainMenu();
                });
        }

        public void Resume()
        {
            _paused = false;
            Time.timeScale = 1f;
            if (_pauseScreen != null)
            {
                Destroy(_pauseScreen);
                _pauseScreen = null;
            }
            if (InputHub.Instance != null)
            {
                InputHub.Instance.ClearAll();
            }
        }

        private void RestartCurrentMode()
        {
            Time.timeScale = 1f;
            switch (Mode)
            {
                case GameMode.Survival:
                    SceneBuilder.StartSurvival();
                    break;
                case GameMode.Speedrun:
                    SceneBuilder.StartSpeedrun(StoryLevel);
                    break;
                default:
                    SceneBuilder.StartStory(StoryLevel);
                    break;
            }
        }

        private class ResultButton
        {
            public string Label;
            public Color Color;
            public System.Action Action;

            public ResultButton(string label, Color color, System.Action action)
            {
                Label = label;
                Color = color;
                Action = action;
            }
        }

        /// <summary>Pantalla modal de resultados/salida utilizada por los 3 modos.</summary>
        private void ShowResultScreen(string title, Color titleColor, string subtitle, List<string> lines, List<ResultButton> buttons)
        {
            Canvas canvas = SceneBuilder.FindGameCanvas();
            if (canvas == null)
            {
                return;
            }

            Image dim = UIFactory.CreatePanel(canvas.transform, "ResultScreen", new Color(0f, 0f, 0f, 0.78f),
                Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            dim.raycastTarget = true;
            _resultScreen = dim.gameObject;

            Image card = UIFactory.CreatePanel(dim.transform, "Card", UIFactory.PanelColor,
                new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(880f, 520f), Vector2.zero);

            UIFactory.CreateText(card.transform, "Title", title, 50, TextAnchor.UpperCenter, titleColor,
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(760f, 60f), new Vector2(0f, -26f));

            UIFactory.CreateText(card.transform, "Subtitle", subtitle, 24, TextAnchor.UpperCenter, UIFactory.TextColor,
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(760f, 40f), new Vector2(0f, -92f));

            string body = "";
            for (int i = 0; i < lines.Count; i++)
            {
                body += lines[i];
                if (i < lines.Count - 1)
                {
                    body += "\n";
                }
            }

            UIFactory.CreateText(card.transform, "Body", body, 24, TextAnchor.MiddleCenter, new Color(0.85f, 0.9f, 1f),
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(780f, 200f), new Vector2(0f, -146f));

            float spacing = 300f;
            float startX = -(buttons.Count - 1) * spacing * 0.5f;
            for (int i = 0; i < buttons.Count; i++)
            {
                ResultButton button = buttons[i];
                UIFactory.CreateButton(card.transform, "ResultButton" + i, button.Label, 26, button.Color,
                    new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(272f, 78f),
                    new Vector2(startX + i * spacing, -430f),
                    delegate
                    {
                        AudioFx.Play(Sfx.UiClick);
                        button.Action();
                    });
            }
        }
    }
}
