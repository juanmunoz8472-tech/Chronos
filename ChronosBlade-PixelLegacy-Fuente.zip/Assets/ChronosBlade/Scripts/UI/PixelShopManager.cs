using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace ChronosBlade
{
    /// <summary>
    /// Tienda completa optimizada para UI Landscape, con tres secciones:
    ///  - PERSONAJES: comprar y seleccionar heroes desbloqueables.
    ///  - ARMAS: comprar, equipar y subir de nivel cada arma.
    ///  - POTENCIADORES: comprar consumibles para usar durante la partida.
    /// Verifica saldo (Monedas/Gemas), descuenta automaticamente y guarda todo
    /// en el inventario persistente de PlayerPrefs a traves de SaveSystem.
    /// </summary>
    public class PixelShopManager : MonoBehaviour
    {
        public static PixelShopManager Instance { get; private set; }

        private const int TabCharacters = 0;
        private const int TabWeapons = 1;
        private const int TabPowerUps = 2;

        private int _tab = TabCharacters;
        private Canvas _canvas;
        private RectTransform _content;
        private Text _coinsText;
        private Text _gemsText;
        private Text _statusText;
        private Text[] _tabLabels = new Text[3];
        private Image[] _tabBackgrounds = new Image[3];
        private readonly List<GameObject> _cards = new List<GameObject>();

        private readonly Color TabActive = new Color(0.98f, 0.72f, 0.25f, 1f);
        private readonly Color TabIdle = new Color(0.16f, 0.18f, 0.27f, 1f);

        // ------------------------------------------------------------------
        // APERTURA / CIERRE
        // ------------------------------------------------------------------
        public static void Open()
        {
            if (Instance != null)
            {
                return;
            }
            GameObject go = new GameObject("PixelShop");
            PixelShopManager shop = go.AddComponent<PixelShopManager>();
            shop.Build();
            Instance = shop;
            AudioFx.PlayMusic(MusicMood.Menu);
        }

        public void Close()
        {
            AudioFx.Play(Sfx.UiClick);
            SaveSystem.Save();
            Destroy(gameObject);
        }

        private void OnDestroy()
        {
            if (Instance == this)
            {
                Instance = null;
            }
        }

        private void Build()
        {
            SaveSystem.Load();

            _canvas = UIFactory.CreateCanvas("ShopCanvas", 60);
            _canvas.transform.SetParent(transform, false);

            Image dim = UIFactory.CreatePanel(_canvas.transform, "Dim", new Color(0.02f, 0.02f, 0.05f, 0.86f),
                Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            dim.raycastTarget = true;

            Image panel = UIFactory.CreatePanel(dim.transform, "Panel", UIFactory.PanelColor,
                new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(1200f, 660f), Vector2.zero);

            Image header = UIFactory.CreatePanel(panel.transform, "Header", new Color(0.09f, 0.1f, 0.17f, 1f),
                new Vector2(0f, 1f), new Vector2(1f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, 84f), Vector2.zero);
            header.rectTransform.offsetMin = new Vector2(6f, 0f);
            header.rectTransform.offsetMax = new Vector2(-6f, 0f);

            UIFactory.CreateText(header.transform, "Title", "TIENDA DEL CRONOMANTE", 34, TextAnchor.MiddleLeft, UIFactory.Accent,
                new Vector2(0f, 0.5f), new Vector2(0f, 0.5f), new Vector2(0f, 0.5f), new Vector2(600f, 44f), new Vector2(22f, 0f));

            _coinsText = UIFactory.CreateText(header.transform, "Coins", "", 26, TextAnchor.MiddleRight, new Color(1f, 0.86f, 0.4f),
                new Vector2(1f, 0.5f), new Vector2(1f, 0.5f), new Vector2(1f, 0.5f), new Vector2(300f, 36f), new Vector2(-232f, 12f));
            _gemsText = UIFactory.CreateText(header.transform, "Gems", "", 26, TextAnchor.MiddleRight, new Color(0.6f, 0.95f, 1f),
                new Vector2(1f, 0.5f), new Vector2(1f, 0.5f), new Vector2(1f, 0.5f), new Vector2(300f, 36f), new Vector2(-232f, -20f));

            UIFactory.CreateButton(header.transform, "Close", "CERRAR", 24, UIFactory.AccentRed,
                new Vector2(1f, 0.5f), new Vector2(1f, 0.5f), new Vector2(1f, 0.5f), new Vector2(140f, 56f), new Vector2(-16f, 0f),
                delegate { Close(); });

            // Pestanas.
            string[] tabNames = { "PERSONAJES", "ARMAS", "POTENCIADORES" };
            for (int i = 0; i < tabNames.Length; i++)
            {
                int tabIndex = i;
                float x = -395f + i * 280f;
                Button tabButton = UIFactory.CreateButton(panel.transform, "Tab" + i, tabNames[i], 24, TabIdle,
                    new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(264f, 56f), new Vector2(x, -104f),
                    delegate
                    {
                        AudioFx.Play(Sfx.UiClick);
                        SetTab(tabIndex);
                    });
                _tabLabels[i] = tabButton.GetComponentInChildren<Text>();
                _tabBackgrounds[i] = tabButton.targetGraphic as Image;
            }

            _content = UIFactory.CreateRect(panel.transform, "Content", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
                new Vector2(0.5f, 0.5f), new Vector2(1120f, 380f), new Vector2(0f, -40f));

            _statusText = UIFactory.CreateText(panel.transform, "Status", "", 22, TextAnchor.LowerCenter, new Color(1f, 0.7f, 0.7f),
                new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(900f, 34f), new Vector2(0f, 18f));

            SetTab(TabCharacters);
        }

        private void SetTab(int tab)
        {
            _tab = tab;
            for (int i = 0; i < _tabLabels.Length; i++)
            {
                if (_tabBackgrounds[i] != null)
                {
                    _tabBackgrounds[i].color = i == tab ? TabActive : TabIdle;
                }
                if (_tabLabels[i] != null)
                {
                    _tabLabels[i].color = i == tab ? new Color(0.08f, 0.08f, 0.12f) : UIFactory.TextColor;
                }
            }
            ClearCards();
            switch (tab)
            {
                case TabWeapons:
                    BuildWeaponCards();
                    break;
                case TabPowerUps:
                    BuildPowerUpCards();
                    break;
                default:
                    BuildCharacterCards();
                    break;
            }
            RefreshHeader();
        }

        private void ClearCards()
        {
            for (int i = 0; i < _cards.Count; i++)
            {
                if (_cards[i] != null)
                {
                    Destroy(_cards[i]);
                }
            }
            _cards.Clear();
            _statusText.text = "";
        }

        private void RefreshHeader()
        {
            _coinsText.text = "MONEDAS: " + SaveSystem.Coins;
            _gemsText.text = "GEMAS: " + SaveSystem.Gems;
        }

        private void SetStatus(string message, bool success)
        {
            _statusText.text = message;
            _statusText.color = success ? new Color(0.6f, 1f, 0.7f) : new Color(1f, 0.6f, 0.6f);
        }

        // ------------------------------------------------------------------
        // TARJETAS
        // ------------------------------------------------------------------
        private RectTransform CreateCard(int index, int total)
        {
            float cardWidth = 256f;
            float spacing = 24f;
            float totalWidth = total * cardWidth + (total - 1) * spacing;
            float startX = -totalWidth * 0.5f + cardWidth * 0.5f;

            RectTransform card = UIFactory.CreateRect(_content, "Card" + index, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
                new Vector2(0.5f, 0.5f), new Vector2(cardWidth, 372f), new Vector2(startX + index * (cardWidth + spacing), 0f));

            Image background = card.gameObject.AddComponent<Image>();
            background.sprite = SpriteFactory.White;
            background.color = UIFactory.PanelLight;

            _cards.Add(card.gameObject);
            return card;
        }

        private void BuildCharacterCards()
        {
            List<CharacterDefinition> list = ChronosCatalog.Characters;
            for (int i = 0; i < list.Count; i++)
            {
                CharacterDefinition definition = list[i];
                RectTransform card = CreateCard(i, list.Count);

                UIFactory.CreateImage(card, "Icon", SpriteFactory.GetHero(definition.PaletteIndex, HeroAnim.Idle, 0), Color.white,
                    new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(112f, 112f), new Vector2(0f, -16f));

                UIFactory.CreateText(card, "Name", definition.DisplayName, 26, TextAnchor.UpperCenter, UIFactory.Accent,
                    new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(232f, 32f), new Vector2(0f, -136f));

                UIFactory.CreateText(card, "Stats", CharacterSelection.Describe(definition), 18, TextAnchor.UpperCenter, new Color(0.75f, 0.9f, 1f),
                    new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(236f, 26f), new Vector2(0f, -170f));

                UIFactory.CreateText(card, "Description", definition.Description, 18, TextAnchor.UpperCenter, new Color(0.82f, 0.84f, 0.92f),
                    new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(228f, 66f), new Vector2(0f, -200f));

                bool unlocked = SaveSystem.IsCharacterUnlocked(definition.Id);
                bool selected = SaveSystem.SelectedCharacterId == definition.Id;

                string label;
                Color color;
                if (selected)
                {
                    label = "SELECCIONADO";
                    color = new Color(0.3f, 0.65f, 0.4f, 1f);
                }
                else if (unlocked)
                {
                    label = "SELECCIONAR";
                    color = UIFactory.AccentBlue;
                }
                else
                {
                    label = "COMPRAR  " + definition.PriceCoins;
                    color = UIFactory.Accent;
                }

                CharacterDefinition captured = definition;
                UIFactory.CreateButton(card, "Action", label, 22, color,
                    new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(216f, 60f), new Vector2(0f, 22f),
                    delegate { HandleCharacter(captured); });
            }
        }

        private void HandleCharacter(CharacterDefinition definition)
        {
            SaveSystem.Load();
            if (SaveSystem.IsCharacterUnlocked(definition.Id))
            {
                if (CharacterSelection.TrySelect(definition.Id))
                {
                    AudioFx.Play(Sfx.UiClick);
                    SetStatus(definition.DisplayName + " EQUIPADO EN LA SIGUIENTE PARTIDA.", true);
                }
            }
            else if (SaveSystem.TrySpend(definition.PriceCoins, 0))
            {
                SaveSystem.UnlockCharacter(definition.Id);
                CharacterSelection.TrySelect(definition.Id);
                AudioFx.Play(Sfx.Purchase);
                SetStatus("¡" + definition.DisplayName + " SE UNE AL LEGADO!", true);
            }
            else
            {
                AudioFx.Play(Sfx.Denied);
                SetStatus("SALDO INSUFICIENTE: NECESITAS " + definition.PriceCoins + " MONEDAS.", false);
            }
            SetTab(TabCharacters);
        }

        private void BuildWeaponCards()
        {
            List<WeaponDefinition> list = ChronosCatalog.Weapons;
            for (int i = 0; i < list.Count; i++)
            {
                WeaponDefinition definition = list[i];
                RectTransform card = CreateCard(i, list.Count);

                UIFactory.CreateImage(card, "Icon", SpriteFactory.Get(IconFor(definition.Kind), 0), Color.white,
                    new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(104f, 104f), new Vector2(0f, -14f));

                UIFactory.CreateText(card, "Name", definition.DisplayName, 21, TextAnchor.UpperCenter, UIFactory.Accent,
                    new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(240f, 28f), new Vector2(0f, -124f));

                bool unlocked = SaveSystem.IsWeaponUnlocked(definition.Id);
                int level = SaveSystem.GetWeaponLevel(definition.Id);
                int damage = ChronosCatalog.WeaponDamage(definition, Mathf.Max(1, level));
                bool equipped = SaveSystem.SelectedWeaponId == definition.Id;

                string stats = "DAÑO " + damage + "  |  ALCANCE " + definition.Range.ToString("0.0")
                    + "\nCADENCIA " + definition.AttackCooldown.ToString("0.00") + " s"
                    + "\nNIVEL " + Mathf.Max(1, level) + " / " + definition.MaxLevel;
                if (definition.IsProjectile)
                {
                    stats += "\nPROYECTIL (PERFORA " + definition.ProjectilePierce + ")";
                }

                UIFactory.CreateText(card, "Stats", stats, 17, TextAnchor.UpperCenter, new Color(0.78f, 0.9f, 1f),
                    new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(236f, 96f), new Vector2(0f, -154f));

                string actionLabel;
                Color actionColor;
                if (!unlocked)
                {
                    actionLabel = "COMPRAR  " + definition.PriceCoins;
                    actionColor = UIFactory.Accent;
                }
                else if (equipped)
                {
                    actionLabel = "EQUIPADA";
                    actionColor = new Color(0.3f, 0.65f, 0.4f, 1f);
                }
                else
                {
                    actionLabel = "EQUIPAR";
                    actionColor = UIFactory.AccentBlue;
                }

                WeaponDefinition captured = definition;
                UIFactory.CreateButton(card, "Action", actionLabel, 21, actionColor,
                    new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(216f, 56f), new Vector2(0f, 84f),
                    delegate { HandleWeapon(captured); });

                string upgradeLabel = unlocked
                    ? (level >= definition.MaxLevel ? "NIVEL MAXIMO" : "MEJORAR  " + ChronosCatalog.WeaponUpgradeCost(definition, Mathf.Max(1, level)))
                    : "BLOQUEADA";
                UIFactory.CreateButton(card, "Upgrade", upgradeLabel, 20,
                    unlocked && level < definition.MaxLevel ? new Color(0.75f, 0.55f, 0.2f, 1f) : new Color(0.24f, 0.26f, 0.34f, 1f),
                    new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(216f, 52f), new Vector2(0f, 24f),
                    delegate { HandleWeaponUpgrade(captured); });
            }
        }

        private static PixelArtType IconFor(WeaponKind kind)
        {
            switch (kind)
            {
                case WeaponKind.FireGreatsword: return PixelArtType.WeaponGreatsword;
                case WeaponKind.FastDaggers: return PixelArtType.WeaponDaggers;
                case WeaponKind.BoomerangLance: return PixelArtType.WeaponBoomerang;
                default: return PixelArtType.WeaponSword;
            }
        }

        private void HandleWeapon(WeaponDefinition definition)
        {
            SaveSystem.Load();
            if (!SaveSystem.IsWeaponUnlocked(definition.Id))
            {
                if (SaveSystem.TrySpend(definition.PriceCoins, 0))
                {
                    SaveSystem.UnlockWeapon(definition.Id);
                    SaveSystem.SelectedWeaponId = definition.Id;
                    SaveSystem.SetWeaponLevel(definition.Id, 1);
                    AudioFx.Play(Sfx.Purchase);
                    SetStatus("¡" + definition.DisplayName + " FORJADA Y EQUIPADA!", true);
                }
                else
                {
                    AudioFx.Play(Sfx.Denied);
                    SetStatus("SALDO INSUFICIENTE: NECESITAS " + definition.PriceCoins + " MONEDAS.", false);
                }
            }
            else
            {
                SaveSystem.SelectedWeaponId = definition.Id;
                SaveSystem.Save();
                AudioFx.Play(Sfx.UiClick);
                SetStatus(definition.DisplayName + " EQUIPADA.", true);
            }
            SetTab(TabWeapons);
        }

        private void HandleWeaponUpgrade(WeaponDefinition definition)
        {
            SaveSystem.Load();
            if (!SaveSystem.IsWeaponUnlocked(definition.Id))
            {
                AudioFx.Play(Sfx.Denied);
                SetStatus("PRIMERO DEBES COMPRAR EL ARMA.", false);
                return;
            }
            int level = Mathf.Max(1, SaveSystem.GetWeaponLevel(definition.Id));
            if (level >= definition.MaxLevel)
            {
                AudioFx.Play(Sfx.Denied);
                SetStatus("EL ARMA YA ESTA EN NIVEL MAXIMO.", false);
                return;
            }

            int cost = ChronosCatalog.WeaponUpgradeCost(definition, level);
            if (SaveSystem.TrySpend(cost, 0))
            {
                SaveSystem.SetWeaponLevel(definition.Id, level + 1);
                AudioFx.Play(Sfx.Purchase);
                SetStatus(definition.DisplayName + " ASCENDIDA A NIVEL " + (level + 1) + " (DAÑO "
                    + ChronosCatalog.WeaponDamage(definition, level + 1) + ").", true);
            }
            else
            {
                AudioFx.Play(Sfx.Denied);
                SetStatus("SALDO INSUFICIENTE: LA MEJORA CUESTA " + cost + " MONEDAS.", false);
            }
            SetTab(TabWeapons);
        }

        private void BuildPowerUpCards()
        {
            List<PowerUpDefinition> list = ChronosCatalog.PowerUps;
            for (int i = 0; i < list.Count; i++)
            {
                PowerUpDefinition definition = list[i];
                RectTransform card = CreateCard(i, list.Count);

                UIFactory.CreateImage(card, "Icon", SpriteFactory.Get(definition.Icon, 0), Color.white,
                    new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(104f, 104f), new Vector2(0f, -18f));

                UIFactory.CreateText(card, "Name", definition.DisplayName, 21, TextAnchor.UpperCenter, UIFactory.Accent,
                    new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(240f, 28f), new Vector2(0f, -130f));

                string info = definition.Description
                    + "\nDURACION: " + (definition.Duration > 0f ? definition.Duration.ToString("0") + " s" : "HASTA RECIBIR UN GOLPE")
                    + "\nEN INVENTARIO: x" + SaveSystem.GetPowerUpCount(definition.Key);

                UIFactory.CreateText(card, "Info", info, 18, TextAnchor.UpperCenter, new Color(0.8f, 0.88f, 1f),
                    new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(232f, 130f), new Vector2(0f, -162f));

                PowerUpDefinition captured = definition;
                UIFactory.CreateButton(card, "Buy", "COMPRAR  " + definition.PriceCoins, 21, UIFactory.Accent,
                    new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(216f, 58f), new Vector2(0f, 46f),
                    delegate { HandlePowerUp(captured); });
            }
        }

        private void HandlePowerUp(PowerUpDefinition definition)
        {
            SaveSystem.Load();
            if (SaveSystem.TrySpend(definition.PriceCoins, 0))
            {
                SaveSystem.AddPowerUp(definition.Key, 1);
                AudioFx.Play(Sfx.Purchase);
                SetStatus(definition.DisplayName + " AÑADIDO AL INVENTARIO (x" + SaveSystem.GetPowerUpCount(definition.Key)
                    + "). USALO CON LOS BOTONES DEL HUD.", true);
            }
            else
            {
                AudioFx.Play(Sfx.Denied);
                SetStatus("SALDO INSUFICIENTE: CUESTA " + definition.PriceCoins + " MONEDAS.", false);
            }
            SetTab(TabPowerUps);
        }
    }
}
