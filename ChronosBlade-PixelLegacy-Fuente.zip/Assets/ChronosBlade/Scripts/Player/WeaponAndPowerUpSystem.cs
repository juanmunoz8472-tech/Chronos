using System.Collections.Generic;
using UnityEngine;

namespace ChronosBlade
{
    /// <summary>
    /// Sistema de armas equipables. Gestiona el ataque cuerpo a cuerpo (caja de golpe
    /// orientable) y el lanzamiento de proyectiles, ademas del daño final combinando
    /// arma + nivel de mejora + multiplicador del personaje + potenciadores activos.
    /// </summary>
    public class WeaponSystem : MonoBehaviour
    {
        public float CurrentCooldown { get; private set; }
        public int CurrentDamage { get; private set; }

        private PixelPlayerController _player;
        private WeaponDefinition _definition;
        private int _level = 1;

        private GameObject _hitboxGo;
        private BoxCollider2D _hitboxCollider;
        private MeleeHitbox _hitboxScript;

        private float _cooldownTimer;
        private float _activeWindow;
        private int _swingId;
        private readonly HashSet<PixelEnemyAI> _alreadyHit = new HashSet<PixelEnemyAI>();

        public WeaponDefinition Definition { get { return _definition; } }
        public int Level { get { return _level; } }

        public void Init(PixelPlayerController player, WeaponDefinition definition, int level)
        {
            _player = player;
            SetWeapon(definition, level);
            EnsureHitbox();
        }

        public void SetWeapon(WeaponDefinition definition, int level)
        {
            _definition = definition != null ? definition : ChronosCatalog.Weapons[0];
            _level = Mathf.Max(1, level);
            RefreshDamage();
        }

        public void RefreshDamage()
        {
            float powerMultiplier = _player != null && _player.PowerUps != null ? _player.PowerUps.DamageMultiplier : 1f;
            float characterMultiplier = _player != null ? _player.DamageMultiplier : 1f;
            int baseDamage = ChronosCatalog.WeaponDamage(_definition, _level);
            CurrentDamage = Mathf.Max(1, Mathf.RoundToInt(baseDamage * characterMultiplier * powerMultiplier));
            CurrentCooldown = _definition != null ? _definition.AttackCooldown : 0.3f;
        }

        private void EnsureHitbox()
        {
            if (_hitboxGo != null)
            {
                return;
            }
            _hitboxGo = new GameObject("MeleeHitbox");
            _hitboxGo.transform.SetParent(transform, false);
            _hitboxCollider = _hitboxGo.AddComponent<BoxCollider2D>();
            _hitboxCollider.isTrigger = true;
            _hitboxScript = _hitboxGo.AddComponent<MeleeHitbox>();
            _hitboxScript.Owner = this;
            _hitboxGo.SetActive(false);
        }

        private void Update()
        {
            if (_cooldownTimer > 0f)
            {
                _cooldownTimer -= Time.deltaTime;
            }

            if (_activeWindow > 0f)
            {
                _activeWindow -= Time.deltaTime;
                if (_activeWindow <= 0f)
                {
                    DisableHitbox();
                }
                else if (_hitboxGo != null && _player != null)
                {
                    _hitboxGo.transform.position = Vector3.Lerp(_hitboxGo.transform.position, DesiredHitboxCenter(), 0.5f);
                }
            }
        }

        /// <summary>Intenta ejecutar un ataque hacia la direccion indicada.</summary>
        public bool TryAttack(Vector2 direction)
        {
            if (_player == null || _definition == null || _cooldownTimer > 0f)
            {
                return false;
            }

            if (direction.sqrMagnitude < 0.01f)
            {
                direction = new Vector2(_player.Facing, 0f);
            }
            direction = direction.normalized;

            _cooldownTimer = _definition.AttackCooldown;
            _swingId++;
            _alreadyHit.Clear();
            RefreshDamage();

            if (_definition.IsProjectile)
            {
                AudioFx.Play(Sfx.Shoot, 0.7f);
                Projectile.Spawn(_player, _definition, CurrentDamage, direction);
                Vfx.Slash(_player.transform.position + (Vector3)(direction * 0.6f), direction,
                    new Color(0.55f, 0.88f, 1f), 0.85f);
            }
            else
            {
                AudioFx.Play(Sfx.Attack, 0.75f);
                EnableHitbox(direction);
            }
            return true;
        }

        private void EnableHitbox(Vector2 direction)
        {
            EnsureHitbox();
            if (_hitboxGo == null)
            {
                return;
            }

            float range = _definition.Range;
            _hitboxCollider.size = new Vector2(range, range * 0.85f);
            _hitboxGo.transform.position = (Vector2)_player.transform.position + Vector2.up * 0.85f + direction * (range * 0.5f);
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            _hitboxGo.transform.rotation = Quaternion.Euler(0f, 0f, angle);
            _hitboxGo.SetActive(true);
            _activeWindow = Mathf.Min(0.20f, _definition.AttackCooldown * 0.65f);

            Vfx.Slash(_hitboxGo.transform.position, direction, _definition.SlashColor, range * 0.95f);
        }

        private Vector2 DesiredHitboxCenter()
        {
            Vector2 direction = new Vector2(_player.Facing, 0f);
            if (_hitboxGo != null)
            {
                float angle = _hitboxGo.transform.eulerAngles.z * Mathf.Deg2Rad;
                direction = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));
            }
            return (Vector2)_player.transform.position + Vector2.up * 0.85f + direction * (_definition.Range * 0.5f);
        }

        private void DisableHitbox()
        {
            if (_hitboxGo != null)
            {
                _hitboxGo.SetActive(false);
            }
        }

        /// <summary>Llamado por la caja de golpe cuando un enemigo esta dentro.</summary>
        public void HandleHit(Collider2D other)
        {
            if (other == null || _activeWindow <= 0f)
            {
                return;
            }
            PixelEnemyAI enemy = other.GetComponentInParent<PixelEnemyAI>();
            if (enemy == null || enemy.IsDead || _alreadyHit.Contains(enemy))
            {
                return;
            }

            _alreadyHit.Add(enemy);
            Vector2 direction = new Vector2(_player.Facing, 0.35f).normalized;
            Vector2 hitPoint = other.bounds.center;
            if (direction.x > 0f)
            {
                hitPoint.x = Mathf.Min(hitPoint.x, _hitboxGo.transform.position.x + _definition.Range);
            }
            bool killed = enemy.TakeDamage(CurrentDamage, direction, _definition.Knockback);

            Vfx.Spark(hitPoint, new Color(1f, 0.95f, 0.7f), killed ? 8 : 4);
            CameraFollow.Shake(killed ? 0.32f : 0.16f, 0.12f);
            AudioFx.Play(Sfx.Hit, 0.8f);
        }
    }

    /// <summary>Reenviador de eventos de la caja de golpe cuerpo a cuerpo.</summary>
    public class MeleeHitbox : MonoBehaviour
    {
        public WeaponSystem Owner;

        private void OnTriggerEnter2D(Collider2D other)
        {
            if (Owner != null)
            {
                Owner.HandleHit(other);
            }
        }

        private void OnTriggerStay2D(Collider2D other)
        {
            if (Owner != null)
            {
                Owner.HandleHit(other);
            }
        }
    }

    /// <summary>
    /// Proyectil de las armas a distancia (Lanza Bumeran). Vuela, atraviesa enemigos
    /// y regresa al heroe antes de desaparecer.
    /// </summary>
    public class Projectile : MonoBehaviour
    {
        private PixelPlayerController _owner;
        private int _damage;
        private float _speed;
        private int _pierceLeft;
        private Vector2 _direction;
        private float _life = 3.2f;
        private float _spin;
        private float _outboundTime = 0.55f;
        private bool _returning;
        private SpriteRenderer _renderer;
        private readonly HashSet<PixelEnemyAI> _hit = new HashSet<PixelEnemyAI>();

        public static Projectile Spawn(PixelPlayerController owner, WeaponDefinition definition, int damage, Vector2 direction)
        {
            GameObject go = new GameObject("ChronosProjectile");
            go.transform.position = owner.transform.position + Vector3.up * 0.85f + (Vector3)(direction * 0.7f);
            Projectile projectile = go.AddComponent<Projectile>();
            projectile.Setup(owner, definition, damage, direction);
            return projectile;
        }

        private void Setup(PixelPlayerController owner, WeaponDefinition definition, int damage, Vector2 direction)
        {
            _owner = owner;
            _damage = damage;
            _speed = definition != null && definition.ProjectileSpeed > 0f ? definition.ProjectileSpeed : 15f;
            _pierceLeft = definition != null ? Mathf.Max(1, definition.ProjectilePierce) : 3;
            _direction = direction.sqrMagnitude > 0.01f ? direction.normalized : Vector2.right;

            _renderer = gameObject.AddComponent<SpriteRenderer>();
            _renderer.sprite = SpriteFactory.Get(PixelArtType.ProjectileBlade, 0);
            _renderer.sortingOrder = 25;

            GameObject glow = new GameObject("Glow");
            glow.transform.SetParent(transform, false);
            SpriteRenderer glowRenderer = glow.AddComponent<SpriteRenderer>();
            glowRenderer.sprite = SpriteFactory.Get(PixelArtType.Particle, 0);
            glowRenderer.color = new Color(0.6f, 0.9f, 1f, 0.65f);
            glowRenderer.transform.localScale = new Vector3(2.6f, 2.6f, 1f);
            glowRenderer.sortingOrder = 24;
        }

        private void Update()
        {
            _life -= Time.deltaTime;
            _outboundTime -= Time.deltaTime;
            _spin += Time.deltaTime * 900f;

            if (_life <= 0f)
            {
                Destroy(gameObject);
                return;
            }

            if (!_returning && (_outboundTime <= 0f || transform.position.x * _direction.x > _owner.transform.position.x * _direction.x + 9f))
            {
                _returning = true;
            }

            if (_returning && _owner != null)
            {
                Vector2 toOwner = ((Vector2)_owner.transform.position + Vector2.up * 0.85f) - (Vector2)transform.position;
                if (toOwner.magnitude < 0.55f)
                {
                    Destroy(gameObject);
                    return;
                }
                _direction = Vector2.Lerp(_direction, toOwner.normalized, 0.14f).normalized;
            }
            else if (Mathf.Abs(_direction.y) < 1.7f)
            {
                _direction.y -= Mathf.Clamp(_direction.y, -0.6f, 0.6f) * Time.deltaTime * 0.6f;
            }

            transform.position = (Vector2)transform.position + _direction * _speed * Time.deltaTime;

            if (_renderer != null)
            {
                _renderer.sprite = SpriteFactory.Get(PixelArtType.ProjectileBlade, Mathf.Abs((int)(_spin / 90f)) % 4);
            }
            transform.rotation = Quaternion.Euler(0f, 0f, _spin * (_direction.x >= 0f ? -1f : 1f) * 0.25f);

            Collider2D[] hits = Physics2D.OverlapCircleAll(transform.position, 0.45f);
            for (int i = 0; i < hits.Length; i++)
            {
                PixelEnemyAI enemy = hits[i] != null ? hits[i].GetComponentInParent<PixelEnemyAI>() : null;
                if (enemy == null || enemy.IsDead || _hit.Contains(enemy))
                {
                    continue;
                }
                _hit.Add(enemy);
                bool killed = enemy.TakeDamage(_damage, _direction, 4.5f);
                Vfx.Spark(transform.position, new Color(0.7f, 0.95f, 1f), 5);
                AudioFx.Play(Sfx.Hit, 0.6f);
                CameraFollow.Shake(killed ? 0.25f : 0.12f, 0.1f);
                _pierceLeft--;
                if (_pierceLeft <= 0 && !_returning)
                {
                    _returning = true;
                }
            }
        }

        private void OnDestroy()
        {
            Vfx.Puff(transform.position, new Color(0.7f, 0.95f, 1f), 3);
        }
    }

    /// <summary>
    /// Potenciadores activos y pasivos del jugador:
    ///  - Tonic: invencibilidad temporal total.
    ///  - Magnet: iman de monedas y gemas.
    ///  - Shield: absorbe el siguiente golpe (pasivo hasta consumirse).
    ///  - DoubleDamage: multiplicador de dano x2 temporal.
    /// Los consumibles gastan inventario guardado con PlayerPrefs.
    /// </summary>
    public class PlayerPowerUpSystem : MonoBehaviour
    {
        public float MagnetRadius = 7.5f;

        private PixelPlayerController _player;
        private float _invincibilityTimer;
        private float _magnetTimer;
        private float _doubleDamageTimer;
        private bool _shieldReady;
        private int _lastActiveCount = -1;

        public event System.Action OnEffectsChanged;

        public bool IsInvincible { get { return _invincibilityTimer > 0f; } }
        public bool MagnetActive { get { return _magnetTimer > 0f; } }
        public bool ShieldActive { get { return _shieldReady; } }
        public float DamageMultiplier { get { return _doubleDamageTimer > 0f ? 2f : 1f; } }

        public void Init(PixelPlayerController player)
        {
            _player = player;
        }

        /// <summary>Activa un potenciador consumiendo inventario. Devuelve false si no hay stock.</summary>
        public bool ActivateFromInventory(string key)
        {
            PowerUpDefinition definition = ChronosCatalog.GetPowerUpByKey(key);
            if (definition == null || !SaveSystem.ConsumePowerUp(key))
            {
                AudioFx.Play(Sfx.Denied, 0.7f);
                return false;
            }
            ApplyEffect(definition.Id);
            return true;
        }

        public void ApplyEffect(PowerUpId id)
        {
            switch (id)
            {
                case PowerUpId.Tonic:
                    _invincibilityTimer = Mathf.Max(_invincibilityTimer, ChronosCatalog.GetPowerUp(PowerUpId.Tonic).Duration);
                    Vfx.Puff(transform.position, new Color(0.75f, 0.85f, 1f), 8);
                    break;
                case PowerUpId.Magnet:
                    _magnetTimer = Mathf.Max(_magnetTimer, ChronosCatalog.GetPowerUp(PowerUpId.Magnet).Duration);
                    Vfx.Puff(transform.position, new Color(1f, 0.5f, 0.5f), 6);
                    break;
                case PowerUpId.Shield:
                    _shieldReady = true;
                    Vfx.Puff(transform.position, new Color(0.45f, 0.75f, 1f), 8);
                    break;
                case PowerUpId.DoubleDamage:
                    _doubleDamageTimer = Mathf.Max(_doubleDamageTimer, ChronosCatalog.GetPowerUp(PowerUpId.DoubleDamage).Duration);
                    Vfx.Puff(transform.position, new Color(1f, 0.7f, 0.3f), 8);
                    break;
            }

            if (_player != null && _player.Weapons != null)
            {
                _player.Weapons.RefreshDamage();
            }
            AudioFx.Play(Sfx.PowerUp, 0.85f);
            NotifyChanged();
        }

        /// <summary>Absorbe un golpe con el Escudo de Fuerza. Devuelve true si lo consumio.</summary>
        public bool TryAbsorbHit()
        {
            if (!_shieldReady)
            {
                return false;
            }
            _shieldReady = false;
            NotifyChanged();
            return true;
        }

        public float RemainingSeconds(PowerUpId id)
        {
            switch (id)
            {
                case PowerUpId.Tonic: return _invincibilityTimer;
                case PowerUpId.Magnet: return _magnetTimer;
                case PowerUpId.DoubleDamage: return _doubleDamageTimer;
                case PowerUpId.Shield: return _shieldReady ? 1f : 0f;
                default: return 0f;
            }
        }

        private void Update()
        {
            HandleKeyboardShortcuts();

            if (_invincibilityTimer > 0f)
            {
                _invincibilityTimer -= Time.deltaTime;
                if (_invincibilityTimer <= 0f)
                {
                    _invincibilityTimer = 0f;
                    NotifyChanged();
                }
            }
            if (_magnetTimer > 0f)
            {
                _magnetTimer -= Time.deltaTime;
                if (_magnetTimer <= 0f)
                {
                    _magnetTimer = 0f;
                    NotifyChanged();
                }
            }
            if (_doubleDamageTimer > 0f)
            {
                _doubleDamageTimer -= Time.deltaTime;
                if (_doubleDamageTimer <= 0f)
                {
                    _doubleDamageTimer = 0f;
                    if (_player != null && _player.Weapons != null)
                    {
                        _player.Weapons.RefreshDamage();
                    }
                    NotifyChanged();
                }
            }

            if (MagnetActive && _player != null)
            {
                AttractNearbyPickups();
            }
        }

        /// <summary>Atajos de teclado 1..4 para usar consumibles durante las pruebas en editor.</summary>
        private void HandleKeyboardShortcuts()
        {
            if (Input.GetKeyDown(KeyCode.Alpha1))
            {
                ActivateFromInventory("tonic");
            }
            else if (Input.GetKeyDown(KeyCode.Alpha2))
            {
                ActivateFromInventory("magnet");
            }
            else if (Input.GetKeyDown(KeyCode.Alpha3))
            {
                ActivateFromInventory("shield");
            }
            else if (Input.GetKeyDown(KeyCode.Alpha4))
            {
                ActivateFromInventory("double");
            }
        }

        private void AttractNearbyPickups()
        {            Collider2D[] hits = Physics2D.OverlapCircleAll(transform.position, MagnetRadius);
            for (int i = 0; i < hits.Length; i++)
            {
                if (hits[i] == null)
                {
                    continue;
                }
                CoinPickup coin = hits[i].GetComponentInParent<CoinPickup>();
                if (coin != null)
                {
                    coin.AttractTo(transform.position, 16f);
                    continue;
                }
                GemPickup gem = hits[i].GetComponentInParent<GemPickup>();
                if (gem != null)
                {
                    gem.AttractTo(transform.position, 14f);
                }
            }
        }

        private void NotifyChanged()
        {
            int count = (_invincibilityTimer > 0f ? 1 : 0) + (_magnetTimer > 0f ? 1 : 0)
                + (_doubleDamageTimer > 0f ? 1 : 0) + (_shieldReady ? 1 : 0);
            if (count != _lastActiveCount)
            {
                _lastActiveCount = count;
                if (OnEffectsChanged != null)
                {
                    OnEffectsChanged();
                }
            }
        }
    }
}
