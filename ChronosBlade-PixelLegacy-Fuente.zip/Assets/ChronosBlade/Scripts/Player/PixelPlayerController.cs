using System.Collections;
using UnityEngine;

namespace ChronosBlade
{
    /// <summary>
    /// Controlador principal del heroe en pantalla Landscape.
    /// Soporta multiples personajes desbloqueables con estadisticas distintas
    /// (Salud, Velocidad, Multiplicador de Daño), movimiento con doble salto,
    /// ataque, daño con invulnerabilidad, monedas/gemas y animacion por Animator.
    /// </summary>
    [RequireComponent(typeof(Rigidbody2D))]
    [RequireComponent(typeof(BoxCollider2D))]
    public class PixelPlayerController : MonoBehaviour
    {
        // ---------------- Estadisticas ----------------
        public int MaxHealth { get; private set; }
        public int CurrentHealth { get; private set; }
        public float MoveSpeed { get; private set; }
        public float DamageMultiplier { get; private set; }
        public CharacterDefinition Character { get; private set; }
        public WeaponDefinition Weapon { get; private set; }

        // ---------------- Estado ----------------
        public int Coins { get; private set; }
        public int Gems { get; private set; }
        public bool IsDead { get; private set; }
        public bool IsFrozen { get; private set; }
        public bool IsGrounded { get; private set; }
        public bool IsAttacking { get { return _attackTimer > 0f; } }
        public float Facing { get; private set; }
        public bool CanControl { get { return !IsDead && !IsFrozen; } }

        public WeaponSystem Weapons { get; private set; }
        public PlayerPowerUpSystem PowerUps { get; private set; }

        public event System.Action OnCurrencyChanged;
        public event System.Action OnHealthChanged;

        // ---------------- Referencias ----------------
        private Rigidbody2D _rb;
        private BoxCollider2D _collider;
        private SpriteRenderer _renderer;
        private Animator _animator;
        private Transform _shadow;
        private PixelArtOverride _override;
        private GameSession _session;

        // ---------------- Ajustes de movimiento ----------------
        public float JumpVelocity = 15.2f;
        public float FallGravityMultiplier = 2.35f;
        public float LowJumpMultiplier = 2.6f;
        public float MaxFallSpeed = 30f;
        public float CoyoteTime = 0.12f;
        public int ExtraAirJumps = 1;
        public float AttackMoveMultiplier = 0.45f;
        public float InvulnerabilityTime = 1.15f;

        private float _inputX;
        private float _coyoteTimer;
        private float _jumpBufferTimer;
        private float _attackTimer;
        private float _attackCooldownTimer;
        private float _invulnerabilityTimer;
        private float _hurtTimer;
        private int _airJumpsLeft;
        private Vector2 _platformDelta;
        private float _facing = 1f;

        // ---------------- Animacion ----------------
        private HeroAnim _currentAnim = HeroAnim.Idle;
        private int _frameIndex;
        private float _frameTimer;
        private float _animTime;

        private void Awake()
        {
            _rb = GetComponent<Rigidbody2D>();
            _collider = GetComponent<BoxCollider2D>();
            _renderer = GetComponentInChildren<SpriteRenderer>();
            _animator = GetComponentInChildren<Animator>();
            _rb.gravityScale = 3.1f;
            _rb.freezeRotation = true;
            _rb.interpolation = RigidbodyInterpolation2D.Interpolate;
            _rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
            _collider.size = new Vector2(0.62f, 1.5f);
            _collider.offset = new Vector2(0f, 0.75f);
            if (_animator != null)
            {
                _animator.applyRootMotion = false;
            }
        }

        /// <summary>Inicializa el heroe con el personaje y el arma elegidos en la tienda.</summary>
        public void Init(GameSession session)
        {
            _session = session;
            Character = session.Character != null ? session.Character : ChronosCatalog.Characters[0];
            Weapon = session.Weapon != null ? session.Weapon : ChronosCatalog.Weapons[0];

            MaxHealth = Character.MaxHealth;
            CurrentHealth = MaxHealth;
            MoveSpeed = Character.MoveSpeed;
            DamageMultiplier = Character.DamageMultiplier;
            Coins = 0;
            Gems = 0;

            if (_renderer == null)
            {
                _renderer = GetComponentInChildren<SpriteRenderer>();
            }

            _override = PixelArtOverride.Load();
            ApplySpritePalette();
            BuildShadow();

            Weapons = GetComponent<WeaponSystem>();
            if (Weapons == null)
            {
                Weapons = gameObject.AddComponent<WeaponSystem>();
            }
            Weapons.Init(this, Weapon, Mathf.Max(1, session.WeaponLevel));

            PowerUps = GetComponent<PlayerPowerUpSystem>();
            if (PowerUps == null)
            {
                PowerUps = gameObject.AddComponent<PlayerPowerUpSystem>();
            }
            PowerUps.Init(this);

            if (OnHealthChanged != null)
            {
                OnHealthChanged();
            }
        }

        private void ApplySpritePalette()
        {
            if (_renderer != null)
            {
                _renderer.sprite = SpriteFactory.GetHero(Character.PaletteIndex, HeroAnim.Idle, 0);
                _renderer.sortingOrder = 20;
            }
        }

        private void BuildShadow()
        {
            GameObject shadowGo = new GameObject("Shadow");
            shadowGo.transform.SetParent(transform, false);
            shadowGo.transform.localPosition = new Vector3(0f, 0.03f, 0.05f);
            SpriteRenderer shadowRenderer = shadowGo.AddComponent<SpriteRenderer>();
            shadowRenderer.sprite = SpriteFactory.Get(PixelArtType.Shadow, 0);
            shadowRenderer.color = new Color(1f, 1f, 1f, 0.55f);
            shadowRenderer.sortingOrder = 15;
            _shadow = shadowGo.transform;
        }

        // ------------------------------------------------------------------
        // BUCLE PRINCIPAL
        // ------------------------------------------------------------------
        private void Update()
        {
            if (IsDead)
            {
                UpdateVisuals(0f);
                return;
            }

            InputHub hub = InputHub.Instance;
            float keyboardX = hub != null ? hub.Horizontal : Input.GetAxisRaw("Horizontal");

            if (!CanControl)
            {
                _inputX = 0f;
                UpdateTimers();
                UpdateVisuals(keyboardX);
                return;
            }

            _inputX = keyboardX;

            if (hub != null)
            {
                if (hub.ConsumeJump())
                {
                    _jumpBufferTimer = 0.14f;
                }
                if (hub.ConsumeAttack())
                {
                    TryAttack(hub.Vertical);
                }
            }
            else if (Input.GetButtonDown("Jump"))
            {
                _jumpBufferTimer = 0.14f;
            }

            if (Mathf.Abs(_inputX) > 0.05f)
            {
                _facing = Mathf.Sign(_inputX);
            }

            UpdateTimers();
            UpdateVisuals(keyboardX);
        }

        private void UpdateTimers()
        {
            if (_coyoteTimer > 0f)
            {
                _coyoteTimer -= Time.deltaTime;
            }
            if (_jumpBufferTimer > 0f)
            {
                _jumpBufferTimer -= Time.deltaTime;
            }
            if (_attackTimer > 0f)
            {
                _attackTimer -= Time.deltaTime;
            }
            if (_attackCooldownTimer > 0f)
            {
                _attackCooldownTimer -= Time.deltaTime;
            }
            if (_hurtTimer > 0f)
            {
                _hurtTimer -= Time.deltaTime;
            }
            if (_invulnerabilityTimer > 0f)
            {
                _invulnerabilityTimer -= Time.deltaTime;
            }
        }

        private void FixedUpdate()
        {
            if (IsDead)
            {
                _rb.velocity = new Vector2(_rb.velocity.x * 0.9f, _rb.velocity.y);
                return;
            }

            GroundCheck();

            if (_platformDelta != Vector2.zero)
            {
                _rb.position += _platformDelta;
                _platformDelta = Vector2.zero;
            }

            bool controllable = CanControl;
            float targetSpeed = controllable ? _inputX * MoveSpeed : 0f;
            if (IsAttacking && IsGrounded)
            {
                targetSpeed *= AttackMoveMultiplier;
            }

            float smooth = IsGrounded ? 1f : 0.55f;
            float newX = Mathf.Lerp(_rb.velocity.x, targetSpeed, smooth * 0.35f);
            if (Mathf.Abs(newX) < 0.05f && Mathf.Abs(targetSpeed) < 0.05f)
            {
                newX = 0f;
            }

            // Friccion extra al soltar en el suelo para un control pixel-perfect.
            if (IsGrounded && Mathf.Abs(_inputX) < 0.05f)
            {
                newX = Mathf.MoveTowards(_rb.velocity.x, 0f, 60f * Time.fixedDeltaTime);
            }

            _rb.velocity = new Vector2(newX, Mathf.Max(_rb.velocity.y, -MaxFallSpeed));

            // Gravedad mejorada estilo plataformas 2D.
            float gravity = Physics2D.gravity.y * _rb.gravityScale;
            if (_rb.velocity.y < 0f)
            {
                _rb.velocity += Vector2.up * gravity * (FallGravityMultiplier - 1f) * Time.fixedDeltaTime;
            }
            else if (_rb.velocity.y > 0f)
            {
                bool holdingJump = InputHub.Instance != null ? InputHub.Instance.JumpHeld : Input.GetButton("Jump");
                if (!holdingJump || !controllable)
                {
                    _rb.velocity += Vector2.up * gravity * (LowJumpMultiplier - 1f) * Time.fixedDeltaTime;
                }
            }

            // Salto con buffer + coyote time + doble salto.
            if (controllable && _jumpBufferTimer > 0f)
            {
                if (IsGrounded || _coyoteTimer > 0f)
                {
                    PerformJump(false);
                }
                else if (_airJumpsLeft > 0)
                {
                    PerformJump(true);
                }
            }
        }

        private void PerformJump(bool isAirJump)
        {
            _jumpBufferTimer = 0f;
            _coyoteTimer = 0f;
            if (isAirJump)
            {
                _airJumpsLeft--;
            }
            _rb.velocity = new Vector2(_rb.velocity.x, JumpVelocity);
            AudioFx.Play(isAirJump ? Sfx.DoubleJump : Sfx.Jump, 0.7f);
            Vfx.Puff(new Vector2(transform.position.x, transform.position.y + (isAirJump ? 0.5f : 0.05f)),
                isAirJump ? new Color(0.65f, 0.9f, 1f) : new Color(0.85f, 0.85f, 0.8f), 3);
        }

        private void GroundCheck()
        {
            bool wasGrounded = IsGrounded;
            Vector2 origin = new Vector2(transform.position.x, transform.position.y + 0.72f);
            Vector2 size = new Vector2(0.52f, 0.16f);
            Collider2D[] hits = Physics2D.OverlapBoxAll(origin, size, 0f);
            IsGrounded = false;
            for (int i = 0; i < hits.Length; i++)
            {
                Collider2D hit = hits[i];
                if (hit == null || hit.isTrigger)
                {
                    continue;
                }
                if (hit.transform == transform || hit.GetComponentInParent<PixelPlayerController>() == this)
                {
                    continue;
                }
                if (hit.GetComponentInParent<PixelEnemyAI>() != null)
                {
                    continue;
                }
                if (_rb.velocity.y <= 0.6f)
                {
                    IsGrounded = true;
                    break;
                }
            }

            if (IsGrounded)
            {
                _coyoteTimer = CoyoteTime;
                _airJumpsLeft = ExtraAirJumps;
                if (!wasGrounded && _rb.velocity.y < -6f)
                {
                    Vfx.Puff(new Vector2(transform.position.x, transform.position.y + 0.05f), new Color(0.9f, 0.9f, 0.85f), 4);
                }
            }
        }

        // ------------------------------------------------------------------
        // ATAQUE Y DAÑO
        // ------------------------------------------------------------------
        public void TryAttack(float verticalAxis)
        {
            if (!CanControl || Weapons == null || _attackCooldownTimer > 0f)
            {
                return;
            }
            Vector2 direction = new Vector2(_facing, Mathf.Clamp(verticalAxis, -0.85f, 0.85f) * 0.9f).normalized;
            if (verticalAxis > 0.5f && Mathf.Abs(_inputX) < 0.2f)
            {
                direction = new Vector2(0f, 1f);
            }

            if (Weapons.TryAttack(direction))
            {
                _attackTimer = 0.22f;
                _attackCooldownTimer = Weapons.CurrentCooldown;
                if (_animator != null)
                {
                    _animator.SetTrigger("Attack");
                }
            }
        }

        public void TakeDamage(int amount, float sourceX)
        {
            if (IsDead || amount <= 0)
            {
                return;
            }
            if (PowerUps != null && PowerUps.TryAbsorbHit())
            {
                _invulnerabilityTimer = 0.6f;
                Vfx.Spark(transform.position + Vector3.up * 0.8f, new Color(0.45f, 0.75f, 1f), 6);
                AudioFx.Play(Sfx.PowerUp, 0.6f);
                return;
            }
            if (_invulnerabilityTimer > 0f)
            {
                return;
            }

            CurrentHealth = Mathf.Max(0, CurrentHealth - amount);
            _invulnerabilityTimer = InvulnerabilityTime;
            _hurtTimer = 0.35f;
            float pushDirection = Mathf.Sign(transform.position.x - sourceX);
            if (Mathf.Approximately(pushDirection, 0f))
            {
                pushDirection = -_facing;
            }
            _rb.velocity = new Vector2(pushDirection * 7f, 8.5f);
            Vfx.Spark(transform.position + Vector3.up * 0.8f, new Color(1f, 0.35f, 0.35f), 5);
            CameraFollow.Shake(0.28f, 0.22f);

            if (OnHealthChanged != null)
            {
                OnHealthChanged();
            }

            if (CurrentHealth <= 0)
            {
                Die();
            }
            else
            {
                AudioFx.Play(Sfx.Hurt, 0.8f);
            }
        }

        public void Heal(int amount)
        {
            if (IsDead || amount <= 0)
            {
                return;
            }
            CurrentHealth = Mathf.Min(MaxHealth, CurrentHealth + amount);
            Vfx.Spark(transform.position + Vector3.up * 0.9f, new Color(0.95f, 0.4f, 0.45f), 5);
            AudioFx.Play(Sfx.Gem, 0.5f);
            if (OnHealthChanged != null)
            {
                OnHealthChanged();
            }
        }

        private void Die()
        {
            IsDead = true;
            _rb.velocity = new Vector2(0f, 6.5f);
            AudioFx.Play(Sfx.Die, 0.9f);
            Vfx.Spark(transform.position + Vector3.up * 0.7f, new Color(0.9f, 0.9f, 1f), 10);
            if (_animator != null)
            {
                _animator.SetBool("Dead", true);
            }
            if (_collider != null)
            {
                _collider.enabled = false;
            }
            StartCoroutine(NotifyDeathAfterDelay());
        }

        private IEnumerator NotifyDeathAfterDelay()
        {
            yield return new WaitForSeconds(1.25f);
            if (GameModeManager.Instance != null)
            {
                GameModeManager.Instance.OnPlayerDied();
            }
        }

        public void FreezeForDialogue(bool frozen)
        {
            IsFrozen = frozen;
            if (_rb != null)
            {
                _rb.velocity = new Vector2(0f, _rb.velocity.y);
            }
        }

        public void RespawnAt(Vector3 position)
        {
            IsDead = false;
            CurrentHealth = MaxHealth;
            transform.position = position;
            _rb.velocity = Vector2.zero;
            _invulnerabilityTimer = 1.6f;
            _airJumpsLeft = ExtraAirJumps;
            if (_collider != null)
            {
                _collider.enabled = true;
            }
            if (_animator != null)
            {
                _animator.SetBool("Dead", false);
            }
            if (OnHealthChanged != null)
            {
                OnHealthChanged();
            }
        }

        public void SetExternalVelocity(Vector2 velocity)
        {
            if (_rb != null)
            {
                _rb.velocity = velocity;
            }
        }

        public void BoostX(float speed)
        {
            _rb.velocity = new Vector2(speed, Mathf.Max(_rb.velocity.y, 3f));
            Vfx.Puff(transform.position, new Color(0.6f, 0.95f, 1f), 6);
            AudioFx.Play(Sfx.DoubleJump, 0.6f);
        }

        /// <summary>Las plataformas moviles empujan al jugador que va encima.</summary>
        public void AddPlatformDelta(Vector2 delta)
        {
            _platformDelta += delta;
        }

        // ------------------------------------------------------------------
        // MONEDA / GEMAS
        // ------------------------------------------------------------------
        public void AddCoins(int amount)
        {
            if (amount == 0)
            {
                return;
            }
            Coins = Mathf.Max(0, Coins + amount);
            SaveSystem.AddCoins(amount);
            if (OnCurrencyChanged != null)
            {
                OnCurrencyChanged();
            }
        }

        public void AddGems(int amount)
        {
            if (amount == 0)
            {
                return;
            }
            Gems = Mathf.Max(0, Gems + amount);
            SaveSystem.AddGems(amount);
            if (OnCurrencyChanged != null)
            {
                OnCurrencyChanged();
            }
        }

        // ------------------------------------------------------------------
        // ANIMACION
        // ------------------------------------------------------------------
        private void UpdateVisuals(float inputX)
        {
            HeroAnim anim = ResolveAnim(inputX);
            if (anim != _currentAnim)
            {
                _currentAnim = anim;
                _frameIndex = 0;
                _frameTimer = 0f;
                _animTime = 0f;
            }

            if (_animator != null)
            {
                _animator.SetFloat("Speed", Mathf.Abs(_rb != null ? _rb.velocity.x : inputX * MoveSpeed));
                _animator.SetBool("Grounded", IsGrounded);
                _animator.SetFloat("VelocityY", _rb != null ? _rb.velocity.y : 0f);
                _animator.SetBool("Dead", IsDead);
                _animator.SetBool("Attacking", IsAttacking);
            }

            if (_renderer == null)
            {
                return;
            }

            _animTime += Time.deltaTime;
            AnimationClip clip = _override != null ? _override.GetClip(anim) : null;
            if (clip != null)
            {
                clip.SampleAnimation(gameObject, Mathf.Repeat(_animTime, Mathf.Max(0.05f, clip.length)));
            }
            else
            {
                _frameTimer += Time.deltaTime;
                float fps = FrameRateFor(anim);
                if (_frameTimer >= 1f / fps)
                {
                    _frameTimer = 0f;
                    _frameIndex++;
                }
                _renderer.sprite = SpriteFactory.GetHero(Character.PaletteIndex, anim, _frameIndex);
            }

            _renderer.flipX = _facing < 0f;
            _renderer.color = ResolveTint();

            if (_shadow != null)
            {
                _shadow.position = new Vector3(transform.position.x, FloorLevel(), 0f);
                float height = Mathf.Clamp01(1f - (transform.position.y - FloorLevel()) / 6f);
                _shadow.localScale = new Vector3(0.55f + height * 0.45f, 0.45f + height * 0.35f, 1f);
            }
        }

        private float FloorLevel()
        {
            Vector2 origin = new Vector2(transform.position.x, transform.position.y + 0.72f);
            Collider2D[] hits = Physics2D.OverlapBoxAll(origin, new Vector2(0.6f, 0.2f), 0f);
            float best = transform.position.y - 1.4f;
            for (int i = 0; i < hits.Length; i++)
            {
                Collider2D hit = hits[i];
                if (hit == null || hit.isTrigger || hit.transform == transform)
                {
                    continue;
                }
                float top = hit.bounds.max.y;
                if (top > best && top <= transform.position.y + 0.95f)
                {
                    best = top;
                }
            }
            return best;
        }

        private Color ResolveTint()
        {
            if (IsDead)
            {
                return new Color(0.55f, 0.55f, 0.62f, 1f);
            }
            if (_invulnerabilityTimer > 0f && !(PowerUps != null && PowerUps.IsInvincible))
            {
                float blink = Mathf.PingPong(Time.time * 14f, 1f) > 0.5f ? 0.35f : 1f;
                return new Color(blink, blink * 0.75f, blink * 0.75f, 1f);
            }
            if (PowerUps != null && PowerUps.IsInvincible)
            {
                float glow = 0.75f + Mathf.PingPong(Time.time * 3f, 0.25f);
                return new Color(1f, glow, 0.7f, 1f);
            }
            if (PowerUps != null && PowerUps.DamageMultiplier > 1.01f)
            {
                return new Color(1f, 0.82f, 0.6f, 1f);
            }
            return Color.white;
        }

        private HeroAnim ResolveAnim(float inputX)
        {
            if (IsDead)
            {
                return HeroAnim.Die;
            }
            if (_hurtTimer > 0f)
            {
                return HeroAnim.Hurt;
            }
            if (IsAttacking)
            {
                return HeroAnim.Attack;
            }
            if (!IsGrounded)
            {
                return HeroAnim.Jump;
            }
            float speed = Mathf.Abs(_rb != null ? _rb.velocity.x : inputX);
            if (speed > 0.4f)
            {
                return HeroAnim.Run;
            }
            return HeroAnim.Idle;
        }

        private static float FrameRateFor(HeroAnim anim)
        {
            switch (anim)
            {
                case HeroAnim.Run: return 13f;
                case HeroAnim.Attack: return 16f;
                case HeroAnim.Jump: return 4f;
                case HeroAnim.Idle: return 5f;
                case HeroAnim.Hurt: return 6f;
                default: return 3f;
            }
        }
    }

    /// <summary>
    /// Permite reemplazar las animaciones procedurales por clips propios.
    /// Crea un prefab en Assets/Resources/ChronosBlade/PlayerAnimationOverride.prefab
    /// con este componente y asigna tus AnimationClip si deseas pixel art propio.
    /// </summary>
    public class PixelArtOverride : MonoBehaviour
    {
        public AnimationClip Idle;
        public AnimationClip Run;
        public AnimationClip Jump;
        public AnimationClip Attack;
        public AnimationClip Hurt;
        public AnimationClip Die;

        public static PixelArtOverride Load()
        {
            GameObject prefab = Resources.Load<GameObject>("ChronosBlade/PlayerAnimationOverride");
            if (prefab == null)
            {
                return null;
            }
            return prefab.GetComponent<PixelArtOverride>();
        }

        public AnimationClip GetClip(HeroAnim anim)
        {
            switch (anim)
            {
                case HeroAnim.Idle: return Idle;
                case HeroAnim.Run: return Run;
                case HeroAnim.Jump: return Jump;
                case HeroAnim.Attack: return Attack;
                case HeroAnim.Hurt: return Hurt;
                case HeroAnim.Die: return Die;
                default: return null;
            }
        }
    }

    /// <summary>Seleccion del personaje activo y aplicacion de sus estadisticas.</summary>
    public static class CharacterSelection
    {
        public static CharacterDefinition Selected
        {
            get { return ChronosCatalog.GetCharacter(SaveSystem.SelectedCharacterId); }
        }

        public static bool IsUnlocked(string id)
        {
            return SaveSystem.IsCharacterUnlocked(id);
        }

        public static bool TrySelect(string id)
        {
            if (!SaveSystem.IsCharacterUnlocked(id))
            {
                return false;
            }
            SaveSystem.SelectedCharacterId = id;
            SaveSystem.Save();
            return true;
        }

        public static string Describe(CharacterDefinition def)
        {
            return "VID " + def.MaxHealth
                + "  |  VEL " + def.MoveSpeed.ToString("0.0")
                + "  |  DAÑO x" + def.DamageMultiplier.ToString("0.00");
        }
    }
}
