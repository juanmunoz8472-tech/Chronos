#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace ChronosBlade.EditorTools
{
    /// <summary>
    /// Compilador de APK de Chronos Blade: Pixel Legacy para Android.
    ///
    /// Uso en el editor:   menu "Chronos Blade -> 2. Compilar APK Android (local)"
    /// Uso desde CI:       Unity -quit -batchmode -projectPath . -executeMethod ChronosBlade.EditorTools.AndroidBuilder.BuildFromCI
    ///
    /// El metodo de CI escribe el APK en "build/Android" (ruta estandar que usa
    /// game-ci/unity-builder) para que el workflow de GitHub Actions lo publique
    /// como artefacto descargable.
    /// </summary>
    public static class AndroidBuilder
    {
        public const string ApkFileName = "ChronosBlade-PixelLegacy.apk";
        public const string CiOutputFolder = "build/Android";
        public const string LocalOutputFolder = "Builds";

        [MenuItem("Chronos Blade/2. Compilar APK Android (local)")]
        public static void BuildFromMenu()
        {
            BuildApk(LocalOutputFolder, true);
        }

        /// <summary>Metodo invocado por GitHub Actions (game-ci/unity-builder -> buildMethod).</summary>
        public static void BuildFromCI()
        {
            string outputFolder = CiOutputFolder;
            string customPath = ReadCommandLineArgument("-customBuildPath");
            if (!string.IsNullOrEmpty(customPath))
            {
                outputFolder = customPath.Replace('\\', '/');
            }
            BuildApk(outputFolder, false);
        }

        /// <summary>Compila el APK de Android con la configuracion del proyecto ya aplicada.</summary>
        public static void BuildApk(string outputFolder, bool interactive)
        {
            ProjectConfigurator.EnsureConfigured(true);

            if (!EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android))
            {
                Debug.LogWarning("[Chronos Blade] No se pudo cambiar al target Android automaticamente. " +
                    "Instala el modulo 'Android Build Support' desde Unity Hub.");
            }

            string outputDirectory = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), outputFolder));
            Directory.CreateDirectory(outputDirectory);
            string apkPath = Path.Combine(outputDirectory, ApkFileName);

            BuildPlayerOptions options = new BuildPlayerOptions();
            options.scenes = ProjectConfigurator.GetEnabledScenePaths();
            options.locationPathName = apkPath;
            options.target = BuildTarget.Android;
            options.targetGroup = BuildTargetGroup.Android;
            options.options = BuildOptions.None;

            Debug.Log("[Chronos Blade] Compilando APK en: " + apkPath);
            BuildReport report = BuildPipeline.BuildPlayer(options);
            BuildSummary summary = report.summary;

            if (summary.result == BuildResult.Succeeded)
            {
                Debug.Log("[Chronos Blade] APK generado correctamente: " + summary.outputPath
                    + " (" + (summary.totalSize / 1024 / 1024) + " MB)");
                if (interactive && !Application.isBatchMode)
                {
                    EditorUtility.DisplayDialog("APK compilado",
                        "El APK se genero en:\n" + summary.outputPath, "Perfecto");
                }
                Finish(0, interactive);
                return;
            }

            Debug.LogError("[Chronos Blade] La compilacion del APK fallo: " + summary.result
                + " (" + summary.totalErrors + " errores)");
            if (interactive && !Application.isBatchMode)
            {
                EditorUtility.DisplayDialog("Error de compilacion",
                    "La compilacion fallo (" + summary.result + ").\nRevisa la consola de Unity.", "Cerrar");
            }
            Finish(1, interactive);
        }

        private static void Finish(int exitCode, bool interactive)
        {
            if (Application.isBatchMode)
            {
                EditorApplication.Exit(exitCode);
            }
            else if (!interactive)
            {
                EditorApplication.Exit(exitCode);
            }
        }

        private static string ReadCommandLineArgument(string key)
        {
            string[] args = System.Environment.GetCommandLineArgs();
            for (int i = 0; i < args.Length - 1; i++)
            {
                if (args[i] == key)
                {
                    return args[i + 1];
                }
            }
            return null;
        }
    }
}
#endif
