# CHRONOS BLADE: PIXEL LEGACY 🗡️⏳

Juego de plataformas de acción 2D en **Pixel Art** para móvil, optimizado **exclusivamente para pantalla HORIZONTAL (Landscape)**.

**3 modos de juego** (Historia con diálogos RPG, Supervivencia/Arcade y Speedrun con cronómetro MM:SS:MS), **4 héroes desbloqueables**, **4 armas**, **4 potenciadores**, tienda completa y guardado persistente.

> **Listo para usar:** todo el código está escrito a mano, completo y sin placeholders (**19 scripts C# + 2 de Editor, ~8.300 líneas**), verificado con el compilador real de C# → **0 errores, 0 advertencias**.
> El Pixel Art (sprites 16×16), los fondos con parallax, el HUD, los controles táctiles y todo el audio **se generan por código**: no hace falta importar ningún asset.

---

## 📥 1) Subir este proyecto a GitHub

1. Descomprime el ZIP `ChronosBlade-PixelLegacy-GitHub.zip` (el contenido ya está en la raíz del repositorio: `Assets/`, `Packages/`, `ProjectSettings/`, `.github/`).
2. Súbelo a tu repositorio:

```bash
git init
git add .
git commit -m "Chronos Blade: Pixel Legacy - juego completo + CI para APK"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/TU-REPO.git
git push -u origin main
```

> También puedes arrastrar la carpeta descomprimida directamente en la web de GitHub (Add file ▸ Upload files).
> El `.gitignore` ya evita subir `Library/`, `Builds/` y cualquier APK o keystore.

---

## 📱 2) Compilar el APK desde GitHub (GitHub Actions)

El repositorio incluye **dos workflows** en `.github/workflows/`:

| Archivo | Para qué sirve |
|---|---|
| `unity-activate.yml` | **Una sola vez**: genera el archivo de activación `.alf` de Unity para obtener tu licencia y crear el secreto `UNITY_LICENSE`. |
| `android-build.yml` | **Compila el APK** automáticamente en cada push, a mano desde la pestaña Actions, y adjunta el APK a la Release si subes un tag `v1.0.0`. |

### Paso A — Crear el secreto `UNITY_LICENSE` (solo la primera vez)

1. En GitHub entra a **Actions ▸ Unity - Activation ▸ Run workflow**.
2. Cuando termine, descarga el artefacto **Unity-Activation-File** (archivo `.alf`).
3. Entra a **https://license.unity3d.com/manual**, inicia sesión con tu cuenta de Unity y sube el `.alf`.
4. Elige **Unity Personal** (o tu tipo de licencia) y descarga el archivo **`.ulf`**.
5. Abre el `.ulf` con un editor de texto, copia **todo** su contenido y guárdalo en
   **Settings ▸ Secrets and variables ▸ Actions ▸ New repository secret** con el nombre exacto `UNITY_LICENSE`.
6. (Recomendado) Crea también los secretos `UNITY_EMAIL` y `UNITY_PASSWORD` con los datos de tu cuenta de Unity.

> ¿Tienes licencia Pro/Plus? Crea en su lugar los secretos `UNITY_EMAIL`, `UNITY_PASSWORD` y `UNITY_SERIAL` (no necesitas el `.ulf`).

### Paso B — Compilar

1. Ve a **Actions ▸ Build Android APK ▸ Run workflow** (o simplemente haz un `git push`).
2. Espera ~10-20 minutos (la primera vez Unity descarga el editor y compila IL2CPP).
3. Entra al run terminado y descarga el artefacto **`ChronosBlade-APK`** → dentro está `ChronosBlade-PixelLegacy.apk`.
4. Cópialo al teléfono, actívalo e instálalo (permite "instalar apps de origen desconocido").

### Paso C — Publicar una Release con el APK (opcional)

```bash
git tag v1.0.0
git push origin v1.0.0
```

El workflow detecta el tag y **adjunta el APK a la Release** de GitHub, lista para descargar.

---

## 🖥️ 3) Abrir y jugar en el editor de Unity

1. Instala **Unity Hub** y la versión **2022.3.62f1 LTS** con el módulo *Android Build Support* (incluye SDK/NDK/OpenJDK).
2. En Unity Hub: **Add ▸ Add project from disk** y elige la carpeta del repositorio.
3. Abre el proyecto: la primera vez Unity importa y **configura el proyecto automáticamente** (orientación, Android, escena Bootstrap). Verás en la consola:
   `[Chronos Blade] Configuracion aplicada: Landscape, Android (IL2CPP/ARM), escena Bootstrap registrada.`
4. Presiona **Play** en la escena `Assets/ChronosBlade/Scenes/Bootstrap.unity` (se crea y registra sola la primera vez). ¡El juego se construye solo!

**Compilar el APK en local:** menú de Unity ▸ **Chronos Blade ▸ 2. Compilar APK Android (local)** → genera `Builds/ChronosBlade-PixelLegacy.apk`.
Desde consola (línea de comandos):

```bash
Unity -quit -batchmode -projectPath . -executeMethod ChronosBlade.EditorTools.AndroidBuilder.BuildFromCI
```

---

## ⚙️ 4) Lo que el proyecto configura solo

`Assets/ChronosBlade/Editor/ProjectConfigurator.cs` aplica automáticamente (al abrir el proyecto, desde el menú **Chronos Blade ▸ 1. Configurar proyecto** y antes de cualquier build):

- **Default Orientation = Landscape Left** (+ rotación a Landscape Right; retrato desactivado).
- Nombre del producto, compañía, versión y **bundle id** `com.chronosblade.pixellegacy`.
- **IL2CPP** + **ARMv7/ARM64**, min SDK 24 (Android 7.0), target SDK automático.
- Crea la escena **`Bootstrap.unity`** y la registra en *Build Settings*.
- Al ejecutar: 60 FPS objetivo y la pantalla no se apaga (`Screen.sleepTimeout`).

¿Quieres una sola arquitectura (compilación más rápida)? Edita `ApplyPlayerSettings()` y deja `AndroidArchitecture.ARM64`.
¿Firmar para Google Play? Añade los secretos `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASS`, `ANDROID_KEYALIAS_NAME`, `ANDROID_KEYALIAS_PASS` y las 4 líneas `androidKeystore*` / `androidKeyalias*` en el paso de `game-ci/unity-builder` (ya documentadas en los comentarios del workflow).

---

## 🎮 5) Controles

| Acción | Teclado (editor) | Táctil (Landscape) |
|---|---|---|
| Mover | `A`/`D` o ←/→ | Joystick (abajo-izquierda) |
| Saltar / **doble salto** | `Espacio` / `W` / ↑ | Botón **SALTO** (púlsalo dos veces) |
| Atacar | `J` / `K` / `Z` / `X` | Botón **ATACAR** |
| Potenciadores 1-4 | `1` `2` `3` `4` | 4 ranuras del HUD |
| Avanzar diálogo | `Espacio` / clic | Tocar el cuadro de diálogo |
| Pausa | `Esc` / `P` | Botón `II` (arriba-derecha) |

---

## 📁 6) Estructura del repositorio

```
.
├── .github/workflows/
│   ├── android-build.yml            # CI: compila el APK y lo publica como artefacto/Release
│   └── unity-activate.yml           # CI: genera el .alf para obtener UNITY_LICENSE
├── Assets/ChronosBlade/
│   ├── Editor/
│   │   ├── ProjectConfigurator.cs   # Landscape + Android + escena Bootstrap (+ preprocesador de build)
│   │   └── AndroidBuilder.cs        # Compila el APK (menú local y modo CI)
│   ├── Scenes/Bootstrap.unity       # Escena vacia: el juego se construye en runtime
│   └── Scripts/
│       ├── Core/       Catalog, SpriteFactory, SaveSystem, InputHub, GameSession,
│       │               AudioFx, SceneBuilder, RuntimeBootstrap
│       ├── Player/     PixelPlayerController, WeaponAndPowerUpSystem
│       ├── Enemies/    PixelEnemyAI
│       ├── UI/         UIFactory, DialogueManager, GameModeAndEnemyManager, PixelShopManager
│       └── World/      CameraFollow, BackgroundScroller, LevelInteractables, Vfx
├── Packages/manifest.json
├── ProjectSettings/ProjectVersion.txt
├── DOCUMENTACION_JUEGO.md           # Documentacion detallada del juego y de los sistemas
├── .gitignore / .gitattributes
└── README.md
```

---

## 🧩 7) Modos de juego

- **HISTORIA** — 5 niveles con diálogos RPG (efecto máquina de escribir), checkpoints, cofres, pinchos, plataformas móviles y Portal Temporal. Guarda tu progreso.
- **SUPERVIVENCIA (Arcade)** — oleadas infinitas con contador de bajas, oleada actual y dificultad creciente; récord personal guardado.
- **SPEEDRUN** — cronómetro de precisión **MM:SS:MS**, tiempo "PAR", placas de impulso, +3 s de penalización por caída y récord persistente.

**Tienda:** 4 personajes con estadísticas únicas (VID/VEL/DAÑO), 4 armas mejorables a 5 niveles (Espada Inicial, Gran Espada de Fuego, Dagas Rápidas, Lanza Bumerán) y 4 potenciadores (Tónico de Invencibilidad, Imán de Monedas, Escudo de Fuerza, Daño x2).

---

## ❓ 8) Solución de problemas

| Problema | Solución |
|---|---|
| `UNITY_LICENSE` inválido o expirado en el workflow | Vuelve a ejecutar `unity-activate.yml`, genera un `.ulf` nuevo y actualiza el secreto. |
| El workflow falla al descargar Unity | Revisa que el secreto `UNITY_EMAIL`/`UNITY_PASSWORD` sea correcto, o que el `UNITY_LICENSE` corresponda a la cuenta. |
| "No scenes in build settings" | Abre el proyecto en Unity y ejecuta **Chronos Blade ▸ 1. Configurar proyecto** (crea y registra `Bootstrap.unity`). El preprocesador también lo hace antes de cualquier build. |
| La compilación tarda mucho | Es normal la **primera vez** (Unity + IL2CPP + ARMv7/ARM64 ≈ 15-25 min). Los siguientes runs usan la caché de `Library`. |
| El juego no responde al teclado en el editor | `Edit ▸ Project Settings ▸ Player ▸ Active Input Handling` = **Both** o *Input Manager (Old)*. |
| Errores con el formato viejo de `Input` | Es la misma causa anterior (paquete *Input System* configurado como único). |
| Quiero el APK más pequeño | Deja solo `AndroidArchitecture.ARM64` en `ProjectConfigurator.ApplyPlayerSettings()`. |

---

## 📜 9) Extra

- Documentación completa del juego (sistemas, balance, cómo usar tu propio Pixel Art): **[DOCUMENTACION_JUEGO.md](DOCUMENTACION_JUEGO.md)**.
- Todo el balance y el contenido están centralizados en `Assets/ChronosBlade/Scripts/Core/Catalog.cs`.
- Para usar tus propios sprites/animaciones: crea `Assets/Resources/ChronosBlade/PlayerAnimationOverride.prefab` con el componente `PixelArtOverride` (ver documentación).
