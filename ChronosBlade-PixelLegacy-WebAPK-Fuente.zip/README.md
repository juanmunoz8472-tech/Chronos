# Chronos Blade: Pixel Legacy — Proyecto APK (Web/Cordova)

Este ZIP contiene el juego completo y todo lo necesario para convertirlo en una
**APLICACIÓN DE ANDROID (.apk) instalable**, compilada gratis en GitHub.

> **No necesitas la licencia de Unity, ni cuenta, ni contraseñas, ni keystore.**
> El APK lo firma GitHub con la clave de depuración (*debug*) que Android
> genera solo. Ese APK se instala en cualquier teléfono sin más pasos.

---

## 1. Qué hay dentro (contenido del ZIP)

```
config.xml      -> configuración de la app (nombre, icono, pantalla horizontal)
package.json    -> declaración del proyecto para Cordova
www/index.html  -> EL JUEGO COMPLETO (Canvas 2D, todo incluido, funciona offline)
res/            -> iconos de la app en todas las densidades (mdpi ... xxxhdpi)
README.md       -> este archivo
.gitignore      -> evita subir archivos generados
```

El juego está **entero** en `www/index.html`: HTML, CSS, JavaScript, gráficos y
sonido generados por código. No descarga nada de internet: se puede jugar en
modo avión.

---

## 2. Cómo conseguir el APK en 3 pasos (desde el teléfono)

1. **Sube este ZIP tal cual** (sin descomprimir) a la raíz de tu repositorio de GitHub.
2. **Crea el archivo del workflow**: en el repositorio, entra en
   `Add file ▸ Create new file`, escribe la ruta
   `.github/workflows/chronos-blade-web.yml` y pega dentro el contenido del
   archivo `chronos-blade-web.yml` que te entregué. Guarda (*Commit changes*).
3. **Lánzalo**: pestaña **Actions ▸ Compilar APK (Chronos Blade - Web) ▸
   Run workflow ▸ Run workflow**. Espera **3-5 minutos**.

Cuando el check verde aparezca, tienes el APK en **dos sitios**:

| Dónde | Cómo llegar | Ideal para |
|---|---|---|
| Carpeta `apk/` del repositorio | `apk/ChronosBlade-PixelLegacy.apk` ▸ botón de descarga | **Descargar directo desde el teléfono** |
| Artefactos de la ejecución | Actions ▸ la ejecución ▸ *Artifacts* ▸ `ChronosBlade-APK-Web` | Guardar copias / compartir |

Después, en el teléfono: abre el archivo descargado y acepta
*"Instalar aplicaciones desconocidas"* si Android lo pregunta. Listo.

---

## 3. Compilarlo en tu ordenador (opcional)

Necesitas: Node.js 18+, Java 21, Android SDK (plataforma 36) y Gradle 8.14.2.

```bash
npm install cordova@13.0.0
npx cordova platform add android@15.1.0
npx cordova build android --debug
# APK en: platforms/android/app/build/outputs/apk/debug/app-debug.apk
```

Para probarlo en un emulador o en el teléfono conectado por USB:

```bash
npx cordova run android
```

---

## 4. Ficha técnica

| Dato | Valor |
|---|---|
| Nombre de la app | Chronos Blade |
| Identificador | `com.chronosblade.pixellegacy` |
| Versión | 1.0.0 |
| Orientación | **Horizontal (landscape)**, forzada |
| Pantalla completa | Sí (sin barra de estado) |
| Versión mínima de Android | 6.0 (API 24) |
| Compilado contra | Android 16 (API 36) |
| Permisos | **Ninguno** |
| Internet | No necesita |
| Motor | WebView de Android (Canvas 2D) |
| Tamaño del APK | ~3,5 MB |
| Firma | Automática (clave *debug* de GitHub) |

---

## 5. Personalizar (todo desde `config.xml`)

- **Nombre visible**: `<name>Chronos Blade</name>`
- **Identificador** (no lo cambies si ya instalaste una versión anterior):
  `id="com.chronosblade.pixellegacy"`
- **Versión**: `version="1.0.0"`
- **Orientación**: `<preference name="Orientation" value="landscape" />`
  (cámbiala a `portrait` si algún día quieres vertical)
- **Iconos**: sustituye los archivos de `res/` manteniendo los tamaños.
- **El juego**: edita `www/index.html`. Todo el juego (menú, 3 modos, tienda,
  controles táctiles) está ahí dentro.

Después de tocar el juego, **vuelve a subir el ZIP** al repositorio (reemplazando
el anterior) y lanza otra vez el workflow: obtendrás un APK nuevo.

---

## 6. Problemas típicos

| Síntoma | Solución |
|---|---|
| El workflow falla en "Instalar Gradle" | Es una descarga; vuelve a lanzarlo (*Re-run*). |
| "Run workflow" no aparece | El archivo debe estar en `.github/workflows/` y el repositorio tiene que tener la pestaña *Actions* activada. |
| El APK no se instala | Desinstala la versión anterior (mismas apps = mismo `id`) y vuelve a intentarlo. |
| Se ve borroso en pantallas grandes | El juego escala con `image-rendering: pixelated`; es el estilo Pixel Art. |
| Quiero subir una versión nueva | Sube el ZIP actualizado → cambia `version` en `config.xml` → lanza el workflow. |

---

## 7. Aviso legal

Chronos Blade: Pixel Legacy es original: gráficos dibujados por código y sonido
sintetizado en el propio juego. No usa recursos de terceros, ni librerías
externas, ni conexión a internet. Puedes distribuir el APK con libertad.
